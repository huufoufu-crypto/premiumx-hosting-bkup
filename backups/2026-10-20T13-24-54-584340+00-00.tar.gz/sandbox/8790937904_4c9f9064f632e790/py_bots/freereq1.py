import time
import json
import os
import threading
from datetime import datetime
import telebot
from telebot import types

# ------------------ CONFIG ------------------
BOT_TOKEN = "8687329268:AAFKACe3XHUYbluluRKTc-TlimZnVYIv1QI"
ROCKY_BOT_USERNAME = "ROCKY_FREEDMBOT"  # without @
DATA_FILE = "jaat_data.json"  # local storage

# ------------------ CONSTANTS ------------------
PREMIUM_YES_EMOJI = "6267118537752450044"
PREMIUM_NO_EMOJI = "6264989883241076562"
BUTTON_STYLES = {"primary", "success", "danger"}

bot = telebot.TeleBot(BOT_TOKEN)

# ------------------ FILE STORAGE ------------------
_db_lock = threading.Lock()

def _load_db():
    if not os.path.exists(DATA_FILE):
        return {"owners": {}, "groups": {}, "unlock_links": {}}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"⚠️ load err: {e}")
        return {"owners": {}, "groups": {}, "unlock_links": {}}

def _save_db(db):
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(db, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"⚠️ save err: {e}")

def db_get(path):
    """path: 'owners/12345' ya 'groups/-100...' etc."""
    with _db_lock:
        db = _load_db()
        parts = path.split("/")
        cur = db
        for p in parts:
            if isinstance(cur, dict) and p in cur:
                cur = cur[p]
            else:
                return None
        return cur

def db_set(path, value):
    with _db_lock:
        db = _load_db()
        parts = path.split("/")
        cur = db
        for p in parts[:-1]:
            if p not in cur or not isinstance(cur[p], dict):
                cur[p] = {}
            cur = cur[p]
        cur[parts[-1]] = value
        _save_db(db)
        return True

def db_update(path, updates):
    """Merge updates into dict at path"""
    with _db_lock:
        db = _load_db()
        parts = path.split("/")
        cur = db
        for p in parts:
            if p not in cur or not isinstance(cur[p], dict):
                cur[p] = {}
            cur = cur[p]
        cur.update(updates)
        _save_db(db)
        return True

def db_delete(path):
    with _db_lock:
        db = _load_db()
        parts = path.split("/")
        cur = db
        for p in parts[:-1]:
            if p not in cur:
                return False
            cur = cur[p]
        if parts[-1] in cur:
            del cur[parts[-1]]
            _save_db(db)
            return True
        return False

# ------------------ OWNER HELPERS ------------------
def get_owner(owner_id):
    d = db_get(f'owners/{owner_id}')
    if d:
        return {
            "access_key": d.get('access_key'),
            "expiry": d.get('expiry_ts'),
            "enabled": bool(d.get('enabled', 1)),
            "auto_approve": bool(d.get('auto_approve', False)),
            "reject_premium": bool(d.get('reject_premium', False)),
            "remove_premium_from_channel": bool(d.get('remove_premium_from_channel', False)),
            "delay_seconds": int(d.get('delay_seconds', 0)),
            "dm_messages": d.get('dm_messages', [])
        }
    return None

def get_owner_by_chat(chat_id):
    m = db_get(f'groups/{chat_id}')
    return m.get('owner_id') if m else None

def is_owner(uid):
    return get_owner(uid) is not None

def update_owner(uid, updates):
    return db_update(f'owners/{uid}', updates)

def assign_group(uid, chat_id):
    return db_set(f'groups/{chat_id}', {'owner_id': int(uid)})

def remove_group(chat_id):
    return db_delete(f'groups/{chat_id}')

# ------------------ RAW HTTP SENDER ------------------
import requests

def tg_send(chat_id, text, reply_markup=None, parse_mode="HTML"):
    payload = {"chat_id": chat_id, "text": text}
    if parse_mode:
        payload["parse_mode"] = parse_mode
    if reply_markup:
        payload["reply_markup"] = reply_markup
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
            json=payload, timeout=15
        )
        return r.json()
    except Exception as e:
        print(f"tg_send err: {e}")
        return {"ok": False}

# ------------------ MIGRATION / DEFAULT OWNER ------------------
def ensure_default_owner():
    db = _load_db()
    if not db.get("owners"):
        default_owner = 6934676403
        db_set(f'owners/{default_owner}', {
            'access_key': None,
            'expiry_ts': None,
            'enabled': 1,
            'dm_messages': []
        })
        print(f"✅ Created default owner {default_owner}")

ensure_default_owner()

# ------------------ DM SENDER (unlock URL inject) ------------------
def send_dm_content(user_id, entry, owner_id):
    try:
        bot.copy_message(user_id, entry["chat_id"], entry["msg_id"])
    except Exception as e:
        print(f"❌ copy_message failed: {e}")
        return

    buttons = entry.get("buttons", [])
    if not buttons:
        return

    stored_buttons = []
    inline_keyboard = []

    for idx, btn in enumerate(buttons):
        stored_buttons.append({
            "idx": idx,
            "text": btn["text"],
            "original_url": btn["url"],
            "style": btn.get("style"),
            "icon_custom_emoji_id": btn.get("icon_custom_emoji_id")
        })

        new_btn = {
            "text": btn["text"],
            "url": f"https://t.me/{ROCKY_BOT_USERNAME}?start=unlock_{user_id}_{idx}"
        }
        if btn.get("style") in BUTTON_STYLES:
            new_btn["style"] = btn["style"]
        if btn.get("icon_custom_emoji_id"):
            new_btn["icon_custom_emoji_id"] = btn["icon_custom_emoji_id"]

        inline_keyboard.append([new_btn])

    resp = tg_send(
        user_id,
        "✦ 𝐈𝐌𝐏𝐎𝐑𝐓𝐀𝐍𝐓 ✦",
        reply_markup={"inline_keyboard": inline_keyboard}
    )

    if not resp.get("ok"):
        print(f"⚠️ Button msg failed: {resp}")
        return

    dm_msg_id = resp["result"]["message_id"]

    existing = db_get(f"unlock_links/{user_id}") or {}
    all_buttons = existing.get("buttons", []) + stored_buttons

    db_set(f"unlock_links/{user_id}", {
        "buttons": all_buttons,
        "dm_msg_id": dm_msg_id,
        "owner_id": owner_id,
        "unlocked": False,
        "created_at": int(time.time())
    })

# ------------------ KEYBOARDS ------------------
def _raw_inline(inline_json):
    kb = types.InlineKeyboardMarkup(row_width=1)
    for row in inline_json:
        btns = []
        for b in row:
            btns.append(types.InlineKeyboardButton(
                text=b["text"],
                callback_data=b.get("callback_data"),
                url=b.get("url")
            ))
        kb.add(*btns)
    return kb

def main_menu_keyboard(owner=None):
    if owner is None:
        owner = {}
    auto = owner.get("auto_approve", False)
    rej = owner.get("reject_premium", False)
    chn = owner.get("remove_premium_from_channel", False)
    delay = owner.get("delay_seconds", 0)

    inline = [
        [{"text": "👥 Users Check", "callback_data": "users_check"}],
        [{"text": f"🪃 Channel Premium Remove: {'ON 🟢' if chn else 'OFF 🔴'}",
          "callback_data": "toggle_chn_premium"}],
        [{"text": f"⛔ Reject Premium: {'ON 🟢' if rej else 'OFF 🔴'}",
          "callback_data": "toggle_reject_premium"}],
        [{"text": f"⚙️ Auto-Approve: {'ON 🟢' if auto else 'OFF 🔴'}",
          "callback_data": "toggle_auto_approve"}],
        [
            {"text": "1️⃣ Setup Msg 1", "callback_data": "setup_msg_1"},
            {"text": "2️⃣ Setup Msg 2", "callback_data": "setup_msg_2"},
            {"text": "3️⃣ Setup Msg 3", "callback_data": "setup_msg_3"},
        ],
        [{"text": f"⏱️ Setup Delay: {delay} sec", "callback_data": "setup_delay"}],
        [{"text": "1️⃣ ADD DM MSG", "callback_data": "add_msg"}],
        [{"text": "3️⃣ DLT ALL DM MSG", "callback_data": "dlt_msg"}],
        [{"text": "4️⃣ ON/OFF TOGGLE", "callback_data": "toggle"}],
        [{"text": "5️⃣ REMAINING TIME", "callback_data": "time"}],
    ]
    return _raw_inline(inline)

def add_button_choice_keyboard():
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("✅ Yes, add button", callback_data="add_btn_yes",
                                   icon_custom_emoji_id=PREMIUM_YES_EMOJI),
        types.InlineKeyboardButton("❌ No", callback_data="add_btn_no",
                                   icon_custom_emoji_id=PREMIUM_NO_EMOJI)
    )
    return kb

def add_another_button_keyboard():
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("✅ Yes, add another", callback_data="add_another_yes",
                                   icon_custom_emoji_id=PREMIUM_YES_EMOJI),
        types.InlineKeyboardButton("❌ No, done", callback_data="add_another_no",
                                   icon_custom_emoji_id=PREMIUM_NO_EMOJI)
    )
    return kb

def color_selection_keyboard():
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("Primary", callback_data="color_primary"),
        types.InlineKeyboardButton("Success", callback_data="color_success"),
        types.InlineKeyboardButton("Danger", callback_data="color_danger"),
        types.InlineKeyboardButton("❌ No Color", callback_data="color_none")
    )
    return kb

# ------------------ STATE ------------------
user_state = {}
user_temp_msgs = {}
user_current_msg_idx = {}
user_temp_button_text = {}
user_temp_button_color = {}
user_temp_button_emoji = {}

# ------------------ /start ------------------
@bot.message_handler(commands=['start'])
def start_cmd(message):
    uid = message.chat.id
    if not is_owner(uid):
        bot.send_message(uid, "🚫 *THIS BOT IS NOT FOR YOU*\n\nContact @absolecore.",
                         parse_mode="Markdown")
        return
    cfg = get_owner(uid)
    if cfg and cfg['access_key'] and cfg['expiry'] and cfg['expiry'] > int(time.time()):
        bot.send_message(uid, "✅ *Access Granted*\n\n🔹 Welcome!",
                         parse_mode="Markdown",
                         reply_markup=main_menu_keyboard(cfg))
        return
    user_state[uid] = "awaiting_key"
    bot.send_message(uid, "🔐 *Access Key Required*\n\nEnter your key:",
                     parse_mode="Markdown")

@bot.message_handler(func=lambda m: user_state.get(m.chat.id) == "awaiting_key")
def handle_key(m):
    uid = m.chat.id
    if not is_owner(uid):
        return
    entered = m.text.strip()
    cfg = get_owner(uid)
    if not cfg:
        bot.send_message(uid, "❌ Account not found.")
        return
    if not cfg['access_key']:
        bot.send_message(uid, "❌ No key configured.")
        return
    if entered == cfg['access_key'] and cfg['expiry'] and cfg['expiry'] > int(time.time()):
        user_state[uid] = None
        bot.send_message(uid, "✅ *Key Verified!*", parse_mode="Markdown",
                         reply_markup=main_menu_keyboard(cfg))
    else:
        bot.send_message(uid, "❌ Invalid or Expired Key.")

# ------------------ CALLBACK ------------------
@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    uid = call.message.chat.id
    if not is_owner(uid):
        bot.answer_callback_query(call.id, "Unauthorized", show_alert=True)
        return
    cfg = get_owner(uid)
    d = call.data

    if d in ("add_msg", "edit_msg"):
        user_state[uid] = "collecting_dm"
        user_temp_msgs[uid] = []
        user_current_msg_idx[uid] = None
        bot.send_message(uid,
            "📝 *Send messages for DM.*\n\nType **SAVE** to store, **CANCEL** to abort.",
            parse_mode="Markdown")
        bot.answer_callback_query(call.id)

    elif d == "dlt_msg":
        update_owner(uid, {"dm_messages": []})
        bot.send_message(uid, "🗑️ *All DM messages deleted.*", parse_mode="Markdown")
        bot.answer_callback_query(call.id)

    elif d == "toggle":
        new_val = 0 if cfg['enabled'] else 1
        update_owner(uid, {"enabled": new_val})
        status = "ON" if new_val else "OFF"
        bot.send_message(uid, f"🔄 Auto-DM: *{status}*", parse_mode="Markdown")
        bot.answer_callback_query(call.id)

    elif d == "toggle_auto_approve":
        update_owner(uid, {"auto_approve": not cfg['auto_approve']})
        bot.answer_callback_query(call.id, "Toggled!")
        try:
            bot.edit_message_reply_markup(uid, call.message.message_id,
                reply_markup=main_menu_keyboard(get_owner(uid)))
        except Exception as e:
            print(f"edit err: {e}")

    elif d == "toggle_reject_premium":
        update_owner(uid, {"reject_premium": not cfg['reject_premium']})
        bot.answer_callback_query(call.id, "Toggled!")
        try:
            bot.edit_message_reply_markup(uid, call.message.message_id,
                reply_markup=main_menu_keyboard(get_owner(uid)))
        except Exception as e:
            print(f"edit err: {e}")

    elif d == "toggle_chn_premium":
        update_owner(uid, {"remove_premium_from_channel": not cfg['remove_premium_from_channel']})
        bot.answer_callback_query(call.id, "Toggled!")
        try:
            bot.edit_message_reply_markup(uid, call.message.message_id,
                reply_markup=main_menu_keyboard(get_owner(uid)))
        except Exception as e:
            print(f"edit err: {e}")

    elif d == "users_check":
        users = db_get(f'owners/{uid}/users_seen') or {}
        total = len(users)
        lines = [f"👥 <b>Total Users DM'd:</b> {total}\n"]
        for i, (uu, info) in enumerate(list(users.items())[:20], 1):
            name = info.get("name", "Unknown")
            un = info.get("username")
            lines.append(f"{i}. {name}" + (f" (@{un})" if un else "") + f" — <code>{uu}</code>")
        if total > 20:
            lines.append(f"\n...and {total-20} more.")
        tg_send(uid, "\n".join(lines))
        bot.answer_callback_query(call.id)

    elif d == "setup_delay":
        user_state[uid] = "awaiting_delay"
        bot.send_message(uid, "⏱️ Send delay in seconds (0–600):")
        bot.answer_callback_query(call.id)

    elif d in ("setup_msg_1", "setup_msg_2", "setup_msg_3"):
        slot = d[-1]
        user_state[uid] = f"collecting_slot_{slot}"
        user_temp_msgs[uid] = []
        user_current_msg_idx[uid] = None
        bot.send_message(uid,
            f"📝 Send content for *Message {slot}*.\n"
            f"Type *SAVE* to store, *CANCEL* to abort, *CLEAR* to remove.",
            parse_mode="Markdown")
        bot.answer_callback_query(call.id)

    elif d == "add_btn_yes":
        idx = user_current_msg_idx.get(uid)
        if idx is None or idx >= len(user_temp_msgs.get(uid, [])):
            bot.answer_callback_query(call.id, "No message.")
            return
        entry = user_temp_msgs[uid][idx]
        if len(entry.get("buttons", [])) >= 5:
            bot.send_message(uid, "⚠️ Max 5 buttons.")
            bot.answer_callback_query(call.id)
            return
        user_state[uid] = "button_text"
        bot.send_message(uid, "✏️ Send button text:")
        bot.answer_callback_query(call.id)

    elif d == "add_another_yes":
        idx = user_current_msg_idx.get(uid)
        if idx is None or idx >= len(user_temp_msgs.get(uid, [])):
            bot.answer_callback_query(call.id, "No message.")
            return
        entry = user_temp_msgs[uid][idx]
        if len(entry.get("buttons", [])) >= 5:
            bot.send_message(uid, "⚠️ Max 5 buttons.")
            user_state[uid] = "collecting_dm"
            bot.answer_callback_query(call.id)
            return
        user_state[uid] = "button_text"
        bot.send_message(uid, f"✏️ Send text for button #{len(entry['buttons'])+1}:")
        bot.answer_callback_query(call.id)

    elif d in ("add_btn_no", "add_another_no"):
        user_state[uid] = "collecting_dm"
        bot.send_message(uid, "👍 Send another message or type *SAVE*.", parse_mode="Markdown")
        bot.answer_callback_query(call.id)

    elif d in ("color_primary", "color_success", "color_danger", "color_none"):
        color = d.replace("color_", "")
        if color == "none":
            color = None
        user_temp_button_color[uid] = color
        user_state[uid] = "button_emoji"
        bot.send_message(uid,
            f"🎨 Color: *{color or 'default'}*\n\n"
            f"Send *Premium Emoji ID* or type `skip`:", parse_mode="Markdown")
        bot.answer_callback_query(call.id)

    elif d == "time":
        if not cfg['expiry']:
            bot.send_message(uid, "❌ No key.")
            bot.answer_callback_query(call.id)
            return
        rem = cfg['expiry'] - int(time.time())
        if rem <= 0:
            bot.send_message(uid, "⛔ Expired.")
        else:
            dd = rem // 86400
            hh = (rem % 86400) // 3600
            bot.send_message(uid,
                f"⏳ Active: *{dd}d {hh}h*\n📅 {datetime.fromtimestamp(cfg['expiry'])}",
                parse_mode="Markdown")
        bot.answer_callback_query(call.id)

    else:
        bot.answer_callback_query(call.id, "?")

# ------------------ DELAY ------------------
@bot.message_handler(func=lambda m: user_state.get(m.chat.id) == "awaiting_delay")
def handle_delay(m):
    uid = m.chat.id
    try:
        sec = int(m.text.strip())
        if sec < 0 or sec > 600:
            raise ValueError
    except ValueError:
        bot.send_message(uid, "❌ Send a number 0–600.")
        return
    update_owner(uid, {"delay_seconds": sec})
    user_state[uid] = None
    bot.send_message(uid, f"✅ Delay set: *{sec} sec*", parse_mode="Markdown",
                     reply_markup=main_menu_keyboard(get_owner(uid)))

# ------------------ BUTTON FLOW ------------------
@bot.message_handler(func=lambda m: user_state.get(m.chat.id) == "button_emoji")
def handle_button_emoji(m):
    uid = m.chat.id
    txt = m.text.strip()
    user_temp_button_emoji[uid] = None if txt.lower() == "skip" else txt
    user_state[uid] = "button_url"
    bot.send_message(uid, "🔗 Send the URL for this button:")

@bot.message_handler(func=lambda m: user_state.get(m.chat.id) == "button_text")
def handle_button_text(m):
    uid = m.chat.id
    txt = m.text.strip()
    if not txt:
        bot.send_message(uid, "❌ Cannot be empty.")
        return
    user_temp_button_text[uid] = txt
    bot.send_message(uid,
        f"✅ Text: *{txt}*\n\n🎨 Select color:", parse_mode="Markdown",
        reply_markup=color_selection_keyboard())

@bot.message_handler(func=lambda m: user_state.get(m.chat.id) == "button_url")
def handle_button_url(m):
    uid = m.chat.id
    url = m.text.strip()
    if not url.startswith(("http://", "https://")):
        bot.send_message(uid, "❌ Invalid URL.")
        return

    idx = user_current_msg_idx.get(uid)
    if idx is None or idx >= len(user_temp_msgs.get(uid, [])):
        bot.send_message(uid, "❌ No pending button.")
        user_state[uid] = "collecting_dm"
        return

    btn = {"text": user_temp_button_text.get(uid, "Button"), "url": url}
    c = user_temp_button_color.get(uid)
    e = user_temp_button_emoji.get(uid)
    if c:
        btn["style"] = c
    if e:
        btn["icon_custom_emoji_id"] = e

    entry = user_temp_msgs[uid][idx]
    entry.setdefault("buttons", []).append(btn)

    user_temp_button_text[uid] = None
    user_temp_button_color[uid] = None
    user_temp_button_emoji[uid] = None

    if len(entry["buttons"]) >= 5:
        bot.send_message(uid, "⚠️ Max 5 buttons reached.")
        user_state[uid] = "collecting_dm"
        return

    bot.send_message(uid, "✅ Button added. Add another?",
                     reply_markup=add_another_button_keyboard())

# ------------------ COLLECT DM ------------------
@bot.message_handler(
    content_types=['text', 'photo', 'video', 'document', 'sticker', 'voice', 'audio', 'animation'],
    func=lambda m: user_state.get(m.chat.id) in ("collecting_dm",)
    or (isinstance(user_state.get(m.chat.id), str) and user_state.get(m.chat.id, "").startswith("collecting_slot_"))
)
def handle_collect(m):
    uid = m.chat.id
    if not is_owner(uid):
        return
    text = (m.text or "").strip()

    if text.upper() == "SAVE":
        temp_list = user_temp_msgs.get(uid, [])
        if not temp_list:
            bot.send_message(uid, "⚠️ No messages.")
            return
        state = user_state.get(uid, "")
        if state.startswith("collecting_slot_"):
            slot = state[-1]
            update_owner(uid, {f"dm_messages/slot_{slot}": temp_list})
            bot.send_message(uid, f"✅ Saved to *Msg {slot}*!", parse_mode="Markdown")
        else:
            existing = get_owner(uid).get("dm_messages", [])
            if isinstance(existing, list):
                existing.extend(temp_list)
            else:
                existing = temp_list
            update_owner(uid, {"dm_messages": existing})
            bot.send_message(uid, f"✅ Saved {len(temp_list)} message(s)!")
        user_state[uid] = None
        user_temp_msgs[uid] = []
        user_current_msg_idx[uid] = None
        return

    if text.upper() == "CANCEL":
        user_state[uid] = None
        user_temp_msgs[uid] = []
        user_current_msg_idx[uid] = None
        bot.send_message(uid, "❌ Cancelled.")
        return

    if text.upper() == "CLEAR":
        state = user_state.get(uid, "")
        if state.startswith("collecting_slot_"):
            slot = state[-1]
            update_owner(uid, {f"dm_messages/slot_{slot}": None})
            bot.send_message(uid, f"🗑️ Cleared Msg {slot}.")
        return

    entry = {"chat_id": uid, "msg_id": m.message_id, "buttons": []}
    user_temp_msgs.setdefault(uid, []).append(entry)
    idx = len(user_temp_msgs[uid]) - 1
    user_current_msg_idx[uid] = idx

    bot.send_message(uid, f"📨 Message {idx+1} saved. Add a button?",
                     reply_markup=add_button_choice_keyboard())

# ------------------ MY_CHAT_MEMBER ------------------
@bot.my_chat_member_handler()
def handle_my_chat_member(update):
    new = update.new_chat_member
    old = update.old_chat_member
    chat = update.chat
    user = update.from_user

    if new.status == 'administrator' and old.status != 'administrator':
        if is_owner(user.id):
            assign_group(user.id, chat.id)
            print(f"✅ Group {chat.id} assigned to {user.id}")
    elif old.status == 'administrator' and new.status != 'administrator':
        if get_owner_by_chat(chat.id):
            remove_group(chat.id)
            print(f"🗑️ Group {chat.id} removed")

# ------------------ JOIN REQUEST ------------------
@bot.chat_join_request_handler()
def handle_join(req):
    user = req.from_user
    chat = req.chat
    chat_id = chat.id

    owner_id = get_owner_by_chat(chat_id)
    if not owner_id:
        print(f"⚠️ No owner for {chat_id}")
        return

    cfg = get_owner(owner_id)
    if not cfg or not cfg.get('enabled'):
        return

    if cfg.get('reject_premium'):
        is_prem = getattr(user, "is_premium", False)
        if is_prem:
            try:
                bot.decline_chat_join_request(chat_id, user.id)
            except Exception as e:
                print(f"decline err: {e}")
            return

    if cfg.get('auto_approve'):
        try:
            bot.approve_chat_join_request(chat_id, user.id)
        except Exception as e:
            print(f"approve err: {e}")

    if cfg.get('remove_premium_from_channel'):
        is_prem = getattr(user, "is_premium", False)
        if is_prem:
            try:
                bot.ban_chat_member(chat_id, user.id)
                print(f"🚫 Premium user {user.id} banned")
            except Exception as e:
                print(f"ban err: {e}")

    delay = int(cfg.get('delay_seconds', 0) or 0)
    if delay > 0:
        time.sleep(delay)

    dm_msgs = cfg.get('dm_messages', [])
    entries = []
    if isinstance(dm_msgs, list):
        entries = dm_msgs
    elif isinstance(dm_msgs, dict):
        for k in ("slot_1", "slot_2", "slot_3"):
            if dm_msgs.get(k):
                entries.extend(dm_msgs[k])

    for entry in entries:
        try:
            send_dm_content(user.id, entry, owner_id)
        except Exception as e:
            print(f"send_dm_content err: {e}")

    try:
        db_set(f"owners/{owner_id}/users_seen/{user.id}", {
            "name": user.first_name or "",
            "username": user.username or "",
            "ts": int(time.time())
        })
    except Exception as e:
        print(f"log err: {e}")

    print(f"📨 DM sent to {user.id}")

# ------------------ RUN ------------------
if __name__ == "__main__":
    print("🤖 JaatBot1 running (file storage)...")
    bot.infinity_polling(skip_pending=True)