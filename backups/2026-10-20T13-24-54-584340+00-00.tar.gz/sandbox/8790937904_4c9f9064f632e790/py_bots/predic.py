import logging
import requests
import random
import asyncio
import time
import sqlite3
import re
from collections import Counter
from datetime import datetime
from typing import List, Dict, Tuple, Optional, Union

from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup, MessageEntity, KeyboardButton
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters,
    ContextTypes, ConversationHandler, CallbackQueryHandler
)

# ========================================
# 🔧 CONFIGURATION
# ========================================
BOT_TOKEN = "8874199939:AAHofnO7h3RbHaR4hCzbA3paanVC9DtEXZw"
OWNER_USERNAME = "@crabhay"
OWNER_ID = 8790937904

# 📌 CHANNELS
CHANNELS = [
    {"id": -1004346685674, "link": "https://t.me/crabhay_bots", "name": "Channel 1"},
    {"id": -1004380885566, "link": "https://t.me/crabhay_bots", "name": "Channel 2"},
    {"id": -1003703297171, "link": "https://t.me/crabhay_bots", "name": "Channel 3"}
]

# 🎯 PREMIUM EMOJI IDs
PREMIUM_EMOJI_CALENDAR = "6172202676793643591"
PREMIUM_EMOJI_MONEY = "6267068789146260253"
PREMIUM_EMOJI_NUMBER = "6226410236425543060"
PREMIUM_EMOJI_STAR = "6224097418011484360"

# ✨ PREMIUM EMOJI IDs (UI Decoration)
PE_FIRE    = "6057591118017599641"
PE_BOLT    = "6226429830066348205"
PE_STAR    = "6224097418011484360"
PE_CALENDAR= "6172202676793643591"
PE_SPARKLE = "6174639095776547146"
PE_TARGET  = "6124987031861860234"
PE_DIAMOND = "5397782960512444700"
PE_TROPHY  = "6057459838047230701"
PE_SHINE   = "6057721277001504261"

# Sticker IDs
STICKER_WIN = "CAACAgUAAxkBA1CiFGpPLJ63FTqJu1fEbwOHfPlsFPetAAJDFAACPUMBVhgge585MfgCPAQ"
STICKER_LOSS = "CAACAgUAAxkBA1ClPGpPMEcusLppTnvwCjHwxhokaX2tAALCGAACTESYVT8HKk6Lfh0UPAQ"
STICKER_JACKPOT = "CAACAgUAAxkBA1ClMmpPMEAiRehlsLL-RmkggAtswuvOAAIHEwACxyT4VeQk0FjUc_LCPAQ"
SESSION_CLOSE_STICKER = "CAACAgUAAxkBA2GDN2pjPKZ5nIzq6urSR_LwNXNoAiaOAALaFAACb4WJVU3xBZOIkt3yPQQ"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ========================================
# 🗄️ DATABASE FUNCTIONS
# ========================================
def init_db():
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS user_targets (
                     id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER,
                     target_chat_id INTEGER,
                     target_title TEXT,
                     added_at TIMESTAMP
                   )''')
        c.execute('''CREATE TABLE IF NOT EXISTS prediction_cache (
                     id INTEGER PRIMARY KEY AUTOINCREMENT,
                     period TEXT,
                     prediction TEXT,
                     jackpot1 INTEGER,
                     jackpot2 INTEGER,
                     confidence REAL,
                     created_at TIMESTAMP
                   )''')
        c.execute('''CREATE TABLE IF NOT EXISTS user_sessions (
                     user_id INTEGER PRIMARY KEY,
                     target_wins INTEGER,
                     current_wins INTEGER DEFAULT 0,
                     status TEXT,
                     created_at TIMESTAMP
                   )''')
        c.execute('''CREATE TABLE IF NOT EXISTS historical_predictions (
                     id INTEGER PRIMARY KEY AUTOINCREMENT,
                     period TEXT,
                     actual_number INTEGER,
                     predicted_size TEXT,
                     predicted_jp1 INTEGER,
                     predicted_jp2 INTEGER,
                     result TEXT,
                     created_at TIMESTAMP
                   )''')
        c.execute('''CREATE TABLE IF NOT EXISTS custom_message (
                     id INTEGER PRIMARY KEY CHECK (id = 1),
                     template TEXT,
                     updated_at TIMESTAMP
                   )''')
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"DB init: {e}")
        return False

def save_prediction_history(period, actual_num, pred_size, jp1, jp2, result):
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("INSERT INTO historical_predictions (period, actual_number, predicted_size, predicted_jp1, predicted_jp2, result, created_at) VALUES (?,?,?,?,?,?,?)",
                  (period, actual_num, pred_size, jp1, jp2, result, datetime.now()))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Save history error: {e}")

def add_target(user_id: int, chat_id: int, title: str) -> bool:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("INSERT INTO user_targets (user_id, target_chat_id, target_title, added_at) VALUES (?,?,?,?)",
                  (user_id, chat_id, title, datetime.now()))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Add target error: {e}")
        return False

def remove_target(user_id: int, chat_id: int) -> bool:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("DELETE FROM user_targets WHERE user_id=? AND target_chat_id=?", (user_id, chat_id))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Remove target error: {e}")
        return False

def get_targets(user_id: int) -> List[Dict]:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("SELECT target_chat_id, target_title FROM user_targets WHERE user_id=?", (user_id,))
        rows = c.fetchall()
        conn.close()
        return [{"chat_id": r[0], "title": r[1]} for r in rows]
    except Exception as e:
        logger.error(f"Get targets error: {e}")
        return []

def get_all_targets() -> List[Dict]:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("SELECT user_id, target_chat_id, target_title FROM user_targets")
        rows = c.fetchall()
        conn.close()
        return [{"user_id": r[0], "chat_id": r[1], "title": r[2]} for r in rows]
    except Exception as e:
        logger.error(f"Get all targets error: {e}")
        return []

def get_all_users() -> List[int]:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("SELECT DISTINCT user_id FROM user_targets")
        rows = c.fetchall()
        conn.close()
        return [r[0] for r in rows]
    except Exception as e:
        logger.error(f"Get all users error: {e}")
        return []

def save_cache(period, pred, j1, j2, conf):
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("DELETE FROM prediction_cache WHERE period=?", (period,))
        c.execute("INSERT INTO prediction_cache (period, prediction, jackpot1, jackpot2, confidence, created_at) VALUES (?,?,?,?,?,?)",
                  (period, pred, j1, j2, conf, datetime.now()))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Save cache error: {e}")
        return False

def get_cache(period):
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("SELECT prediction, jackpot1, jackpot2, confidence FROM prediction_cache WHERE period=?", (period,))
        row = c.fetchone()
        conn.close()
        if row:
            return {"prediction": row[0], "jackpot1": row[1], "jackpot2": row[2], "confidence": row[3]}
        return None
    except Exception as e:
        logger.error(f"Get cache error: {e}")
        return None

def create_or_update_session(user_id: int, target_wins: int, status: str = 'active') -> bool:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("SELECT user_id FROM user_sessions WHERE user_id=?", (user_id,))
        row = c.fetchone()
        if row:
            c.execute("UPDATE user_sessions SET target_wins=?, current_wins=0, status=? WHERE user_id=?",
                      (target_wins, status, user_id))
        else:
            c.execute("INSERT INTO user_sessions (user_id, target_wins, current_wins, status, created_at) VALUES (?,?,?,?,?)",
                      (user_id, target_wins, 0, status, datetime.now()))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Create/update session error: {e}")
        return False

def get_user_session(user_id: int) -> Optional[Dict]:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("SELECT target_wins, current_wins, status FROM user_sessions WHERE user_id=?", (user_id,))
        row = c.fetchone()
        conn.close()
        if row:
            return {'target_wins': row[0], 'current_wins': row[1], 'status': row[2]}
        return None
    except Exception as e:
        logger.error(f"Get session error: {e}")
        return None

def update_user_wins(user_id: int, increment: int = 1) -> Tuple[Optional[int], Optional[int]]:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("UPDATE user_sessions SET current_wins = current_wins + ? WHERE user_id=? AND status='active'",
                  (increment, user_id))
        conn.commit()
        c.execute("SELECT current_wins, target_wins FROM user_sessions WHERE user_id=?", (user_id,))
        row = c.fetchone()
        conn.close()
        if row:
            return row[0], row[1]
        return None, None
    except Exception as e:
        logger.error(f"Update wins error: {e}")
        return None, None

def close_user_session(user_id: int) -> bool:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("UPDATE user_sessions SET status='closed' WHERE user_id=?", (user_id,))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Close session error: {e}")
        return False

def pause_user_session(user_id: int) -> bool:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("UPDATE user_sessions SET status='paused' WHERE user_id=?", (user_id,))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Pause session error: {e}")
        return False

def get_active_sessions() -> List[int]:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("SELECT user_id FROM user_sessions WHERE status='active'")
        rows = c.fetchall()
        conn.close()
        return [r[0] for r in rows]
    except Exception as e:
        logger.error(f"Get active sessions error: {e}")
        return []

# ========================================
# ✉️ CUSTOM MESSAGE FUNCTIONS
# ========================================
DEFAULT_MESSAGE = (
    "👑 𝗪𝗜𝗡 𝗚𝗢 𝟭 𝗠𝗜𝗡𝗨𝗧𝗘💰\n"
    "\n"
    "🔴 {period}➡️ IN LIVE"
)

def save_custom_message(template: str) -> bool:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("DELETE FROM custom_message")
        c.execute("INSERT INTO custom_message (id, template, updated_at) VALUES (1, ?, ?)",
                  (template, datetime.now()))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Save message error: {e}")
        return False

def get_custom_message() -> str:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("SELECT template FROM custom_message WHERE id=1")
        row = c.fetchone()
        conn.close()
        if row and row[0]:
            return row[0]
        return DEFAULT_MESSAGE
    except Exception as e:
        logger.error(f"Get message error: {e}")
        return DEFAULT_MESSAGE

def reset_custom_message() -> bool:
    try:
        conn = sqlite3.connect('bot_data.db')
        c = conn.cursor()
        c.execute("DELETE FROM custom_message")
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Reset message error: {e}")
        return False

# ========================================
# 🤖 GLOBAL STATE
# ========================================
ADD_CHAT = 1
BROADCAST = 2
SET_TARGET = 3
SET_MESSAGE = 4

access_cache = {}
ACCESS_CACHE_TIMEOUT = 3600
sent_periods = set()

# ========================================
# 🌐 API
# ========================================
WIN_GO_URL = "https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json"

def fetch_wingo_data(limit=50, retries=3):
    for attempt in range(retries):
        try:
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            url = f"{WIN_GO_URL}?t={int(datetime.now().timestamp()*1000)}"
            resp = requests.get(url, timeout=8, headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                if data and 'data' in data and 'list' in data['data']:
                    return data['data']['list'][:limit]
        except Exception as e:
            logger.error(f"Fetch wingo data attempt {attempt+1}: {e}")
        time.sleep(1)
    return None

def number_to_size(num: int) -> str:
    return "BIG" if num >= 5 else "SMALL"

# ========================================
# 🧠 PREDICTOR CLASS
# ========================================
class WinGoPredictor:
    def __init__(self):
        self.last_issue = None
        self.current_prediction = None
        self.total_wins = 0
        self.total_losses = 0
        self.total_jackpots = 0
        self.last_result = None
        self.history_numbers = []
        self.history_sizes = []
        self.history_full_data = []
        self.pattern_cache = {}
        self.accuracy_history = []
        self._lock = asyncio.Lock()
        
        self.weights = {
            'trend': 0.30,
            'pattern': 0.25,
            'frequency': 0.15,
            'streak': 0.10,
            'momentum': 0.10,
            'seasonal': 0.05,
            'markov': 0.05
        }
        
        self.transition_matrix = {'BIG': {'BIG': 0, 'SMALL': 0}, 'SMALL': {'BIG': 0, 'SMALL': 0}}
        self.last_size = None
        
    def update_history(self, data):
        self.history_numbers = []
        self.history_sizes = []
        self.history_full_data = []
        
        for item in data:
            if 'number' in item:
                num = int(item['number'])
                self.history_numbers.append(num)
                self.history_sizes.append(number_to_size(num))
                self.history_full_data.append({
                    'number': num,
                    'size': number_to_size(num),
                    'period': item.get('issueNumber', '')
                })
        
        self.history_numbers = self.history_numbers[:50]
        self.history_sizes = self.history_sizes[:50]
        self.history_full_data = self.history_full_data[:50]
        self.pattern_cache = {}
        self.update_markov_matrix()

    def update_markov_matrix(self):
        if len(self.history_sizes) < 2:
            return
        
        self.transition_matrix = {'BIG': {'BIG': 0, 'SMALL': 0}, 'SMALL': {'BIG': 0, 'SMALL': 0}}
        
        for i in range(len(self.history_sizes) - 1):
            current = self.history_sizes[i]
            next_size = self.history_sizes[i + 1]
            self.transition_matrix[current][next_size] += 1
        
        for state in self.transition_matrix:
            total = sum(self.transition_matrix[state].values())
            if total > 0:
                for next_state in self.transition_matrix[state]:
                    self.transition_matrix[state][next_state] /= total
        
        if self.history_sizes:
            self.last_size = self.history_sizes[0]

    def analyze_trend(self) -> Dict:
        if len(self.history_sizes) < 5:
            return {'trend': 'neutral', 'strength': 0, 'confidence': 0}
        
        windows = [5, 10, 15, 20]
        trend_signals = []
        
        for window in windows:
            if len(self.history_sizes) >= window:
                recent = self.history_sizes[:window]
                big_count = sum(1 for s in recent if s == 'BIG')
                small_count = window - big_count
                
                if big_count > small_count:
                    strength = (big_count - small_count) / window
                    trend_signals.append(('BIG', strength))
                elif small_count > big_count:
                    strength = (small_count - big_count) / window
                    trend_signals.append(('SMALL', strength))
        
        if not trend_signals:
            return {'trend': 'neutral', 'strength': 0, 'confidence': 0}
        
        big_weight = 0
        small_weight = 0
        for trend, strength in trend_signals:
            if trend == 'BIG':
                big_weight += strength
            else:
                small_weight += strength
        
        if big_weight > small_weight:
            trend = 'BIG'
            strength = big_weight / len(trend_signals)
        elif small_weight > big_weight:
            trend = 'SMALL'
            strength = small_weight / len(trend_signals)
        else:
            trend = 'neutral'
            strength = 0
        
        confidence = min(0.5 + strength * 0.5, 0.9)
        
        return {'trend': trend, 'strength': strength, 'confidence': confidence}

    def detect_patterns(self) -> Dict:
        if len(self.history_sizes) < 10:
            return {'pattern': None, 'confidence': 0}
        
        patterns_found = []
        
        if len(self.history_sizes) >= 6:
            last_6 = self.history_sizes[:6]
            is_alternating = all(last_6[i] != last_6[i+1] for i in range(5))
            if is_alternating:
                patterns_found.append(('SMALL' if last_6[0] == 'BIG' else 'BIG', 0.75))
        
        if len(self.history_sizes) >= 8:
            seq = ''.join(['B' if s == 'BIG' else 'S' for s in self.history_sizes[:8]])
            if seq[:4] == seq[4:]:
                patterns_found.append((self.history_sizes[4], 0.70))
        
        if len(self.history_sizes) >= 12:
            seq = ''.join(['B' if s == 'BIG' else 'S' for s in self.history_sizes[:12]])
            if seq[:6] == seq[6:]:
                patterns_found.append((self.history_sizes[6], 0.65))
        
        if not patterns_found:
            return {'pattern': None, 'confidence': 0}
        
        pattern_counts = {}
        for pattern, conf in patterns_found:
            if pattern not in pattern_counts:
                pattern_counts[pattern] = 0
            pattern_counts[pattern] += conf
        
        best_pattern = max(pattern_counts, key=pattern_counts.get)
        avg_confidence = pattern_counts[best_pattern] / len(patterns_found)
        
        return {'pattern': best_pattern, 'confidence': avg_confidence}

    def analyze_frequency(self) -> Dict:
        if not self.history_numbers:
            return {'hot_numbers': [], 'cold_numbers': [], 'bias': 0, 'confidence': 0}
        
        recent = self.history_numbers[:30]
        counter = Counter(recent)
        expected = len(recent) / 10
        
        hot_numbers = []
        cold_numbers = []
        for num in range(10):
            freq = counter.get(num, 0)
            deviation = (freq - expected) / expected if expected > 0 else 0
            if deviation > 0.5:
                hot_numbers.append(num)
            elif deviation < -0.3:
                cold_numbers.append(num)
        
        big_freq = sum(1 for n in recent if n >= 5)
        small_freq = len(recent) - big_freq
        bias = (big_freq - small_freq) / len(recent) if recent else 0
        confidence = min(0.5 + len(recent) / 60, 0.85)
        
        return {
            'hot_numbers': hot_numbers,
            'cold_numbers': cold_numbers,
            'bias': bias,
            'confidence': confidence
        }

    def analyze_streaks(self) -> Dict:
        if not self.history_sizes:
            return {'current_streak': 0, 'streak_type': None, 'break_probability': 0}
        
        current_streak = 0
        streak_type = None
        
        for size in self.history_sizes:
            if streak_type is None:
                streak_type = size
                current_streak = 1
            elif size == streak_type:
                current_streak += 1
            else:
                break
        
        if current_streak == 0:
            return {'current_streak': 0, 'streak_type': None, 'break_probability': 0}
        
        historical_breaks = {
            1: 0.52,
            2: 0.48,
            3: 0.60,
            4: 0.65,
            5: 0.70,
            6: 0.75,
            7: 0.80,
            8: 0.85,
        }
        
        break_prob = historical_breaks.get(current_streak, 0.90)
        predicted = 'SMALL' if streak_type == 'BIG' else 'BIG'
        
        return {
            'current_streak': current_streak,
            'streak_type': streak_type,
            'prediction': predicted,
            'break_probability': break_prob,
            'confidence': break_prob
        }

    def analyze_momentum(self) -> Dict:
        if len(self.history_numbers) < 15:
            return {'momentum': 0, 'prediction': None, 'confidence': 0}
        
        ma_5 = sum(self.history_numbers[:5]) / 5
        ma_10 = sum(self.history_numbers[:10]) / 10
        ma_15 = sum(self.history_numbers[:15]) / 15
        
        momentum_5_10 = ma_5 - ma_10
        momentum_10_15 = ma_10 - ma_15
        momentum = (momentum_5_10 * 0.6 + momentum_10_15 * 0.4)
        momentum_strength = abs(momentum) / 9
        
        if abs(momentum) > 0.3:
            predicted = 'BIG' if momentum > 0 else 'SMALL'
            confidence = min(0.5 + momentum_strength * 0.4, 0.8)
            return {
                'momentum': momentum,
                'prediction': predicted,
                'confidence': confidence
            }
        
        return {'momentum': momentum, 'prediction': None, 'confidence': 0}

    def markov_prediction(self) -> Dict:
        if not self.last_size or self.last_size not in self.transition_matrix:
            return {'prediction': None, 'confidence': 0}
        
        transitions = self.transition_matrix[self.last_size]
        if transitions['BIG'] == 0 and transitions['SMALL'] == 0:
            return {'prediction': None, 'confidence': 0}
        
        if transitions['BIG'] > transitions['SMALL']:
            return {'prediction': 'BIG', 'confidence': transitions['BIG']}
        elif transitions['SMALL'] > transitions['BIG']:
            return {'prediction': 'SMALL', 'confidence': transitions['SMALL']}
        
        return {'prediction': None, 'confidence': 0}

    def get_comprehensive_prediction(self) -> Dict:
        if len(self.history_sizes) < 5:
            return self.get_basic_prediction()
        
        predictions = []
        total_weight = 0
        
        trend = self.analyze_trend()
        if trend['trend'] != 'neutral' and trend['confidence'] > 0.5:
            predictions.append({
                'prediction': trend['trend'],
                'weight': self.weights['trend'] * trend['confidence']
            })
            total_weight += self.weights['trend']
        
        pattern = self.detect_patterns()
        if pattern['pattern'] and pattern['confidence'] > 0.5:
            predictions.append({
                'prediction': pattern['pattern'],
                'weight': self.weights['pattern'] * pattern['confidence']
            })
            total_weight += self.weights['pattern']
        
        freq = self.analyze_frequency()
        if abs(freq['bias']) > 0.1 and freq['confidence'] > 0.5:
            pred = 'BIG' if freq['bias'] > 0 else 'SMALL'
            predictions.append({
                'prediction': pred,
                'weight': self.weights['frequency'] * min(freq['confidence'], 0.8)
            })
            total_weight += self.weights['frequency']
        
        streak = self.analyze_streaks()
        if streak['prediction'] and streak['confidence'] > 0.5:
            predictions.append({
                'prediction': streak['prediction'],
                'weight': self.weights['streak'] * streak['confidence']
            })
            total_weight += self.weights['streak']
        
        momentum = self.analyze_momentum()
        if momentum['prediction'] and momentum['confidence'] > 0.5:
            predictions.append({
                'prediction': momentum['prediction'],
                'weight': self.weights['momentum'] * momentum['confidence']
            })
            total_weight += self.weights['momentum']
        
        markov = self.markov_prediction()
        if markov['prediction'] and markov['confidence'] > 0.5:
            predictions.append({
                'prediction': markov['prediction'],
                'weight': self.weights['markov'] * markov['confidence']
            })
            total_weight += self.weights['markov']
        
        if not predictions or total_weight == 0:
            return self.get_basic_prediction()
        
        big_score = 0
        small_score = 0
        
        for p in predictions:
            if p['prediction'] == 'BIG':
                big_score += p['weight']
            else:
                small_score += p['weight']
        
        big_score = big_score / total_weight
        small_score = small_score / total_weight
        
        min_confidence = 0.45
        if big_score > small_score and big_score >= min_confidence:
            prediction = 'BIG'
            confidence = min(big_score, 0.85)
        elif small_score > big_score and small_score >= min_confidence:
            prediction = 'SMALL'
            confidence = min(small_score, 0.85)
        else:
            trend_result = self.analyze_trend()
            if trend_result['trend'] != 'neutral':
                prediction = trend_result['trend']
                confidence = trend_result['confidence']
            else:
                if self.history_numbers:
                    avg = sum(self.history_numbers[:10]) / 10
                    prediction = 'BIG' if avg >= 4.5 else 'SMALL'
                    confidence = 0.5 + abs(avg - 4.5) / 9 * 0.3
                else:
                    prediction = 'BIG'
                    confidence = 0.5
        
        jackpot_numbers = self.calculate_hot_numbers(prediction)
        
        return {
            'prediction': prediction,
            'confidence': confidence,
            'jackpot1': jackpot_numbers[0],
            'jackpot2': jackpot_numbers[1]
        }

    def calculate_hot_numbers(self, prediction: str = None) -> List[int]:
        if prediction == 'BIG':
            pool = [5, 6, 7, 8, 9]
        elif prediction == 'SMALL':
            pool = [0, 1, 2, 3, 4]
        else:
            pool = list(range(10))
        
        if not self.history_numbers:
            selected = random.sample(pool, min(2, len(pool)))
            while len(selected) < 2:
                num = random.choice(pool)
                if num not in selected:
                    selected.append(num)
            return selected[:2]
        
        counter = Counter(self.history_numbers[:30])
        filtered_numbers = {num: count for num, count in counter.items() if num in pool}
        
        if not filtered_numbers:
            filtered_numbers = {num: counter.get(num, 0) for num in pool}
        
        sorted_numbers = sorted(filtered_numbers.items(), key=lambda x: x[1], reverse=True)
        top_numbers = [num for num, _ in sorted_numbers[:4]]
        
        while len(top_numbers) < 2:
            candidate = random.choice(pool)
            if candidate not in top_numbers:
                top_numbers.append(candidate)
        
        return top_numbers[:2]

    def get_basic_prediction(self) -> Dict:
        if len(self.history_sizes) < 3:
            if self.history_sizes:
                count = Counter(self.history_sizes)
                if count.get('BIG', 0) > count.get('SMALL', 0):
                    pred = 'BIG'
                    confidence = 0.55
                elif count.get('SMALL', 0) > count.get('BIG', 0):
                    pred = 'SMALL'
                    confidence = 0.55
                else:
                    pred = 'BIG'
                    confidence = 0.5
            else:
                pred = 'BIG'
                confidence = 0.5
        else:
            big = sum(1 for s in self.history_sizes if s == 'BIG')
            small = len(self.history_sizes) - big
            
            if big > small:
                pred = 'BIG'
                confidence = 0.5 + (big / len(self.history_sizes)) * 0.3
            elif small > big:
                pred = 'SMALL'
                confidence = 0.5 + (small / len(self.history_sizes)) * 0.3
            else:
                pred = 'BIG'
                confidence = 0.5
        
        jackpot_numbers = self.calculate_hot_numbers(pred)
        
        return {
            'prediction': pred,
            'confidence': min(confidence, 0.8),
            'jackpot1': jackpot_numbers[0],
            'jackpot2': jackpot_numbers[1]
        }

    def extract_period_number(self, issue_str):
        try:
            match = re.search(r'(\d{4})$', issue_str)
            if match:
                return int(match.group(1))
            digits = re.findall(r'\d+', issue_str)
            if digits:
                return int(digits[-1][-4:]) if len(digits[-1]) >= 4 else int(digits[-1])
        except Exception:
            pass
        return 0

    def generate_next_period_str(self, current_issue):
        if not current_issue:
            return datetime.now().strftime("%Y%m%d%H%M")
        try:
            prefix = current_issue[:-4] if len(current_issue) >= 4 else ""
            last_num = self.extract_period_number(current_issue)
            next_num = last_num + 1
            next_str = f"{next_num:04d}"
            return prefix + next_str
        except Exception:
            return datetime.now().strftime("%Y%m%d%H%M")

    def get_display_period(self, full_period):
        return full_period[-4:] if len(full_period) >= 4 else full_period

    async def update_and_get_result(self):
        async with self._lock:
            data = fetch_wingo_data()
            if not data:
                if self.current_prediction:
                    return self.last_result, self.current_prediction
                fallback = self.get_comprehensive_prediction()
                fallback_period = datetime.now().strftime("%Y%m%d%H%M")
                fallback['period'] = self.get_display_period(fallback_period)
                save_cache(fallback_period, fallback['prediction'], fallback['jackpot1'], fallback['jackpot2'], fallback['confidence'])
                return None, fallback
            
            try:
                latest = data[0]
                issue = latest['issueNumber']
                current_number = int(latest['number'])
                result = None
                
                self.update_history(data)
                
                if self.last_issue and self.last_issue != issue and self.current_prediction:
                    actual_size = number_to_size(current_number)
                    pred = self.current_prediction
                    jackpot = (current_number == pred['jackpot1'] or current_number == pred['jackpot2'])
                    is_win = (jackpot or actual_size == pred['prediction'])
                    status = "JACKPOT" if jackpot else ("WIN" if is_win else "LOSS")
                    
                    save_prediction_history(
                        self.last_issue, 
                        current_number, 
                        pred['prediction'], 
                        pred['jackpot1'], 
                        pred['jackpot2'], 
                        status
                    )
                    
                    if status == "JACKPOT":
                        self.total_wins += 1
                        self.total_jackpots += 1
                    elif status == "WIN":
                        self.total_wins += 1
                    else:
                        self.total_losses += 1
                    
                    self.accuracy_history.append(1 if status in ['WIN', 'JACKPOT'] else 0)
                    if len(self.accuracy_history) > 100:
                        self.accuracy_history = self.accuracy_history[-100:]
                    
                    result = {
                        "period": self.get_display_period(self.last_issue),
                        "number": current_number,
                        "size": actual_size,
                        "status": status
                    }
                    self.last_result = result
                
                self.last_issue = issue
                
                pred = self.get_comprehensive_prediction()
                next_full_period = self.generate_next_period_str(issue)
                pred['period'] = self.get_display_period(next_full_period)
                
                save_cache(next_full_period, pred['prediction'], pred['jackpot1'], pred['jackpot2'], pred['confidence'])
                
                self.current_prediction = pred
                logger.info(f"Generated prediction for period {pred['period']} with confidence {pred['confidence']:.2f}")
                return result, pred
                
            except Exception as e:
                logger.error(f"Update error: {e}")
                if self.current_prediction:
                    return self.last_result, self.current_prediction
                fallback = self.get_comprehensive_prediction()
                fallback_period = datetime.now().strftime("%Y%m%d%H%M")
                fallback['period'] = self.get_display_period(fallback_period)
                return None, fallback

    def get_stats(self):
        active_users_count = len(get_active_sessions())
        accuracy = 0
        if self.accuracy_history:
            accuracy = sum(self.accuracy_history) / len(self.accuracy_history)
        
        return {
            "wins": self.total_wins,
            "losses": self.total_losses,
            "jackpots": self.total_jackpots,
            "total": self.total_wins + self.total_losses,
            "users": active_users_count,
            "accuracy": accuracy
        }

predictor = WinGoPredictor()

# ========================================
# 🎨 FORMATTER - WITH PREMIUM EMOJI ENTITIES
# ========================================
def create_confidence_bar(conf):
    filled = int(conf * 10)
    return "█" * filled + "░" * (10 - filled)

def _utf16_len(ch: str) -> int:
    return 2 if ord(ch) > 0xFFFF else 1

def apply_premium_entities(text: str, emoji_map: Dict[str, str]) -> Tuple[str, List[MessageEntity]]:
    total_utf16 = sum(_utf16_len(ch) for ch in text)

    entities: List[MessageEntity] = [
        MessageEntity(type=MessageEntity.BOLD, offset=0, length=total_utf16)
    ]

    utf16_offset = 0
    for ch in text:
        char_utf16_len = _utf16_len(ch)
        if ch in emoji_map:
            entities.append(
                MessageEntity(
                    type=MessageEntity.CUSTOM_EMOJI,
                    offset=utf16_offset,
                    length=char_utf16_len,
                    custom_emoji_id=emoji_map[ch]
                )
            )
        utf16_offset += char_utf16_len
    return text, entities

def build_bold_message(text: str) -> Tuple[str, List[MessageEntity]]:
    total_utf16 = sum(_utf16_len(ch) for ch in text)
    return text, [MessageEntity(type=MessageEntity.BOLD, offset=0, length=total_utf16)]

UI_EMOJI_MAP: Dict[str, str] = {
    '🔥': PE_FIRE,
    '⚡': PE_BOLT,
    '🌟': PE_STAR,
    '📅': PE_CALENDAR,
    '💫': PE_SPARKLE,
    '🎯': PE_TARGET,
    '💎': PE_DIAMOND,
    '🏆': PE_TROPHY,
    '✨': PE_SHINE,
}

def build_ui_message(text: str) -> Tuple[str, List[MessageEntity]]:
    return apply_premium_entities(text, UI_EMOJI_MAP)

# ========================================
# ✉️ BUILD CUSTOM PREDICTION MESSAGE
# ========================================
def build_custom_prediction(next_pred) -> Tuple[str, List[MessageEntity]]:
    """
    Custom message use karta hai.
    Sirf {period} auto-replace hota hai.
    Baaki sab kuch exactly wahi rehta hai jo owner ne set kiya.
    """
    template = get_custom_message()
    
    # Sirf {period} replace karo — agar nahi hai to bhi koi issue nahi
    filled = template.replace("{period}", str(next_pred.get('period', '')))
    
    # Premium emoji map
    emoji_map = {
        '👑': PE_TROPHY,
        '💰': PREMIUM_EMOJI_MONEY,
        '🔴': PE_FIRE,
        '🟢': PE_SHINE,
        '🔢': PREMIUM_EMOJI_NUMBER,
        '🌟': PREMIUM_EMOJI_STAR,
        '📅': PREMIUM_EMOJI_CALENDAR,
        '✨': PE_SHINE,
        '🔥': PE_FIRE,
        '⚡': PE_BOLT,
        '💎': PE_DIAMOND,
        '🏆': PE_TROPHY,
        '🎯': PE_TARGET,
        '💫': PE_SPARKLE,
        '⭐': PE_STAR,
    }
    
    return apply_premium_entities(filled, emoji_map)

# ========================================
# 🔘 KEYBOARDS
# ========================================
def get_reply_keyboard() -> ReplyKeyboardMarkup:
    keyboard = [
        [
            KeyboardButton("🟢 Primary", style="success"),
            KeyboardButton("✅ Success", style="primary")
        ],
        [
            KeyboardButton("🔴 Danger", style="danger"),
            KeyboardButton("📊 Stats", style="primary")
        ],
        [
            KeyboardButton("📢 My Channels", style="primary"),
            KeyboardButton("➕ Add Channel", style="primary")
        ],
        [
            KeyboardButton("❓ Help", style="success"),
            KeyboardButton("ℹ️ About", style="primary"),
            KeyboardButton("📶 Ping", style="primary")
        ],
        [
            KeyboardButton("📢 Broadcast", style="danger")
        ]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_colored_button(text: str, callback_data: str, color: str = None) -> InlineKeyboardButton:
    button = InlineKeyboardButton(text=text, callback_data=callback_data)
    if color:
        button.color = color
    return button

def get_channel_join_keyboard(channels: List[Dict]) -> InlineKeyboardMarkup:
    keyboard = []
    
    keyboard.append([
        get_colored_button(
            text="📢 Ch 2 🔥",
            callback_data="channel_2",
            color="primary"
        ),
        get_colored_button(
            text="📢 Ch 3 ⚡",
            callback_data="channel_3",
            color="primary"
        )
    ])
    
    keyboard.append([
        get_colored_button(
            text="⭐ JOIN CHANNEL 1 ⭐",
            callback_data="channel_1",
            color="success"
        )
    ])
    
    keyboard.append([
        get_colored_button(
            text="✅ Verify Membership 🏆",
            callback_data="verify_membership",
            color="primary"
        )
    ])
    
    return InlineKeyboardMarkup(keyboard)

def get_verified_success_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [
            get_colored_button(
                text="🚀 Go to Bot 💫",
                callback_data="go_to_bot",
                color="success"
            )
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

# ========================================
# 🤖 HANDLERS
# ========================================

async def check_all_memberships(user_id: int, bot) -> Tuple[bool, List[Dict]]:
    missing = []
    for ch in CHANNELS:
        try:
            member = await bot.get_chat_member(chat_id=ch["id"], user_id=user_id)
            if member.status not in ['member', 'administrator', 'creator']:
                missing.append(ch)
        except Exception:
            missing.append(ch)
    return len(missing) == 0, missing

def clear_old_cache():
    current_time = time.time()
    keys_to_remove = []
    for key, value in access_cache.items():
        if current_time - value > ACCESS_CACHE_TIMEOUT:
            keys_to_remove.append(key)
    for key in keys_to_remove:
        del access_cache[key]

async def send_prediction_to_user(user_id: int, context: ContextTypes.DEFAULT_TYPE, result=None, next_pred=None):
    if not next_pred:
        return
    
    targets = get_targets(user_id)
    if not targets:
        return
    
    sticker_id = None
    if result:
        if result['status'] == "JACKPOT":
            sticker_id = STICKER_JACKPOT
        elif result['status'] == "WIN":
            sticker_id = STICKER_WIN
        elif result['status'] == "LOSS":
            sticker_id = STICKER_LOSS
    
    text, entities = build_custom_prediction(next_pred)
    
    sent_chats = set()
    for t in targets:
        chat_id = t['chat_id']
        if chat_id in sent_chats:
            continue
        sent_chats.add(chat_id)
        
        try:
            if sticker_id:
                try:
                    await context.bot.send_sticker(chat_id=chat_id, sticker=sticker_id)
                    await asyncio.sleep(0.1)
                except Exception:
                    pass
            
            await context.bot.send_message(
                chat_id=chat_id, 
                text=text,
                entities=entities
            )
            await asyncio.sleep(0.15)
        except Exception as e:
            logger.error(f"Send failed to {chat_id}: {e}")
    
    try:
        if sticker_id:
            try:
                await context.bot.send_sticker(chat_id=user_id, sticker=sticker_id)
                await asyncio.sleep(0.1)
            except Exception:
                pass
        
        await context.bot.send_message(
            chat_id=user_id, 
            text=text,
            entities=entities
        )
    except Exception as e:
        logger.error(f"DM send failed: {e}")

# ========================================
# 📍 START HANDLER
# ========================================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    clear_old_cache()

    if user_id in access_cache:
        txt, ents = build_ui_message(
            "✨ Welcome back! ✨\n"
            "\n"
            "🌟 You are already verified!\n"
            "\n"
            "🎯 Click 'Primary' to begin receiving predictions."
        )
        await update.message.reply_text(txt, entities=ents, reply_markup=get_reply_keyboard())
        return

    joined, missing = await check_all_memberships(user_id, context.bot)
    
    if joined:
        access_cache[user_id] = time.time()
        txt, ents = build_ui_message(
            "🏆 Access Granted! 🏆\n"
            "\n"
            "💎 You have joined all required channels.\n"
            "\n"
            "🎯 Click 'Primary' to begin receiving predictions."
        )
        await update.message.reply_text(txt, entities=ents, reply_markup=get_reply_keyboard())
        return

    raw = (
        "🔥 ACCESS REQUIRED 🔥\n"
        "\n"
        "⚠️ You must join ALL channels below to use this bot:\n"
        "\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "\n"
        "💎 Required Channels:\n"
        "\n"
        "⚡ Channel 2  -  VIP Channel\n"
        "⚡ Channel 3  -  Bonus Channel\n"
        "🌟 Channel 1  -  Main Channel\n"
        "\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "\n"
        "🏆 After joining all channels, click Verify Membership button below."
    )
    txt, ents = build_ui_message(raw)
    await update.message.reply_text(
        txt, entities=ents,
        reply_markup=get_channel_join_keyboard(CHANNELS),
        disable_web_page_preview=True
    )

async def verify_membership_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    if user_id in access_cache:
        t1, e1 = build_ui_message(
            "✨ Already Verified! ✨\n"
            "\n"
            "🏆 You already have access to the bot."
        )
        await query.edit_message_text(t1, entities=e1, reply_markup=get_verified_success_keyboard())
        return

    joined, missing = await check_all_memberships(user_id, context.bot)

    if joined:
        access_cache[user_id] = time.time()
        t2, e2 = build_ui_message(
            "🏆 Verification Successful! 🏆\n"
            "\n"
            "✨ You have joined all required channels!\n"
            "\n"
            "🔥 Click below to start using the bot."
        )
        await query.edit_message_text(t2, entities=e2, reply_markup=get_verified_success_keyboard())
    else:
        lines = (
            "🔥 Verification Failed 🔥\n"
            "\n"
            "⚠️ You have NOT joined all required channels.\n"
            "\n"
            "💎 Missing channels:\n"
        )
        for ch in missing:
            lines += f"⚡ {ch['name']}  -  {ch['link']}\n"
        lines += "\n🏆 Please join all channels and click Verify again."
        t3, e3 = build_ui_message(lines)
        await query.edit_message_text(
            t3, entities=e3,
            reply_markup=get_channel_join_keyboard(CHANNELS),
            disable_web_page_preview=True
        )

async def go_to_bot_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    if user_id not in access_cache:
        t0, e0 = build_bold_message("⚠️ Access Denied\n\nPlease verify your membership first.")
        await query.edit_message_text(t0, entities=e0)
        return
    
    await query.message.delete()

    txt, ents = build_ui_message(
        "🏆 Welcome to MARCO BHAI VIP PREDICTOR! 🏆\n"
        "\n"
        "💎 Use the buttons below to get started.\n"
        "\n"
        "🎯 Click 'Primary' to set your win target!"
    )
    await context.bot.send_message(
        chat_id=user_id,
        text=txt,
        entities=ents,
        reply_markup=get_reply_keyboard()
    )

async def show_session_progress(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    session = get_user_session(user_id)
    if not session:
        txt, ents = build_ui_message(
            "🔥 No Active Session 🔥\n"
            "\n"
            "🎯 Press 'Primary' to start a new session."
        )
    else:
        status = session['status']
        current = session['current_wins']
        target = session['target_wins']
        progress = f"{current}/{target}"
        progress_percent = (current / target * 100) if target > 0 else 0

        filled = int(progress_percent / 10)
        bar = "▓" * filled + "░" * (10 - filled)

        status_emoji = "✨" if status == 'active' else "🔥"
        status_text = "ACTIVE" if status == 'active' else "PAUSED"

        raw = (
            f"🏆 Session Progress 🏆\n"
            f"\n"
            f"🎯 Target  : {target} wins\n"
            f"✨ Achieved: {current} wins\n"
            f"⚡ Progress: {progress} ({progress_percent:.0f}%)\n"
            f"{bar}\n"
            f"\n"
            f"{status_emoji} Status: {status_text}\n"
            f"\n"
            f"💫 Press 'Danger' to pause/reset session."
        )
        txt, ents = build_ui_message(raw)

    await update.message.reply_text(txt, entities=ents, reply_markup=get_reply_keyboard())

async def handle_menu_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text

    clear_old_cache()
    if user_id not in access_cache:
        joined, missing = await check_all_memberships(user_id, context.bot)
        if joined:
            access_cache[user_id] = time.time()
        else:
            t0, e0 = build_bold_message("⚠️ Please /start first and join all required channels.")
            await update.message.reply_text(t0, entities=e0)
            return

    # 🟢 Primary
    if text in ["🟢 Primary", "Primary"]:
        await start_target(update, context)
        return

    # ✅ Success
    if text in ["✅ Success", "Success"]:
        await show_session_progress(update, context)
        return

    # 🔴 Danger
    if text in ["🔴 Danger", "Danger"]:
        session = get_user_session(user_id)
        if not session:
            t0, e0 = build_bold_message("❌ No active session to pause.")
            await update.message.reply_text(t0, entities=e0, reply_markup=get_reply_keyboard())
            return

        if session['status'] == 'paused':
            if create_or_update_session(user_id, session['target_wins'], 'active'):
                t1, e1 = build_ui_message("✨ Session resumed! Predictions will start again.")
                await update.message.reply_text(t1, entities=e1, reply_markup=get_reply_keyboard())
            else:
                t2, e2 = build_bold_message("❌ Error resuming session.")
                await update.message.reply_text(t2, entities=e2, reply_markup=get_reply_keyboard())
        else:
            if pause_user_session(user_id):
                t3, e3 = build_ui_message("💫 Session paused. Press Danger again to resume.")
                await update.message.reply_text(t3, entities=e3, reply_markup=get_reply_keyboard())
            else:
                t4, e4 = build_bold_message("❌ Error pausing session.")
                await update.message.reply_text(t4, entities=e4, reply_markup=get_reply_keyboard())
        return

    # 📊 Stats
    if text in ["📊 Stats", "Stats"]:
        s = predictor.get_stats()
        raw = (
            f"🏆 STATISTICS 🏆\n"
            f"\n"
            f"✨ Wins    : {s['wins']}\n"
            f"🔥 Losses  : {s['losses']}\n"
            f"🌟 Jackpots: {s['jackpots']}\n"
            f"⚡ Total   : {s['total']}\n"
            f"💎 Users   : {s['users']}\n"
            f"🎯 Accuracy: {s['accuracy']*100:.1f}%"
        )
        txt, ents = build_ui_message(raw)
        await update.message.reply_text(txt, entities=ents, reply_markup=get_reply_keyboard())
        return

    # 📢 My Channels
    if text in ["📢 My Channels", "My Channels"]:
        targets = get_targets(user_id)
        if not targets:
            raw = "💎 No channels added yet.\n\n🎯 Use Add Channel to add one."
        else:
            raw = "💎 Your Channels:\n\n"
            for t in targets:
                raw += f"⚡ {t['title']}  (ID: {t['chat_id']})\n"
            raw += "\n🔥 To remove: /remove <chat_id>"
        txt, ents = build_ui_message(raw)
        await update.message.reply_text(txt, entities=ents, reply_markup=get_reply_keyboard())
        return

    # ➕ Add Channel
    if text in ["➕ Add Channel", "Add Channel"]:
        t0, e0 = build_ui_message(
            "💎 Add Channel / Group 💎\n"
            "\n"
            "Send me the Chat ID (numeric) or @username.\n"
            "Make sure I am an admin there.\n"
            "\n"
            "🔥 Type /cancel to abort."
        )
        await update.message.reply_text(t0, entities=e0)
        return ADD_CHAT

    # ❓ Help
    if text in ["❓ Help", "Help"]:
        raw = (
            f"💎 Help Menu 💎\n"
            f"\n"
            f"🟢 Primary   – Set win target & start\n"
            f"✅ Success   – View session progress\n"
            f"🔴 Danger    – Pause/Resume session\n"
            f"📊 Stats     – View statistics\n"
            f"📢 My Channels – List your channels\n"
            f"📢 Broadcast – Send to all (Owner)\n"
            f"ℹ️ About     – Bot info\n"
            f"📶 Ping      – Check latency\n"
            f"➕ Add Channel – Add a channel\n"
            f"\n"
            f"🏆 Owner: {OWNER_USERNAME}"
        )
        txt, ents = build_ui_message(raw)
        await update.message.reply_text(txt, entities=ents, reply_markup=get_reply_keyboard())
        return

    # ℹ️ About
    if text in ["ℹ️ About", "About"]:
        raw = (
            f"🏆 MARCO BHAI VIP PREDICTOR 🏆\n"
            f"\n"
            f"⚡ Version  : 3.0\n"
            f"🔥 Engine   : Advanced AI v3.0\n"
            f"💎 Owner    : {OWNER_USERNAME}\n"
            f"✨ Analysis : Real data-based predictions\n"
            f"🎯 Feature  : Set win target & track progress!\n"
            f"🌟 Powered  : Machine learning\n"
            f"💫 Status   : Online 24/7"
        )
        txt, ents = build_ui_message(raw)
        await update.message.reply_text(txt, entities=ents, reply_markup=get_reply_keyboard())
        return

    # 📶 Ping
    if text in ["📶 Ping", "Ping"]:
        start_time = time.time()
        tp, ep = build_bold_message("🏓 Pinging...")
        await update.message.reply_text(tp, entities=ep)
        end_time = time.time()
        ms = int((end_time - start_time) * 1000)
        tp2, ep2 = build_ui_message(f"⚡ Pong!  {ms} ms")
        await update.message.reply_text(tp2, entities=ep2, reply_markup=get_reply_keyboard())
        return

    # 📢 Broadcast
    if text in ["📢 Broadcast", "Broadcast"]:
        if user_id != OWNER_ID:
            t0, e0 = build_bold_message("⚠️ Only the bot owner can use this feature!")
            await update.message.reply_text(t0, entities=e0, reply_markup=get_reply_keyboard())
            return

        t1, e1 = build_ui_message(
            "🔥 Broadcast Message 🔥\n"
            "\n"
            "Send the message you want to broadcast to all users.\n"
            "\n"
            "💫 Type /cancel to abort."
        )
        await update.message.reply_text(t1, entities=e1)
        return BROADCAST

    # If no button matched
    t_unk, e_unk = build_bold_message("❌ Unknown command. Use the buttons below.")
    await update.message.reply_text(t_unk, entities=e_unk, reply_markup=get_reply_keyboard())

async def broadcast_receive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text

    if text.startswith('/'):
        t0, e0 = build_bold_message("❌ Broadcast cancelled.")
        await update.message.reply_text(t0, entities=e0, reply_markup=get_reply_keyboard())
        return ConversationHandler.END

    all_users = get_all_users()

    if not all_users:
        t1, e1 = build_bold_message("❌ No users found to broadcast.")
        await update.message.reply_text(t1, entities=e1, reply_markup=get_reply_keyboard())
        return ConversationHandler.END

    success_count = 0
    fail_count = 0

    ts, es = build_ui_message(f"🔥 Sending broadcast to {len(all_users)} users...")
    status_msg = await update.message.reply_text(ts, entities=es)

    for uid in all_users:
        try:
            tb, eb = build_ui_message(f"🏆 Broadcast Message 🏆\n\n{text}")
            await context.bot.send_message(chat_id=uid, text=tb, entities=eb)
            success_count += 1
            await asyncio.sleep(0.2)
        except Exception as e:
            fail_count += 1
            logger.error(f"Broadcast failed to {uid}: {e}")

    done_raw = (
        f"✨ Broadcast Complete! ✨\n"
        f"\n"
        f"🏆 Sent   : {success_count}\n"
        f"🔥 Failed : {fail_count}\n"
        f"⚡ Total  : {len(all_users)}"
    )
    td, ed = build_ui_message(done_raw)
    await status_msg.edit_text(td, entities=ed)
    tf, ef = build_bold_message("✅ Broadcast finished.")
    await update.message.reply_text(tf, entities=ef, reply_markup=get_reply_keyboard())

    return ConversationHandler.END

async def add_chat_receive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text.strip()

    if text.startswith('/'):
        t0, e0 = build_bold_message("❌ Cancelled.")
        await update.message.reply_text(t0, entities=e0, reply_markup=get_reply_keyboard())
        return ConversationHandler.END

    try:
        if text.startswith('@'):
            chat = await context.bot.get_chat(text)
        else:
            chat_id = int(text)
            chat = await context.bot.get_chat(chat_id)
        chat_id = chat.id
        title = chat.title or chat.first_name or str(chat_id)
    except Exception as e:
        t1, e1 = build_bold_message(f"❌ Error: {e}\nTry again or /cancel.")
        await update.message.reply_text(t1, entities=e1)
        return ADD_CHAT

    if add_target(user_id, chat_id, title):
        try:
            tc, ec = build_ui_message(
                "✨ Channel added successfully! ✨\n\nI will send predictions here."
            )
            await context.bot.send_message(chat_id=chat_id, text=tc, entities=ec)
        except Exception as e:
            remove_target(user_id, chat_id)
            t2, e2 = build_bold_message(f"⚠️ Cannot send message. Make me admin!\nError: {e}")
            await update.message.reply_text(t2, entities=e2, reply_markup=get_reply_keyboard())
            return ADD_CHAT

        raw = (
            f"✨ Added Successfully! ✨\n"
            f"\n"
            f"💎 Name : {title}\n"
            f"⚡ ID   : {chat_id}\n"
            f"\n"
            f"🎯 Now press Primary to begin."
        )
        ta, ea = build_ui_message(raw)
        await update.message.reply_text(ta, entities=ea, reply_markup=get_reply_keyboard())
    else:
        t3, e3 = build_bold_message("❌ Database error.")
        await update.message.reply_text(t3, entities=e3, reply_markup=get_reply_keyboard())

    return ConversationHandler.END

async def remove_channel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    try:
        chat_id = int(context.args[0])
    except (IndexError, ValueError):
        t0, e0 = build_bold_message("⚠️ Usage: /remove <chat_id>")
        await update.message.reply_text(t0, entities=e0, reply_markup=get_reply_keyboard())
        return

    if remove_target(user_id, chat_id):
        t1, e1 = build_ui_message("✨ Channel removed successfully!")
        await update.message.reply_text(t1, entities=e1, reply_markup=get_reply_keyboard())
    else:
        t2, e2 = build_bold_message("❌ Channel not found.")
        await update.message.reply_text(t2, entities=e2, reply_markup=get_reply_keyboard())

async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    t0, e0 = build_bold_message("❌ Cancelled.")
    await update.message.reply_text(t0, entities=e0, reply_markup=get_reply_keyboard())
    return ConversationHandler.END

async def start_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    clear_old_cache()
    if user_id not in access_cache:
        joined, missing = await check_all_memberships(user_id, context.bot)
        if joined:
            access_cache[user_id] = time.time()
        else:
            t0, e0 = build_bold_message("⚠️ Please /start first and join all required channels.")
            await update.message.reply_text(t0, entities=e0)
            return ConversationHandler.END

    targets = get_targets(user_id)
    if not targets:
        t1, e1 = build_ui_message("⚠️ No channels added.\n\n💎 Use Add Channel first.")
        await update.message.reply_text(t1, entities=e1, reply_markup=get_reply_keyboard())
        return ConversationHandler.END
    
    session = get_user_session(user_id)
    if session and session['status'] == 'active':
        raw = (
            f"🏆 Session Already Active 🏆\n"
            f"\n"
            f"🎯 Target  : {session['target_wins']} wins\n"
            f"✨ Achieved: {session['current_wins']} wins\n"
            f"\n"
            f"💫 Press 'Success' to view full progress."
        )
        txt, ents = build_ui_message(raw)
        await update.message.reply_text(txt, entities=ents, reply_markup=get_reply_keyboard())
        return ConversationHandler.END
    
    t2, e2 = build_ui_message(
        "🎯 Set Win Target 🎯\n"
        "\n"
        "How many wins do you want in this session?\n"
        "\n"
        "💎 Send a number  (e.g. 10)"
    )
    await update.message.reply_text(t2, entities=e2)
    return SET_TARGET

async def receive_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text.strip()

    try:
        target = int(text)
        if target <= 0 or target > 100:
            t0, e0 = build_bold_message("❌ Please send a number between 1 and 100.")
            await update.message.reply_text(t0, entities=e0)
            return SET_TARGET
    except ValueError:
        t1, e1 = build_bold_message("❌ Please send a valid number (e.g., 10).")
        await update.message.reply_text(t1, entities=e1)
        return SET_TARGET
    
    if create_or_update_session(user_id, target_wins=target, status='active'):
        raw = (
            f"🏆 Session Started! 🏆\n"
            f"\n"
            f"🎯 Target  : {target} wins\n"
            f"✨ Current : 0 wins\n"
            f"\n"
            f"🔥 Predictions incoming. Good luck! 💫"
        )
        txt, ents = build_ui_message(raw)
        await update.message.reply_text(txt, entities=ents, reply_markup=get_reply_keyboard())
        result, next_pred = await predictor.update_and_get_result()
        if next_pred:
            await send_prediction_to_user(user_id, context, result, next_pred)
        return ConversationHandler.END
    else:
        t2, e2 = build_bold_message("❌ Database error. Please try again.")
        await update.message.reply_text(t2, entities=e2)
        return SET_TARGET

async def send_session_close_to_user(user_id: int, app, target: int, achieved: int):
    targets = get_targets(user_id)
    raw = (
        f"🏆 SESSION COMPLETE! 🏆\n"
        f"\n"
        f"✨ You achieved your target of {target} wins!\n"
        f"🎯 Total wins: {achieved}\n"
        f"\n"
        f"🔥 Press 'Primary' to begin a new session. 💫"
    )
    close_txt, close_ents = build_ui_message(raw)

    sent_chats = set()
    for t in targets:
        chat_id = t['chat_id']
        if chat_id in sent_chats:
            continue
        sent_chats.add(chat_id)
        try:
            await app.bot.send_sticker(chat_id=chat_id, sticker=SESSION_CLOSE_STICKER)
            await asyncio.sleep(0.15)
            await app.bot.send_message(chat_id=chat_id, text=close_txt, entities=close_ents)
            await asyncio.sleep(0.15)
        except Exception as e:
            logger.error(f"Close send failed to {chat_id}: {e}")

    try:
        await app.bot.send_sticker(chat_id=user_id, sticker=SESSION_CLOSE_STICKER)
        await asyncio.sleep(0.15)
        await app.bot.send_message(chat_id=user_id, text=close_txt, entities=close_ents)
    except Exception as e:
        logger.error(f"Close send to DM failed: {e}")

async def manual_predict(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    clear_old_cache()
    if user_id not in access_cache:
        t0, e0 = build_bold_message("⚠️ Access required. Please /start first.")
        await update.message.reply_text(t0, entities=e0)
        return

    result, next_pred = await predictor.update_and_get_result()
    if next_pred:
        await send_prediction_to_user(user_id, context, result, next_pred)
    else:
        t1, e1 = build_bold_message("❌ Could not fetch prediction. Try again later.")
        await update.message.reply_text(t1, entities=e1)

# ========================================
# ✉️ SET MESSAGE HANDLERS (OWNER ONLY)
# ========================================
async def setmessage_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        t, e = build_bold_message("⚠️ Sirf Owner use kar sakta hai!")
        await update.message.reply_text(t, entities=e)
        return ConversationHandler.END
    
    current = get_custom_message()
    raw = (
        "✉️ CUSTOM MESSAGE SETUP ✉️\n"
        "\n"
        "📌 Abhi ka message:\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"{current}\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "\n"
        "💡 IMPORTANT:\n"
        "Jahan period number chahiye wahan\n"
        "{period} likh dena.\n"
        "\n"
        "Example:\n"
        "🔴 {period}➡️ IN LIVE\n"
        "\n"
        "📝 Ab apna naya message bhejo:\n"
        "(/cancel se abort)"
    )
    t, e = build_ui_message(raw)
    await update.message.reply_text(t, entities=e)
    return SET_MESSAGE

async def setmessage_receive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        return ConversationHandler.END
    
    text = update.message.text
    
    if text.startswith('/'):
        t, e = build_bold_message("❌ Cancelled.")
        await update.message.reply_text(t, entities=e, reply_markup=get_reply_keyboard())
        return ConversationHandler.END
    
    if not text.strip():
        t, e = build_bold_message("❌ Empty message nahi chalega.")
        await update.message.reply_text(t, entities=e)
        return SET_MESSAGE
    
    if save_custom_message(text):
        preview_text, preview_ents = build_custom_prediction({'period': '540'})
        
        t1, e1 = build_ui_message("✅ Message Save Ho Gaya!\n\n📌 Preview:")
        await update.message.reply_text(t1, entities=e1)
        
        await update.message.reply_text(preview_text, entities=preview_ents)
        
        t2, e2 = build_bold_message("✅ Ab har prediction yehi message jayegi (period real game wala).")
        await update.message.reply_text(t2, entities=e2, reply_markup=get_reply_keyboard())
    else:
        t, e = build_bold_message("❌ DB error. Try again.")
        await update.message.reply_text(t, entities=e)
    
    return ConversationHandler.END


async def viewmessage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        return
    current = get_custom_message()
    raw = (
        "✉️ CURRENT MESSAGE ✉️\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"{current}\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "\n"
        "🔄 /resetmessage → Default par le jao\n"
        "✏️ /setmessage   → Naya message banao"
    )
    t, e = build_ui_message(raw)
    await update.message.reply_text(t, entities=e)


async def resetmessage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        return
    if reset_custom_message():
        t, e = build_ui_message("✨ Message reset ho gaya! Default use hoga.")
        await update.message.reply_text(t, entities=e, reply_markup=get_reply_keyboard())

# ========================================
# ⏰ AUTO ENGINE
# ========================================
async def auto_predict_task(app: Application):
    active_users = get_active_sessions()
    if not active_users:
        return
    
    result, next_pred = await predictor.update_and_get_result()
    if not next_pred:
        return
    
    period = next_pred.get('period')
    
    if period in sent_periods:
        logger.debug(f"Period {period} already sent, skipping duplicate")
        return
    
    sent_periods.add(period)
    if len(sent_periods) > 100:
        sent_periods.clear()
    
    text, entities = build_custom_prediction(next_pred)
    
    sticker_id = None
    if result:
        if result['status'] == "JACKPOT":
            sticker_id = STICKER_JACKPOT
        elif result['status'] == "WIN":
            sticker_id = STICKER_WIN
        elif result['status'] == "LOSS":
            sticker_id = STICKER_LOSS
    
    all_targets = get_all_targets()
    active_user_set = set(active_users)
    
    user_chats = {}
    for target in all_targets:
        owner_id = target['user_id']
        if owner_id not in active_user_set:
            continue
        if owner_id not in user_chats:
            user_chats[owner_id] = []
        user_chats[owner_id].append(target['chat_id'])
    
    sent_chats = set()
    for user_id, chat_ids in user_chats.items():
        for chat_id in chat_ids:
            if chat_id in sent_chats:
                continue
            sent_chats.add(chat_id)
            try:
                if sticker_id:
                    try:
                        await app.bot.send_sticker(chat_id=chat_id, sticker=sticker_id)
                        await asyncio.sleep(0.1)
                    except Exception:
                        pass
                await app.bot.send_message(chat_id=chat_id, text=text, entities=entities)
                await asyncio.sleep(0.1)
            except Exception as e:
                logger.error(f"Send to chat {chat_id} failed: {e}")
        
        try:
            if sticker_id:
                try:
                    await app.bot.send_sticker(chat_id=user_id, sticker=sticker_id)
                    await asyncio.sleep(0.1)
                except Exception:
                    pass
            await app.bot.send_message(chat_id=user_id, text=text, entities=entities)
            await asyncio.sleep(0.1)
        except Exception as e:
            logger.error(f"Send to DM {user_id} failed: {e}")
    
    if result and result['status'] in ['WIN', 'JACKPOT']:
        for user_id in list(active_users):
            session = get_user_session(user_id)
            if not session or session['status'] != 'active':
                continue
            
            current, target = update_user_wins(user_id, 1)
            if current is not None and current >= target:
                close_user_session(user_id)
                await send_session_close_to_user(user_id, app, target, current)

async def run_auto_loop(app: Application):
    while True:
        try:
            await auto_predict_task(app)
        except Exception as e:
            logger.error(f"Auto loop error: {e}")
        await asyncio.sleep(5)

# ========================================
# 🚀 MAIN
# ========================================
def main():
    if not init_db():
        logger.error("Database initialization failed!")
        return
    
    app = Application.builder().token(BOT_TOKEN).build()

    # Command Handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("remove", remove_channel))
    app.add_handler(CommandHandler("cancel", cancel_command))
    app.add_handler(CommandHandler("predict", manual_predict))
    app.add_handler(CommandHandler("viewmessage", viewmessage))
    app.add_handler(CommandHandler("resetmessage", resetmessage))
    
    # Callback Query Handlers
    app.add_handler(CallbackQueryHandler(verify_membership_callback, pattern="verify_membership"))
    app.add_handler(CallbackQueryHandler(go_to_bot_callback, pattern="go_to_bot"))
    app.add_handler(CallbackQueryHandler(lambda u,c: None, pattern="channel_"))
    
    # Add Channel Conversation
    add_chat_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex('^[➕] Add Channel'), handle_menu_buttons)],
        states={
            ADD_CHAT: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_chat_receive)]
        },
        fallbacks=[CommandHandler("cancel", cancel_command)]
    )
    app.add_handler(add_chat_conv)
    
    # Broadcast Conversation
    broadcast_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex('^[📢] Broadcast$'), handle_menu_buttons)],
        states={
            BROADCAST: [MessageHandler(filters.TEXT & ~filters.COMMAND, broadcast_receive)]
        },
        fallbacks=[CommandHandler("cancel", cancel_command)]
    )
    app.add_handler(broadcast_conv)
    
    # Set Target Conversation
    target_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex('^[🟢] Primary$'), start_target)],
        states={
            SET_TARGET: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_target)]
        },
        fallbacks=[CommandHandler("cancel", cancel_command)]
    )
    app.add_handler(target_conv)
    
    # Set Message Conversation (Owner Only)
    setmessage_conv = ConversationHandler(
        entry_points=[CommandHandler("setmessage", setmessage_start)],
        states={
            SET_MESSAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, setmessage_receive)]
        },
        fallbacks=[CommandHandler("cancel", cancel_command)]
    )
    app.add_handler(setmessage_conv)
    
    # Main Message Handler
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_menu_buttons))

    # Start Auto Prediction Loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.create_task(run_auto_loop(app))

    print("="*60)
    print("🚀 MARCO BHAI VIP BOT STARTED!")
    print(f"👑 Owner ID: {OWNER_ID}")
    print(f"👑 Owner: {OWNER_USERNAME}")
    print("⏰ Auto-prediction every 5 seconds")
    print("="*60)
    print("✉️ CUSTOM MESSAGE COMMANDS:")
    print("   /setmessage   → Naya message set karo")
    print("   /viewmessage  → Current message dekho")
    print("   /resetmessage → Default par le jao")
    print("   📌 Use {period} jahan period chahiye")
    print("="*60)
    
    app.run_polling()

if __name__ == "__main__":
    main()