import asyncio
import logging
import secrets
import time
from contextlib import suppress
from datetime import datetime, timezone

from aiogram import Bot, Dispatcher, F
from aiogram.enums import ChatType
from aiogram.exceptions import (
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramNetworkError,
    TelegramRetryAfter,
    TelegramServerError,
)
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    CallbackQuery,
    ChatJoinRequest,
    ChatMemberUpdated,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from pymongo import AsyncMongoClient


# ============================================================
#                         CONFIGURATION
# ============================================================

BOT_TOKEN = "8687329268:AAFKACe3XHUYbluluRKTc-TlimZnVYIv1QI"

MONGO_URI = "mongodb+srv://maxgurupalop_db_user:cag141y7yeLjGvSi@gurlalboss.sudhe7j.mongodb.net/?appName=Gurlalboss"

MONGO_DATABASE = "telegram_join_bot1"

OWNER_IDS = {
    8790937904,
}

# ------------------------------------------------------------
# UNLOCK SYSTEM
# ------------------------------------------------------------

# Bot username (bina @). Khali chhodo to bot khud get_me() se le lega.
UNLOCK_BOT_USERNAME = ""

# URL buttons ko unlock deep-link me convert karna hai ya nahi
UNLOCK_ENABLED = True

# ------------------------------------------------------------
# BROADCAST SETTINGS
# ------------------------------------------------------------

BROADCAST_WORKERS = 8
NORMAL_MESSAGES_PER_SECOND = 18
USE_PAID_BROADCAST = False

PROGRESS_UPDATE_SECONDS = 2
PROGRESS_DB_EVERY = 10

MAX_WELCOME_SLOTS = 3


# ============================================================
#                         LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

logger = logging.getLogger("telegram-bot")


# ============================================================
#                            BOT
# ============================================================

bot = Bot(BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())


# ============================================================
#                          MONGODB
# ============================================================

mongo = AsyncMongoClient(MONGO_URI)
db = mongo[MONGO_DATABASE]

users_collection = db["users1"]
channels_collection = db["channels1"]
settings_collection = db["settings1"]
broadcasts_collection = db["broadcasts1"]
kick_logs_collection = db["kick_logs1"]
unlock_collection = db["unlock_tokens1"]


# ============================================================
#                           STATES
# ============================================================

class BotStates(StatesGroup):
    waiting_welcome_message = State()
    waiting_channel = State()
    waiting_broadcast_message = State()
    waiting_delay = State()


# ============================================================
#                       GLOBAL VARIABLES
# ============================================================

broadcast_tasks = {}
broadcast_runtime = {}
broadcast_lock = asyncio.Lock()
last_broadcast_send_time = 0.0

BOT_USERNAME_CACHE = None


# ============================================================
#                         TIME HELPERS
# ============================================================

def utc_now():
    return datetime.now(timezone.utc)


def is_owner(user_id: int) -> bool:
    return user_id in OWNER_IDS


# ============================================================
#                    BOT USERNAME HELPER
# ============================================================

async def get_bot_username() -> str:
    global BOT_USERNAME_CACHE
    if UNLOCK_BOT_USERNAME:
        return UNLOCK_BOT_USERNAME.lstrip("@")
    if BOT_USERNAME_CACHE:
        return BOT_USERNAME_CACHE
    me = await bot.get_me()
    BOT_USERNAME_CACHE = me.username
    return me.username


# ============================================================
#                       UNLOCK TOKEN DB
# ============================================================

async def create_unlock_token(real_url: str, button_text: str) -> str:
    token = secrets.token_urlsafe(12)
    await unlock_collection.insert_one(
        {
            "token": token,
            "real_url": real_url,
            "button_text": button_text,
            "created_at": utc_now(),
            "used_count": 0,
        }
    )
    username = await get_bot_username()
    return f"https://t.me/{username}?start=unlock_{token}"


async def get_unlock_token(token: str):
    return await unlock_collection.find_one({"token": token})


async def increment_unlock_usage(token: str):
    await unlock_collection.update_one(
        {"token": token},
        {
            "$inc": {"used_count": 1},
            "$set": {"last_used_at": utc_now()},
        },
    )


# ============================================================
#     KEYBOARD PROCESSOR (auto-gate URL buttons -> unlock)
# ============================================================

async def process_reply_markup_for_unlock(reply_markup):
    """
    InlineKeyboardMarkup me jo bhi URL buttons hain,
    unko unlock deep-link me convert kar deta hai.
    Text same rehta hai.
    """
    if not reply_markup:
        return None

    if not isinstance(reply_markup, InlineKeyboardMarkup):
        return reply_markup

    new_rows = []

    for row in reply_markup.inline_keyboard:
        new_row = []
        for button in row:
            if button.url:
                try:
                    deep_link = await create_unlock_token(
                        real_url=button.url,
                        button_text=button.text,
                    )
                    new_row.append(
                        InlineKeyboardButton(
                            text=button.text,
                            url=deep_link,
                        )
                    )
                    logger.info(
                        "Gated button '%s' -> %s",
                        button.text, deep_link,
                    )
                except Exception:
                    logger.exception(
                        "Failed to gate button, using original"
                    )
                    new_row.append(button)
            else:
                new_row.append(button)
        new_rows.append(new_row)

    return InlineKeyboardMarkup(inline_keyboard=new_rows)


def markup_to_json(markup):
    """InlineKeyboardMarkup -> dict (for Mongo storage)."""
    if not markup:
        return None
    try:
        return markup.model_dump()
    except Exception:
        logger.exception("markup_to_json failed")
        return None


def json_to_markup(data):
    """dict -> InlineKeyboardMarkup."""
    if not data:
        return None
    try:
        return InlineKeyboardMarkup(**data)
    except Exception:
        logger.exception("json_to_markup failed")
        return None


# ============================================================
#                         USER DATABASE
# ============================================================

async def save_user(user):
    if not user:
        return
    current_time = utc_now()
    await users_collection.update_one(
        {"user_id": user.id},
        {
            "$set": {
                "user_id": user.id,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "username": user.username,
                "language_code": user.language_code,
                "is_bot": user.is_bot,
                "is_premium": getattr(user, "is_premium", False) or False,
                "last_seen": current_time,
            },
            "$setOnInsert": {
                "created_at": current_time,
                "blocked": False,
                "join_requests": 0,
                "broadcast_received": 0,
            },
        },
        upsert=True,
    )


async def mark_user_blocked(user_id: int):
    await users_collection.update_one(
        {"user_id": user_id},
        {"$set": {"blocked": True, "blocked_at": utc_now()}},
    )


# ============================================================
#                       SETTINGS DATABASE
# ============================================================

async def get_setting(key, default=None):
    document = await settings_collection.find_one({"_id": key})
    if not document:
        return default
    return document.get("value", default)


async def set_setting(key, value):
    await settings_collection.update_one(
        {"_id": key},
        {"$set": {"value": value, "updated_at": utc_now()}},
        upsert=True,
    )


async def get_bool_setting(key, default=False) -> bool:
    value = await get_setting(key, default)
    return bool(value)


# ============================================================
#                  WELCOME MESSAGE STORAGE
# ============================================================

async def get_welcome_messages():
    messages = await get_setting("welcome_messages", {})
    if not isinstance(messages, dict):
        return {}
    return messages


async def save_welcome_slot(slot: int, saved_message: dict):
    messages = await get_welcome_messages()
    messages[str(slot)] = saved_message
    await set_setting("welcome_messages", messages)


async def delete_all_welcome_messages():
    await set_setting("welcome_messages", {})


async def welcome_status_text():
    messages = await get_welcome_messages()
    configured = [
        s for s in range(1, MAX_WELCOME_SLOTS + 1) if str(s) in messages
    ]
    if configured:
        return f"✅ Set: <b>{', '.join(map(str, configured))}</b>"
    return "❌ No welcome message set."


# ============================================================
#                    DELAY FORMATTER
# ============================================================

def format_delay(seconds) -> str:
    try:
        s = int(seconds)
    except Exception:
        s = 0
    if s <= 0:
        return "0 sec"
    if s < 60:
        return f"{s} sec"
    m = s // 60
    r = s % 60
    if r == 0:
        return f"{m} min"
    return f"{m} min {r} sec"


# ============================================================
#                    OWNER PANEL KEYBOARD
# ============================================================

async def owner_panel_keyboard():

    reject_premium = await get_bool_setting("reject_premium", False)
    auto_approve = await get_bool_setting("auto_approve", False)
    delay = await get_setting("welcome_delay", 0)
    messages = await get_welcome_messages()

    reject_icon = "🟢" if reject_premium else "🔴"
    approve_icon = "🟢" if auto_approve else "🔴"

    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(text="👥 Users Check", callback_data="users")
    )

    builder.row(
        InlineKeyboardButton(
            text="📩 Channel Premium Remove",
            callback_data="channel_premium_remove",
        )
    )

    builder.row(
        InlineKeyboardButton(
            text=f"❌ Reject Premium: {'ON' if reject_premium else 'OFF'} {reject_icon}",
            callback_data="toggle_reject_premium",
        )
    )

    builder.row(
        InlineKeyboardButton(
            text=f"⚙️ Auto-Approve: {'ON' if auto_approve else 'OFF'} {approve_icon}",
            callback_data="toggle_auto_approve",
        )
    )

    def setup_label(slot: int) -> str:
        keycap = {1: "1️⃣", 2: "2️⃣", 3: "3️⃣"}.get(slot, f"{slot}️⃣")
        mark = " ✅" if str(slot) in messages else ""
        return f"{keycap} Setup Msg {slot}{mark}"

    builder.row(
        InlineKeyboardButton(text=setup_label(1), callback_data="setup_msg:1"),
        InlineKeyboardButton(text=setup_label(2), callback_data="setup_msg:2"),
        InlineKeyboardButton(text=setup_label(3), callback_data="setup_msg:3"),
    )

    builder.row(
        InlineKeyboardButton(
            text=f"⏱️ Setup Delay: {format_delay(delay)}",
            callback_data="setup_delay",
        )
    )

    builder.row(
        InlineKeyboardButton(text="📡 Channels", callback_data="channels"),
        InlineKeyboardButton(text="📢 Broadcast", callback_data="broadcast"),
    )

    builder.row(
        InlineKeyboardButton(
            text="📊 Broadcast Stats", callback_data="broadcast_stats"
        ),
        InlineKeyboardButton(text="👁 Preview", callback_data="preview"),
    )

    builder.row(
        InlineKeyboardButton(text="🛡️ Kick Logs", callback_data="kick_logs")
    )

    builder.row(
        InlineKeyboardButton(
            text="🗑 Delete All Welcome", callback_data="delete_welcome_all"
        )
    )

    builder.row(
        InlineKeyboardButton(text="🔄 Refresh", callback_data="panel")
    )

    return builder.as_markup()


def back_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="⬅️ Back", callback_data="panel"
                )
            ]
        ]
    )


# ============================================================
#              COPY SAVED TELEGRAM MESSAGE
#           (with auto Unlock gating for URL buttons)
# ============================================================

async def copy_saved_message(target_chat_id: int, saved_message: dict):
    """
    Saved message ko copy karta hai.
    Agar message me URL buttons hain,
    to unko unlock deep-link me convert karke bhejta hai.
    """
    source_chat_id = saved_message["source_chat_id"]
    source_message_id = saved_message["source_message_id"]

    # DB se saved reply_markup nikalo (agar save kiya tha)
    reply_markup = json_to_markup(saved_message.get("reply_markup"))

    # URL buttons ko unlock link me convert karo
    if UNLOCK_ENABLED and reply_markup:
        reply_markup = await process_reply_markup_for_unlock(reply_markup)

    kwargs = {
        "chat_id": target_chat_id,
        "from_chat_id": source_chat_id,
        "message_id": source_message_id,
    }

    if reply_markup:
        kwargs["reply_markup"] = reply_markup

    return await bot.copy_message(**kwargs)


# ============================================================
#             SEND ALL WELCOME MESSAGES
# ============================================================

async def send_welcome_messages(target_chat_id: int):
    messages = await get_welcome_messages()

    try:
        delay = int(await get_setting("welcome_delay", 0) or 0)
    except Exception:
        delay = 0
    if delay < 0:
        delay = 0

    sent = 0

    for slot in range(1, MAX_WELCOME_SLOTS + 1):
        saved = messages.get(str(slot))
        if not saved:
            continue

        if sent > 0 and delay > 0:
            await asyncio.sleep(delay)

        try:
            await copy_saved_message(target_chat_id, saved)
            sent += 1
        except TelegramForbiddenError:
            raise
        except TelegramBadRequest as error:
            logger.warning("Welcome slot %s failed: %s", slot, error)
        except Exception:
            logger.exception("Welcome slot %s crashed", slot)

    return sent


# ============================================================
#                  UNLOCK DEEP-LINK HANDLER
# ============================================================

@dp.message(CommandStart(deep_link=True))
async def unlock_start_handler(message: Message, command: CommandObject):
    args = command.args or ""

    if not args.startswith("unlock_"):
        return await start_handler(message)

    token = args[len("unlock_"):]
    doc = await get_unlock_token(token)

    if not doc:
        await message.answer(
            "❌ <b>Unlock link expired or invalid.</b>\n\n"
            "Please ask the channel owner for a fresh link."
        )
        return

    real_url = doc.get("real_url")
    button_text = doc.get("button_text") or "🔓 Open"

    await increment_unlock_usage(token)

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=button_text,
                    url=real_url,
                )
            ]
        ]
    )

    await message.answer(
        "✅ <b>Unlocked!</b>\n\n"
        "Tap the button below to continue.",
        reply_markup=keyboard,
    )

    logger.info(
        "Unlock served: token=%s user=%s url=%s",
        token,
        message.from_user.id if message.from_user else "?",
        real_url,
    )


# ============================================================
#                           /START
# ============================================================

@dp.message(CommandStart())
async def start_handler(message: Message):
    if not message.from_user:
        return

    await save_user(message.from_user)

    messages = await get_welcome_messages()
    if not messages:
        await message.answer(
            "👋 Hello!\n\n"
            "Welcome messages are not configured yet."
        )
        return

    try:
        await send_welcome_messages(message.chat.id)
    except TelegramForbiddenError:
        await mark_user_blocked(message.from_user.id)
    except Exception:
        logger.exception("Failed to send welcome messages")


# ============================================================
#                           /ID
# ============================================================

@dp.message(Command("id"))
async def id_handler(message: Message):
    if not message.from_user:
        return
    await message.answer(
        "🆔 <b>Your Telegram ID</b>\n\n"
        f"<code>{message.from_user.id}</code>"
    )


# ============================================================
#                          /CANCEL
# ============================================================

@dp.message(Command("cancel"))
async def cancel_command(message: Message, state: FSMContext):
    if not message.from_user:
        return
    if not is_owner(message.from_user.id):
        return

    current_state = await state.get_state()
    if current_state:
        await state.clear()
        await message.answer("❌ Current action cancelled.")
        return

    running = [
        bid for bid, task in broadcast_tasks.items() if not task.done()
    ]
    if not running:
        await message.answer("ℹ️ No running broadcast.")
        return

    for bid in running:
        task = broadcast_tasks.get(bid)
        if task:
            task.cancel()

    await message.answer("🛑 <b>Broadcast cancellation requested.</b>")


# ============================================================
#                           /PANEL
# ============================================================

async def get_user_counts():
    total = await users_collection.count_documents({})
    blocked = await users_collection.count_documents({"blocked": True})
    reachable = await users_collection.count_documents(
        {"blocked": {"$ne": True}}
    )
    return total, reachable, blocked


async def panel_text():
    total, reachable, blocked = await get_user_counts()
    welcome_status = await welcome_status_text()

    reject_premium = await get_bool_setting("reject_premium", False)
    auto_approve = await get_bool_setting("auto_approve", False)
    delay = await get_setting("welcome_delay", 0)

    running_count = sum(
        1 for task in broadcast_tasks.values() if not task.done()
    )

    text = (
        "👑 <b>OWNER PANEL</b>\n\n"

        "👥 <b>Users</b>\n"
        f"├ Total: <b>{total}</b>\n"
        f"├ Reachable: <b>{reachable}</b>\n"
        f"└ Blocked: <b>{blocked}</b>\n\n"

        "📩 <b>Welcome</b>\n"
        f"{welcome_status}\n"
        f"⏱️ Delay: <b>{format_delay(delay)}</b>\n\n"

        "⚙️ <b>Join Settings</b>\n"
        f"├ Reject Premium: <b>{'ON' if reject_premium else 'OFF'}</b>\n"
        f"└ Auto-Approve: <b>{'ON' if auto_approve else 'OFF'}</b>\n\n"

        "🔓 <b>Unlock System</b>\n"
        f"└ Status: <b>{'ON' if UNLOCK_ENABLED else 'OFF'}</b>\n\n"

        "📢 <b>Broadcast</b>\n"
        f"└ Running: <b>{running_count}</b>\n\n"

        "Select an option:"
    )
    return text


@dp.message(Command("panel"))
async def panel_command(message: Message):
    if not message.from_user:
        return
    user_id = message.from_user.id
    logger.info("Panel command from user_id=%s", user_id)

    if not is_owner(user_id):
        await message.answer("❌ You are not authorized.")
        return

    await message.answer(
        await panel_text(),
        reply_markup=await owner_panel_keyboard(),
    )


@dp.callback_query(F.data == "panel")
async def panel_callback(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    await callback.answer()
    if not callback.message:
        return

    try:
        await callback.message.edit_text(
            await panel_text(),
            reply_markup=await owner_panel_keyboard(),
        )
    except TelegramBadRequest as error:
        if "message is not modified" not in str(error).lower():
            logger.warning("Panel edit failed: %s", error)


# ============================================================
#              TOGGLE: REJECT PREMIUM
# ============================================================

@dp.callback_query(F.data == "toggle_reject_premium")
async def toggle_reject_premium(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    current = await get_bool_setting("reject_premium", False)
    new_value = not current
    await set_setting("reject_premium", new_value)

    await callback.answer(
        f"Reject Premium: {'ON 🟢' if new_value else 'OFF 🔴'}",
        show_alert=False,
    )

    if callback.message:
        try:
            await callback.message.edit_text(
                await panel_text(),
                reply_markup=await owner_panel_keyboard(),
            )
        except TelegramBadRequest:
            pass


# ============================================================
#              TOGGLE: AUTO-APPROVE
# ============================================================

@dp.callback_query(F.data == "toggle_auto_approve")
async def toggle_auto_approve(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    current = await get_bool_setting("auto_approve", False)
    new_value = not current
    await set_setting("auto_approve", new_value)

    await callback.answer(
        f"Auto-Approve: {'ON 🟢' if new_value else 'OFF 🔴'}",
        show_alert=False,
    )

    if callback.message:
        try:
            await callback.message.edit_text(
                await panel_text(),
                reply_markup=await owner_panel_keyboard(),
            )
        except TelegramBadRequest:
            pass


# ============================================================
#              CHANNEL PREMIUM REMOVE (INFO)
# ============================================================

@dp.callback_query(F.data == "channel_premium_remove")
async def channel_premium_remove_callback(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    reject_premium = await get_bool_setting("reject_premium", False)

    text = (
        "📩 <b>CHANNEL PREMIUM REMOVE</b>\n\n"
        "This feature works together with <b>❌ Reject Premium</b>.\n\n"
        f"Current Reject Premium status: "
        f"<b>{'ON 🟢' if reject_premium else 'OFF 🔴'}</b>\n\n"
        "<b>How it works:</b>\n"
        "1️⃣ Add bot as <b>admin</b> in your channel\n"
        "2️⃣ Channel is auto-registered ✅\n"
        "3️⃣ Turn <b>Reject Premium = ON</b>\n"
        "4️⃣ Any Telegram Premium user who joins → "
        "<b>banned instantly</b> 🚫\n\n"
        "📌 Also works on join requests."
    )

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"❌ Reject Premium: "
                         f"{'ON 🟢' if reject_premium else 'OFF 🔴'}",
                    callback_data="toggle_reject_premium",
                )
            ],
            [
                InlineKeyboardButton(
                    text="🛡️ Kick Logs", callback_data="kick_logs"
                )
            ],
            [
                InlineKeyboardButton(text="⬅️ Back", callback_data="panel")
            ],
        ]
    )

    await callback.answer()
    try:
        await callback.message.edit_text(text, reply_markup=keyboard)
    except TelegramBadRequest:
        pass


# ============================================================
#              KICK LOGS
# ============================================================

@dp.callback_query(F.data == "kick_logs")
async def kick_logs_callback(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    await callback.answer()

    total = await kick_logs_collection.count_documents({})
    latest = await kick_logs_collection.find(
        {}, sort=[("kicked_at", -1)]
    ).to_list(length=10)

    text = f"🛡️ <b>PREMIUM KICK LOGS</b>\n\nTotal: <b>{total}</b>\n\n"

    if not latest:
        text += "No kicks recorded yet."
    else:
        for log in latest:
            uid = log.get("user_id", "-")
            cid = log.get("channel_id", "-")
            uname = log.get("username")
            uname_text = f"@{uname}" if uname else "-"
            when = log.get("kicked_at")
            if when:
                when = when.strftime("%d-%m-%Y %H:%M")

            text += (
                f"• <code>{uid}</code> {uname_text}\n"
                f"  Channel: <code>{cid}</code>\n"
                f"  🕐 {when}\n\n"
            )

    try:
        await callback.message.edit_text(text, reply_markup=back_keyboard())
    except TelegramBadRequest:
        pass


# ============================================================
#                  SETUP MSG SLOT
# ============================================================

@dp.callback_query(F.data.startswith("setup_msg:"))
async def setup_msg_callback(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    try:
        slot = int(callback.data.split(":")[1])
    except Exception:
        await callback.answer("Invalid slot.", show_alert=True)
        return

    if slot < 1 or slot > MAX_WELCOME_SLOTS:
        await callback.answer("Invalid slot.", show_alert=True)
        return

    await callback.answer()
    await state.update_data(welcome_slot=slot)
    await state.set_state(BotStates.waiting_welcome_message)

    keycap = {1: "1️⃣", 2: "2️⃣", 3: "3️⃣"}.get(slot, f"{slot}️⃣")

    await callback.message.answer(
        f"{keycap} <b>Setup Message {slot}</b>\n\n"
        f"Send the Telegram message for slot <b>{slot}</b>.\n\n"
        "Supported:\n"
        "• Text\n• Photo\n• Video\n• Document / APK\n"
        "• Audio / Animation\n• Links\n• Inline buttons\n"
        "• Formatting & custom emoji\n\n"
        "🔓 URL buttons will be auto-converted to unlock links.\n\n"
        "The original Telegram message will be copied."
    )


@dp.message(BotStates.waiting_welcome_message)
async def save_welcome_message(message: Message, state: FSMContext):
    if not message.from_user:
        return
    if not is_owner(message.from_user.id):
        return

    data = await state.get_data()
    slot = data.get("welcome_slot")

    if not slot:
        await state.clear()
        await message.answer("❌ Welcome slot missing. Try again.")
        return

    # reply_markup bhi save karo (dict ke form me)
    reply_markup_json = None
    if message.reply_markup:
        reply_markup_json = markup_to_json(message.reply_markup)

    saved_message = {
        "source_chat_id": message.chat.id,
        "source_message_id": message.message_id,
        "saved_by": message.from_user.id,
        "saved_at": utc_now(),
        "reply_markup": reply_markup_json,
    }

    await save_welcome_slot(slot, saved_message)
    await state.clear()

    await message.answer(
        f"✅ <b>Setup Message {slot} saved.</b>\n\n"
        f"Slot {slot} will be sent in the welcome sequence.\n"
        + (
            "🔓 URL buttons will be auto-converted to unlock links."
            if reply_markup_json else ""
        ),
        reply_markup=await owner_panel_keyboard(),
    )


# ============================================================
#                  SETUP DELAY
# ============================================================

@dp.callback_query(F.data == "setup_delay")
async def setup_delay_callback(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    await callback.answer()
    await state.set_state(BotStates.waiting_delay)

    current = await get_setting("welcome_delay", 0)

    await callback.message.answer(
        "⏱️ <b>Setup Delay</b>\n\n"
        f"Current delay: <b>{format_delay(current)}</b>\n\n"
        "Send delay in <b>seconds</b> between each welcome message.\n\n"
        "Examples:\n<code>0</code> = no delay\n"
        "<code>3</code> = 3 sec delay\n<code>5</code> = 5 sec delay\n\n"
        "Send /cancel to abort."
    )


@dp.message(BotStates.waiting_delay)
async def save_delay(message: Message, state: FSMContext):
    if not message.from_user:
        return
    if not is_owner(message.from_user.id):
        return

    if not message.text:
        await message.answer("❌ Send a number (seconds).")
        return

    try:
        seconds = int(message.text.strip())
    except Exception:
        await message.answer("❌ Invalid number. Send like <code>3</code>")
        return

    if seconds < 0:
        await message.answer("❌ Delay must be >= 0.")
        return

    if seconds > 600:
        await message.answer("❌ Max delay is 600 seconds.")
        return

    await set_setting("welcome_delay", seconds)
    await state.clear()

    await message.answer(
        f"✅ <b>Delay saved:</b> <b>{format_delay(seconds)}</b>",
        reply_markup=await owner_panel_keyboard(),
    )


# ============================================================
#                      PREVIEW WELCOME
# ============================================================

@dp.callback_query(F.data == "preview")
async def preview_callback(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    await callback.answer()

    messages = await get_welcome_messages()
    if not messages:
        await callback.message.answer("❌ No welcome messages saved.")
        return

    await callback.message.answer(
        "👁 <b>Preview of saved welcome messages:</b>\n"
        "🔓 URL buttons will appear as unlock links."
    )

    try:
        await send_welcome_messages(callback.from_user.id)
    except Exception:
        logger.exception("Welcome preview failed")


# ============================================================
#                  DELETE ALL WELCOME
# ============================================================

@dp.callback_query(F.data == "delete_welcome_all")
async def delete_welcome_all_callback(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    await delete_all_welcome_messages()

    await callback.answer("All welcome messages deleted.", show_alert=True)

    if callback.message:
        try:
            await callback.message.edit_text(
                await panel_text(),
                reply_markup=await owner_panel_keyboard(),
            )
        except TelegramBadRequest:
            pass


# ============================================================
#        AUTO-REGISTER CHANNEL WHEN BOT PROMOTED TO ADMIN
# ============================================================

@dp.my_chat_member()
async def bot_membership_handler(update: ChatMemberUpdated):
    try:
        chat = update.chat
        new_status = update.new_chat_member.status
        promoter = update.from_user

        if chat.type not in (ChatType.CHANNEL, ChatType.SUPERGROUP):
            return

        if new_status in ("administrator", "creator"):
            await channels_collection.update_one(
                {"chat_id": chat.id},
                {
                    "$set": {
                        "chat_id": chat.id,
                        "title": chat.title,
                        "username": chat.username,
                        "type": chat.type,
                        "active": True,
                        "owner_id": promoter.id,
                        "updated_at": utc_now(),
                    },
                    "$setOnInsert": {"created_at": utc_now()},
                },
                upsert=True,
            )

            logger.info(
                "Auto-registered channel %s (%s) via bot promotion",
                chat.title, chat.id,
            )

            with suppress(Exception):
                await bot.send_message(
                    chat_id=promoter.id,
                    text=(
                        "🎉 <b>Channel Linked Successfully!</b>\n\n"
                        f"• <b>Title:</b> {chat.title}\n"
                        f"• <b>ID:</b> <code>{chat.id}</code>\n\n"
                        "🛡️ Anti-Premium guard is now active."
                    ),
                )

        elif new_status in ("left", "kicked"):
            await channels_collection.update_one(
                {"chat_id": chat.id},
                {"$set": {"active": False, "updated_at": utc_now()}},
            )
            logger.info("Bot removed from channel %s", chat.id)

    except Exception:
        logger.exception("my_chat_member handler crashed")


# ============================================================
#        PREMIUM USER JOIN → AUTO BAN
# ============================================================

@dp.chat_member()
async def chat_member_handler(update: ChatMemberUpdated):
    try:
        chat = update.chat
        old_status = update.old_chat_member.status
        new_member = update.new_chat_member
        new_status = new_member.status
        user = new_member.user

        if chat.type not in (ChatType.CHANNEL, ChatType.SUPERGROUP):
            return

        if new_status != "member":
            return
        if old_status in ("member", "administrator", "creator"):
            return

        if not getattr(user, "is_premium", False):
            return

        reject_premium = await get_bool_setting("reject_premium", False)
        if not reject_premium:
            return

        channel = await channels_collection.find_one(
            {"chat_id": chat.id, "active": True}
        )
        if not channel:
            return

        try:
            await bot.ban_chat_member(chat_id=chat.id, user_id=user.id)
            logger.info(
                "BANNED premium user %s from channel %s",
                user.id, chat.id,
            )
        except TelegramBadRequest as error:
            logger.warning(
                "Ban failed for premium %s in %s: %s",
                user.id, chat.id, error,
            )

        await kick_logs_collection.insert_one(
            {
                "owner_id": channel.get("owner_id"),
                "channel_id": chat.id,
                "channel_title": chat.title,
                "user_id": user.id,
                "username": user.username,
                "first_name": user.first_name,
                "kicked_at": utc_now(),
            }
        )

        owner_id = channel.get("owner_id")
        if owner_id:
            with suppress(Exception):
                await bot.send_message(
                    chat_id=owner_id,
                    text=(
                        "🚫 <b>Premium User Removed</b>\n\n"
                        f"• Channel: <b>{chat.title}</b>\n"
                        f"• User: {user.full_name}\n"
                        f"• ID: <code>{user.id}</code>\n"
                        f"• Username: @{user.username or '-'}"
                    ),
                )

    except Exception:
        logger.exception("chat_member handler crashed")


# ============================================================
#                     JOIN REQUEST
# ============================================================

@dp.chat_join_request()
async def join_request_handler(request: ChatJoinRequest):
    user = request.from_user

    try:
        await save_user(user)

        await users_collection.update_one(
            {"user_id": user.id},
            {
                "$inc": {"join_requests": 1},
                "$set": {
                    "last_join_request": utc_now(),
                    "last_join_channel": request.chat.id,
                },
            },
        )

        channel = await channels_collection.find_one(
            {"chat_id": request.chat.id, "active": True}
        )

        reject_premium = await get_bool_setting("reject_premium", False)
        is_premium = bool(getattr(user, "is_premium", False))

        if reject_premium and is_premium:
            with suppress(Exception):
                await bot.decline_chat_join_request(
                    chat_id=request.chat.id,
                    user_id=user.id,
                )

            await kick_logs_collection.insert_one(
                {
                    "owner_id": channel.get("owner_id") if channel else None,
                    "channel_id": request.chat.id,
                    "channel_title": (
                        request.chat.title if channel else None
                    ),
                    "user_id": user.id,
                    "username": user.username,
                    "first_name": user.first_name,
                    "kicked_at": utc_now(),
                    "reason": "premium_join_request_declined",
                }
            )

            logger.info("Declined premium user %s", user.id)
            return

        auto_approve = await get_bool_setting("auto_approve", False)
        if auto_approve:
            with suppress(Exception):
                await bot.approve_chat_join_request(
                    chat_id=request.chat.id,
                    user_id=user.id,
                )
            logger.info("Auto-approved user %s", user.id)

        if not channel:
            logger.info(
                "Join request from unregistered channel: %s",
                request.chat.id,
            )
            return

        messages = await get_welcome_messages()
        if not messages:
            logger.warning(
                "Join request received but welcome messages missing."
            )
            return

        await send_welcome_messages(request.user_chat_id)
        logger.info("Welcome sequence sent to %s", user.id)

    except TelegramForbiddenError:
        await mark_user_blocked(user.id)
    except TelegramBadRequest as error:
        logger.warning(
            "Join request BadRequest for %s: %s", user.id, error
        )
    except Exception:
        logger.exception("Join request handler crashed")


# ============================================================
#                      CHANNEL LIST
# ============================================================

@dp.callback_query(F.data == "channels")
async def channels_callback(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    await callback.answer()

    text = "📡 <b>REGISTERED CHANNELS</b>\n\n"
    count = 0

    async for channel in channels_collection.find({"active": True}):
        count += 1
        title = channel.get("title", "Unknown")
        chat_id = channel.get("chat_id", "-")
        username = channel.get("username")
        username_text = f"@{username}" if username else "-"

        text += (
            f"• <b>{title}</b>\n"
            f"  ID: <code>{chat_id}</code>\n"
            f"  Username: {username_text}\n\n"
        )

    if count == 0:
        text += (
            "No channels registered.\n\n"
            "💡 Just add the bot as <b>admin</b> in any channel\n"
            "and it will be registered automatically."
        )

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="➕ Add Channel", callback_data="add_channel"
                )
            ],
            [
                InlineKeyboardButton(
                    text="⬅️ Back", callback_data="panel"
                )
            ],
        ]
    )

    await callback.message.edit_text(text, reply_markup=keyboard)


# ============================================================
#                      ADD CHANNEL
# ============================================================

@dp.callback_query(F.data == "add_channel")
async def add_channel_callback(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    await callback.answer()
    await state.set_state(BotStates.waiting_channel)

    await callback.message.answer(
        "📡 <b>Send channel username or ID.</b>\n\n"
        "Example:\n<code>@mychannel</code>\n\n"
        "Bot must be administrator of the channel.\n\n"
        "💡 Or just add the bot as admin — it will auto-register."
    )


@dp.message(BotStates.waiting_channel)
async def add_channel_message(message: Message, state: FSMContext):
    if not message.from_user:
        return
    if not is_owner(message.from_user.id):
        return

    if not message.text:
        await message.answer("❌ Please send a channel username or ID.")
        return

    channel_input = message.text.strip()

    try:
        chat = await bot.get_chat(channel_input)
        bot_info = await bot.get_me()
        member = await bot.get_chat_member(chat.id, bot_info.id)

        if member.status not in ("administrator", "creator"):
            await message.answer(
                "❌ Bot is not an administrator of this channel."
            )
            return

        await channels_collection.update_one(
            {"chat_id": chat.id},
            {
                "$set": {
                    "chat_id": chat.id,
                    "title": chat.title,
                    "username": chat.username,
                    "type": chat.type,
                    "active": True,
                    "owner_id": message.from_user.id,
                    "updated_at": utc_now(),
                },
                "$setOnInsert": {"created_at": utc_now()},
            },
            upsert=True,
        )

        await state.clear()

        await message.answer(
            "✅ <b>Channel registered.</b>\n\n"
            f"Title: <b>{chat.title}</b>\n"
            f"ID: <code>{chat.id}</code>\n"
            f"Username: @{chat.username or '-'}\n\n"
            "Make sure Join Requests are enabled."
        )

    except Exception as error:
        logger.exception("Failed to register channel")
        await message.answer(
            "❌ <b>Could not register channel.</b>\n\n"
            f"<code>{str(error)[:1500]}</code>"
        )


# ============================================================
#                       USER STATS
# ============================================================

@dp.callback_query(F.data == "users")
async def users_callback(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    total, reachable, blocked = await get_user_counts()
    premium_count = await users_collection.count_documents(
        {"is_premium": True}
    )
    total_kicks = await kick_logs_collection.count_documents({})
    total_unlocks = await unlock_collection.count_documents({})

    join_requests = await users_collection.aggregate(
        [{"$group": {"_id": None, "total": {"$sum": "$join_requests"}}}]
    ).to_list(length=1)

    total_join_requests = (
        join_requests[0].get("total", 0) if join_requests else 0
    )

    await callback.answer()

    await callback.message.edit_text(
        "👥 <b>USER STATISTICS</b>\n\n"
        f"👤 Total Users: <b>{total}</b>\n"
        f"🟢 Reachable: <b>{reachable}</b>\n"
        f"🚫 Blocked: <b>{blocked}</b>\n"
        f"💎 Premium: <b>{premium_count}</b>\n"
        f"📨 Join Requests: <b>{total_join_requests}</b>\n"
        f"🛡️ Premium Kicks: <b>{total_kicks}</b>\n"
        f"🔓 Unlock Tokens: <b>{total_unlocks}</b>",
        reply_markup=back_keyboard(),
    )


# ============================================================
#                    BROADCAST MENU
# ============================================================

@dp.callback_query(F.data == "broadcast")
async def broadcast_callback(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    running = [
        bid for bid, task in broadcast_tasks.items() if not task.done()
    ]
    if running:
        await callback.answer(
            "A broadcast is already running.", show_alert=True
        )
        return

    await callback.answer()
    await state.set_state(BotStates.waiting_broadcast_message)

    total, reachable, blocked = await get_user_counts()

    await callback.message.answer(
        "📢 <b>NEW BROADCAST</b>\n\n"
        f"👥 Reachable users: <b>{reachable}</b>\n"
        f"🚫 Blocked: <b>{blocked}</b>\n\n"
        "Send the <b>ONE Telegram message</b> you want to broadcast.\n\n"
        "🔓 <b>Unlock System:</b> URL buttons will auto-convert "
        "into unlock links.\n\n"
        "⚠️ This broadcast does NOT use your Setup Msg slots."
    )


# ============================================================
#                  CREATE BROADCAST
# ============================================================

@dp.message(BotStates.waiting_broadcast_message)
async def create_broadcast(message: Message, state: FSMContext):
    if not message.from_user:
        return
    if not is_owner(message.from_user.id):
        return

    # reply_markup bhi capture karo
    reply_markup_json = None
    if message.reply_markup:
        reply_markup_json = markup_to_json(message.reply_markup)

    source = {
        "source_chat_id": message.chat.id,
        "source_message_id": message.message_id,
        "reply_markup": reply_markup_json,
    }

    broadcast_id = f"{int(time.time())}-{message.message_id}"
    total = await users_collection.count_documents(
        {"blocked": {"$ne": True}}
    )

    await broadcasts_collection.insert_one(
        {
            "broadcast_id": broadcast_id,
            "source": source,
            "status": "queued",
            "total": total,
            "success": 0,
            "failed": 0,
            "blocked": 0,
            "processed": 0,
            "created_at": utc_now(),
            "owner_id": message.from_user.id,
        }
    )

    await state.clear()

    unlock_note = (
        "\n🔓 Unlock gating: <b>ON</b>\n"
        if (UNLOCK_ENABLED and reply_markup_json) else ""
    )

    progress_message = await message.answer(
        "📢 <b>BROADCAST STARTING...</b>\n\n"
        f"🆔 <code>{broadcast_id}</code>\n\n"
        f"👥 Total: <b>{total}</b>\n"
        "📤 Sent: <b>0</b>\n"
        "❌ Failed: <b>0</b>\n"
        "🚫 Blocked: <b>0</b>\n"
        f"⏳ Remaining: <b>{total}</b>\n"
        + unlock_note
        + "Status: <b>Starting...</b>"
    )

    task = asyncio.create_task(
        run_broadcast(
            broadcast_id=broadcast_id,
            source=source,
            owner_chat_id=message.chat.id,
            progress_message_id=progress_message.message_id,
        )
    )
    broadcast_tasks[broadcast_id] = task


# ============================================================
#                    GLOBAL RATE LIMITER
# ============================================================

async def broadcast_rate_limit():
    global last_broadcast_send_time
    if USE_PAID_BROADCAST:
        return
    interval = 1.0 / NORMAL_MESSAGES_PER_SECOND
    async with broadcast_lock:
        now = time.monotonic()
        wait_time = last_broadcast_send_time + interval - now
        if wait_time > 0:
            await asyncio.sleep(wait_time)
        last_broadcast_send_time = time.monotonic()


# ============================================================
#                 SEND BROADCAST WITH RETRY
#                 (with Unlock gating)
# ============================================================

async def send_broadcast_message(user_id: int, source: dict):
    max_attempts = 8
    for attempt in range(max_attempts):
        try:
            await broadcast_rate_limit()

            # reply_markup nikalo + unlock gate karo
            reply_markup = None
            markup_data = source.get("reply_markup")

            if markup_data:
                reply_markup = json_to_markup(markup_data)

                if UNLOCK_ENABLED and reply_markup:
                    reply_markup = await process_reply_markup_for_unlock(
                        reply_markup
                    )

            kwargs = {
                "chat_id": user_id,
                "from_chat_id": source["source_chat_id"],
                "message_id": source["source_message_id"],
            }

            if reply_markup:
                kwargs["reply_markup"] = reply_markup

            if USE_PAID_BROADCAST:
                kwargs["allow_paid_broadcast"] = True

            return await bot.copy_message(**kwargs)

        except TelegramRetryAfter as error:
            retry_seconds = float(error.retry_after)
            logger.warning(
                "FloodWait for %s: %.1f seconds",
                user_id, retry_seconds,
            )
            await asyncio.sleep(retry_seconds + 0.5)
            continue

        except (TelegramNetworkError, TelegramServerError) as error:
            delay = min(60, 2 ** min(attempt, 5))
            logger.warning(
                "Temporary error for %s: %s. Retry in %ss.",
                user_id, error, delay,
            )
            await asyncio.sleep(delay)
            continue

        except TelegramForbiddenError:
            raise
        except TelegramBadRequest:
            raise

        except Exception as error:
            if attempt >= max_attempts - 1:
                raise
            delay = min(30, 2 ** min(attempt, 5))
            logger.warning(
                "Unexpected error for %s: %s. Retry in %ss.",
                user_id, error, delay,
            )
            await asyncio.sleep(delay)

    raise RuntimeError("Telegram retry limit exceeded.")


# ============================================================
#                    BROADCAST PROGRESS
# ============================================================

def get_runtime(broadcast_id):
    return broadcast_runtime.get(broadcast_id)


async def update_broadcast_database(
    broadcast_id: str, runtime: dict, force: bool = False
):
    processed = runtime["success"] + runtime["failed"] + runtime["blocked"]

    if (
        not force
        and processed != runtime.get("last_db_processed", -1)
        and processed % PROGRESS_DB_EVERY != 0
    ):
        return

    await broadcasts_collection.update_one(
        {"broadcast_id": broadcast_id},
        {
            "$set": {
                "success": runtime["success"],
                "failed": runtime["failed"],
                "blocked": runtime["blocked"],
                "processed": processed,
                "updated_at": utc_now(),
            }
        },
    )
    runtime["last_db_processed"] = processed


async def make_progress_text(
    broadcast_id: str, runtime: dict, status: str
):
    total = runtime["total"]
    success = runtime["success"]
    failed = runtime["failed"]
    blocked = runtime["blocked"]
    processed = success + failed + blocked
    remaining = max(0, total - processed)
    elapsed = time.monotonic() - runtime["started_monotonic"]
    speed = processed / elapsed if elapsed > 0 else 0

    if speed > 0:
        eta_text = f"{int((remaining / speed) / 60)} min"
    else:
        eta_text = "-"

    return (
        "📢 <b>BROADCAST PROCESS</b>\n\n"
        f"🆔 <code>{broadcast_id}</code>\n\n"
        f"👥 Total: <b>{total}</b>\n"
        f"📤 Sent: <b>{success}</b>\n"
        f"❌ Failed: <b>{failed}</b>\n"
        f"🚫 Blocked: <b>{blocked}</b>\n"
        f"📊 Processed: <b>{processed}</b>\n"
        f"⏳ Remaining: <b>{remaining}</b>\n\n"
        f"⚡ Speed: <b>{speed:.1f}/sec</b>\n"
        f"🕐 ETA: <b>{eta_text}</b>\n\n"
        f"Status: <b>{status}</b>"
    )


async def progress_updater(
    broadcast_id, runtime, owner_chat_id, progress_message_id
):
    while True:
        try:
            await asyncio.sleep(PROGRESS_UPDATE_SECONDS)
            if runtime.get("finished"):
                break
            text = await make_progress_text(
                broadcast_id, runtime, "Running..."
            )
            try:
                await bot.edit_message_text(
                    chat_id=owner_chat_id,
                    message_id=progress_message_id,
                    text=text,
                )
            except TelegramBadRequest as error:
                if "message is not modified" not in str(error).lower():
                    logger.warning("Progress edit failed: %s", error)
        except asyncio.CancelledError:
            break
        except Exception:
            logger.exception("Progress updater crashed")


# ============================================================
#                    BROADCAST WORKER
# ============================================================

async def broadcast_worker(
    queue: asyncio.Queue, source: dict, runtime: dict
):
    while True:
        user_id = await queue.get()
        if user_id is None:
            queue.task_done()
            return

        try:
            await send_broadcast_message(user_id, source)
            await users_collection.update_one(
                {"user_id": user_id},
                {
                    "$inc": {"broadcast_received": 1},
                    "$set": {"last_broadcast_at": utc_now()},
                },
            )
            async with runtime["lock"]:
                runtime["success"] += 1

        except TelegramForbiddenError:
            await mark_user_blocked(user_id)
            async with runtime["lock"]:
                runtime["blocked"] += 1

        except TelegramBadRequest as error:
            logger.warning(
                "Broadcast BadRequest for %s: %s", user_id, error
            )
            await mark_user_blocked(user_id)
            async with runtime["lock"]:
                runtime["failed"] += 1

        except Exception:
            logger.exception("Broadcast failed for %s", user_id)
            async with runtime["lock"]:
                runtime["failed"] += 1

        finally:
            queue.task_done()


# ============================================================
#                    BROADCAST ENGINE
# ============================================================

async def run_broadcast(
    broadcast_id, source, owner_chat_id, progress_message_id
):
    logger.info("Broadcast started: %s", broadcast_id)

    runtime = {
        "total": 0,
        "success": 0,
        "failed": 0,
        "blocked": 0,
        "lock": asyncio.Lock(),
        "started_monotonic": time.monotonic(),
        "last_db_processed": -1,
        "finished": False,
    }
    broadcast_runtime[broadcast_id] = runtime

    updater_task = None
    worker_tasks = []
    queue = asyncio.Queue(maxsize=BROADCAST_WORKERS * 4)

    try:
        total = await users_collection.count_documents(
            {"blocked": {"$ne": True}}
        )
        runtime["total"] = total

        await broadcasts_collection.update_one(
            {"broadcast_id": broadcast_id},
            {
                "$set": {
                    "status": "running",
                    "total": total,
                    "started_at": utc_now(),
                }
            },
        )

        if total == 0:
            runtime["finished"] = True
            await broadcasts_collection.update_one(
                {"broadcast_id": broadcast_id},
                {
                    "$set": {
                        "status": "completed",
                        "total": 0,
                        "finished_at": utc_now(),
                    }
                },
            )
            await bot.edit_message_text(
                chat_id=owner_chat_id,
                message_id=progress_message_id,
                text="📢 <b>BROADCAST COMPLETED</b>\n\nTotal: 0",
            )
            return

        updater_task = asyncio.create_task(
            progress_updater(
                broadcast_id, runtime, owner_chat_id,
                progress_message_id,
            )
        )

        worker_count = min(BROADCAST_WORKERS, max(1, total))
        for _ in range(worker_count):
            worker_tasks.append(
                asyncio.create_task(
                    broadcast_worker(queue, source, runtime)
                )
            )

        cursor = users_collection.find(
            {"blocked": {"$ne": True}}, {"user_id": 1}
        )
        async for user in cursor:
            user_id = user.get("user_id")
            if not user_id:
                continue
            await queue.put(user_id)

        for _ in range(worker_count):
            await queue.put(None)

        await queue.join()
        await asyncio.gather(*worker_tasks, return_exceptions=True)

        processed = (
            runtime["success"] + runtime["failed"] + runtime["blocked"]
        )
        runtime["finished"] = True

        await update_broadcast_database(
            broadcast_id, runtime, force=True
        )

        await broadcasts_collection.update_one(
            {"broadcast_id": broadcast_id},
            {
                "$set": {
                    "status": "completed",
                    "total": total,
                    "success": runtime["success"],
                    "failed": runtime["failed"],
                    "blocked": runtime["blocked"],
                    "processed": processed,
                    "finished_at": utc_now(),
                }
            },
        )

        final_text = await make_progress_text(
            broadcast_id, runtime, "Completed ✅"
        )
        await bot.edit_message_text(
            chat_id=owner_chat_id,
            message_id=progress_message_id,
            text=final_text,
        )
        logger.info(
            "Broadcast completed: %s | total=%s success=%s failed=%s blocked=%s",
            broadcast_id, total, runtime["success"],
            runtime["failed"], runtime["blocked"],
        )

    except asyncio.CancelledError:
        runtime["finished"] = True
        processed = (
            runtime["success"] + runtime["failed"] + runtime["blocked"]
        )
        await broadcasts_collection.update_one(
            {"broadcast_id": broadcast_id},
            {
                "$set": {
                    "status": "cancelled",
                    "success": runtime["success"],
                    "failed": runtime["failed"],
                    "blocked": runtime["blocked"],
                    "processed": processed,
                    "updated_at": utc_now(),
                }
            },
        )
        with suppress(Exception):
            await bot.edit_message_text(
                chat_id=owner_chat_id,
                message_id=progress_message_id,
                text=await make_progress_text(
                    broadcast_id, runtime, "Cancelled 🛑"
                ),
            )
        raise

    except Exception:
        runtime["finished"] = True
        logger.exception("Broadcast crashed: %s", broadcast_id)
        processed = (
            runtime["success"] + runtime["failed"] + runtime["blocked"]
        )
        await broadcasts_collection.update_one(
            {"broadcast_id": broadcast_id},
            {
                "$set": {
                    "status": "failed",
                    "success": runtime["success"],
                    "failed": runtime["failed"],
                    "blocked": runtime["blocked"],
                    "processed": processed,
                    "updated_at": utc_now(),
                }
            },
        )
        with suppress(Exception):
            await bot.edit_message_text(
                chat_id=owner_chat_id,
                message_id=progress_message_id,
                text=await make_progress_text(
                    broadcast_id, runtime, "Failed ❌"
                ),
            )

    finally:
        runtime["finished"] = True
        if updater_task:
            updater_task.cancel()
            with suppress(asyncio.CancelledError):
                await updater_task
        for task in worker_tasks:
            if not task.done():
                task.cancel()
        broadcast_tasks.pop(broadcast_id, None)
        broadcast_runtime.pop(broadcast_id, None)


# ============================================================
#                BROADCAST STATISTICS
# ============================================================

@dp.callback_query(F.data == "broadcast_stats")
async def broadcast_stats_callback(callback: CallbackQuery):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not allowed.", show_alert=True)
        return

    latest = await broadcasts_collection.find_one(
        {}, sort=[("created_at", -1)]
    )
    await callback.answer()

    if not latest:
        text = (
            "📊 <b>BROADCAST STATISTICS</b>\n\n"
            "No broadcast found."
        )
    else:
        total = latest.get("total", 0)
        success = latest.get("success", 0)
        failed = latest.get("failed", 0)
        blocked = latest.get("blocked", 0)
        processed = latest.get(
            "processed", success + failed + blocked
        )

        text = (
            "📊 <b>LATEST BROADCAST</b>\n\n"
            f"🆔 ID:\n<code>{latest.get('broadcast_id')}</code>\n\n"
            f"📌 Status: <b>{latest.get('status')}</b>\n\n"
            f"👥 Total: <b>{total}</b>\n"
            f"📊 Processed: <b>{processed}</b>\n"
            f"📤 Sent: <b>{success}</b>\n"
            f"❌ Failed: <b>{failed}</b>\n"
            f"🚫 Blocked: <b>{blocked}</b>"
        )

    await callback.message.edit_text(text, reply_markup=back_keyboard())


# ============================================================
#                  PRIVATE USER TRACKING
# ============================================================

@dp.message()
async def track_private_users(message: Message):
    if message.chat.type != ChatType.PRIVATE:
        return
    if message.from_user:
        await save_user(message.from_user)


# ============================================================
#                    GLOBAL ERROR HANDLER
# ============================================================

@dp.errors()
async def global_error_handler(event):
    logger.error("Unhandled update error: %s", event.exception)
    return True


# ============================================================
#                  DATABASE INITIALIZATION
# ============================================================

async def initialize_database():
    await mongo.admin.command("ping")

    await users_collection.create_index("user_id", unique=True)
    await users_collection.create_index("blocked")
    await channels_collection.create_index("chat_id", unique=True)
    await broadcasts_collection.create_index("broadcast_id", unique=True)
    await broadcasts_collection.create_index("created_at")
    await kick_logs_collection.create_index("kicked_at")
    await kick_logs_collection.create_index("user_id")
    await unlock_collection.create_index("token", unique=True)

    await broadcasts_collection.update_many(
        {"status": {"$in": ["queued", "running"]}},
        {
            "$set": {
                "status": "interrupted_by_restart",
                "updated_at": utc_now(),
            }
        },
    )

    logger.info("MongoDB connected and initialized.")


# ============================================================
#                         STARTUP
# ============================================================

async def main():
    if not BOT_TOKEN or BOT_TOKEN == "PASTE_YOUR_BOT_TOKEN_HERE":
        raise RuntimeError(
            "Please put your BotFather token in BOT_TOKEN."
        )
    if not OWNER_IDS:
        raise RuntimeError(
            "Please put your Telegram numeric ID inside OWNER_IDS."
        )
    if not MONGO_URI or MONGO_URI == "PASTE_YOUR_MONGODB_URI_HERE":
        raise RuntimeError(
            "Please put your MongoDB URI in MONGO_URI."
        )
    if NORMAL_MESSAGES_PER_SECOND <= 0:
        raise RuntimeError(
            "NORMAL_MESSAGES_PER_SECOND must be > 0."
        )

    await initialize_database()

    me = await bot.get_me()
    global BOT_USERNAME_CACHE
    BOT_USERNAME_CACHE = me.username

    logger.info("Bot started: @%s | ID: %s", me.username, me.id)

    await dp.start_polling(
        bot,
        allowed_updates=dp.resolve_used_update_types(),
    )


# ============================================================
#                         RUN BOT
# ============================================================

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user.")
    except Exception:
        logger.exception("Fatal application error.")
    finally:
        with suppress(Exception):
            asyncio.run(mongo.close())