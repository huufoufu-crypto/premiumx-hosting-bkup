#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Subscription based Content Library Bot (pyTelegramBotAPI)
Run:  export BOT_TOKEN=... ; export OWNER_ID=... ; python3 bot.py

Deployer ko sirf placeholders fill karne hain (ya env vars se de do):
  BOT_USERNAME, SUPPORT_USERNAME, FORCE_CHANNEL_ID, FORCE_CHANNEL_LINK,
  STORAGE_CHANNEL_ID (private channel jahan content ki copy store hoti hai)
"""

# ════════════════════════════════════════════════════════════════
# 1. IMPORTS  (missing packages boot par auto-install ho jayenge)
# ════════════════════════════════════════════════════════════════
import os, sys, subprocess, importlib


def _ensure(pkg, mod):
    # Package nahi mila to pip se install kar do
    try:
        importlib.import_module(mod)
    except ImportError:
        print(f"[boot] installing {pkg} ...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", pkg])


_ensure("pyTelegramBotAPI", "telebot")
_ensure("requests", "requests")

import json, time, random, string, threading, shutil, logging, html, re, atexit, glob
from collections import deque, defaultdict
from datetime import datetime, timedelta
from urllib.parse import quote
import requests  # noqa: F401  (telebot ke liye dependency, yahan ensure ho gaya)
import telebot
from telebot import types
from telebot.apihelper import ApiTelegramException

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("bot")

# ════════════════════════════════════════════════════════════════
# 2. CONFIG
# ════════════════════════════════════════════════════════════════
BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
try:
    OWNER_ID = int(os.environ.get("OWNER_ID", "0"))
except ValueError:
    OWNER_ID = 0
if not BOT_TOKEN or not OWNER_ID:
    sys.exit("❌ BOT_TOKEN aur OWNER_ID environment variables set karo.")

# --- Placeholders (deployer fill karega) ---
BOT_USERNAME = os.environ.get("BOT_USERNAME", "BOT_USERNAME")
SUPPORT_USERNAME = os.environ.get("SUPPORT_USERNAME", "SUPPORT_USERNAME")
FORCE_CHANNEL_ID = os.environ.get("FORCE_CHANNEL_ID", "@FORCE_CHANNEL_USERNAME")
FORCE_CHANNEL_LINK = os.environ.get("FORCE_CHANNEL_LINK", "FORCE_CHANNEL_LINK")
STORAGE_CHANNEL_ID = os.environ.get("STORAGE_CHANNEL_ID", "")  # private channel id e.g. -100123...
PAYMENT_QR_URL = os.environ.get("PAYMENT_QR_URL", "")

DB_FILE = os.environ.get("DB_FILE", "database.json")
BACKUP_DIR = os.environ.get("BACKUP_DIR", "backups")
MAX_BACKUPS = 20
AUDIT_LIMIT = 500
PER_PAGE = 8

RATE = {"msg": (30, 60), "cb": (60, 60)}  # (limit, window seconds)

LEVEL_NAMES = {0: "Free", 1: "Basic", 2: "Pro", 3: "Premium", 4: "Lifetime"}
KIND_ICON = {"video": "🎬", "photo": "🖼️", "document": "📄", "link": "🔗", "text": "📝"}

# Admin roles -> permissions ("*" = sab kuch, owner-only chhod ke)
ROLE_PERMS = {
    "owner": {"*"},
    "full": {"*"},
    "users": {"view", "users", "payments"},
    "content": {"view", "sections", "content", "requests"},
    "view": {"view"},
}
ADMIN_PERM = {
    "dash": "view", "ana": "view", "usr": "users", "pay": "payments",
    "sec": "sections", "cnt": "content", "pln": "plans", "cpn": "coupons",
    "req": "requests", "tkt": "tickets", "bc": "broadcast", "set": "settings",
    "bk": "backup", "adm": "owner", "log": "settings",
}

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML", threaded=True, num_threads=8)

# ════════════════════════════════════════════════════════════════
# 3. DATABASE LAYER  (single JSON, atomic write, auto-backup)
# ════════════════════════════════════════════════════════════════
DB = {}
DB_LOCK = threading.RLock()
_dirty = False


def now():
    return int(time.time())


def default_db():
    def plan(pid, name, price, days, limit, level):
        return {"id": pid, "name": name, "price": price, "days": days,
                "limit": limit, "level": level, "active": True}  # limit 0 = unlimited
    return {
        "meta": {"created": now(), "counters": {}, "last_backup": 0},
        "users": {}, "sections": {}, "content": {}, "payments": {},
        "coupons": {}, "requests": {}, "tickets": {}, "admins": {},
        "scheduled": {}, "audit": [],
        "plans": {
            "free": plan("free", "Free Demo", 0, 0, 5, 0),
            "basic": plan("basic", "Basic", 80, 30, 50, 1),
            "pro": plan("pro", "Pro", 199, 30, 200, 2),
            "premium": plan("premium", "Premium", 499, 30, 0, 3),
            "lifetime": plan("lifetime", "Lifetime", 1499, 36500, 0, 4),
        },
        "settings": {
            "force_join": True, "force_channel_id": FORCE_CHANNEL_ID,
            "force_channel_link": FORCE_CHANNEL_LINK, "qr_url": PAYMENT_QR_URL,
            "support_username": SUPPORT_USERNAME, "maintenance": False,
            "auto_approve": False, "protect_content": True, "ref_reward": 10,
            "backup_hours": 6,
            "welcome": "👋 Namaste <b>{name}</b>!\nContent library mein swagat hai.\nNeeche se option chuno 👇",
        },
    }


def db_load():
    # Main file corrupt ho to latest backup se recover
    data = None
    for path in [DB_FILE] + sorted(glob.glob(os.path.join(BACKUP_DIR, "db_*.json")), reverse=True):
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                log.info("DB loaded from %s", path)
                break
            except Exception as e:
                log.error("DB load fail %s: %s", path, e)
    base = default_db()
    if data:
        for k, v in base.items():
            data.setdefault(k, v)
        for k, v in base["settings"].items():
            data["settings"].setdefault(k, v)
        return data
    return base


def db_save():
    # Atomic write: pehle tmp file, fsync, phir os.replace -> crash-safe
    global _dirty
    with DB_LOCK:
        tmp = DB_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(DB, f, ensure_ascii=False, separators=(",", ":"))
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, DB_FILE)
        _dirty = False


def save(now_=False):
    # Normal changes background thread flush karta hai; paise wale kaam turant save
    global _dirty
    _dirty = True
    if now_:
        db_save()


def db_backup():
    with DB_LOCK:
        db_save()
        os.makedirs(BACKUP_DIR, exist_ok=True)
        dst = os.path.join(BACKUP_DIR, "db_%s.json" % datetime.now().strftime("%Y%m%d_%H%M%S"))
        shutil.copy2(DB_FILE, dst)
        DB["meta"]["last_backup"] = now()
        old = sorted(glob.glob(os.path.join(BACKUP_DIR, "db_*.json")))
        for f in old[:-MAX_BACKUPS]:
            try:
                os.remove(f)
            except OSError:
                pass
        save()
        return dst


def nid(kind):
    # Auto-increment id generator (string)
    with DB_LOCK:
        c = DB["meta"]["counters"]
        c[kind] = c.get(kind, 0) + 1
        return str(c[kind])


# ════════════════════════════════════════════════════════════════
# 4. HELPERS
# ════════════════════════════════════════════════════════════════
USER_STATES = {}          # uid -> {"s": state_name, ...}
STATE_HANDLERS = {}       # state_name -> fn(m, st)
ROUTES = {}               # callback prefix -> fn(c, parts, u)
_rate = defaultdict(lambda: {"msg": deque(), "cb": deque()})
_last_cb = {}


def esc(x):
    return html.escape(str(x), quote=True)


def fdt(ts):
    return datetime.fromtimestamp(ts).strftime("%d-%b-%Y %H:%M") if ts else "—"


def money(x):
    return "₹%g" % x


def S(key, default=None):
    return DB["settings"].get(key, default)


def route(prefix):
    def d(f):
        ROUTES[prefix] = f
        return f
    return d


def state(name):
    def d(f):
        STATE_HANDLERS[name] = f
        return f
    return d


def set_state(uid, s, **kw):
    USER_STATES[uid] = dict(s=s, **kw)


def B(text, data):
    if data.startswith(("http://", "https://", "tg://")):
        return types.InlineKeyboardButton(text, url=data)
    return types.InlineKeyboardButton(text, callback_data=data)


def kb(*rows):
    m = types.InlineKeyboardMarkup()
    for r in rows:
        if r:
            m.row(*[B(t, d) for t, d in r])
    return m


def page_kb(items, page, per, make_btn, nav_prefix):
    # Generic pagination: rows return karta hai (nav buttons ke saath)
    total = len(items)
    pages = max(1, (total + per - 1) // per)
    page = max(0, min(page, pages - 1))
    rows = [[make_btn(i)] for i in items[page * per:(page + 1) * per]]
    if pages > 1:
        nav = []
        if page > 0:
            nav.append(("⬅️", f"{nav_prefix}:{page - 1}"))
        nav.append((f"{page + 1}/{pages}", "noop"))
        if page < pages - 1:
            nav.append(("➡️", f"{nav_prefix}:{page + 1}"))
        rows.append(nav)
    return rows


def send(chat_id, text, markup=None, **kw):
    try:
        return bot.send_message(chat_id, text[:4090], reply_markup=markup,
                                disable_web_page_preview=True, **kw)
    except ApiTelegramException as e:
        log.warning("send fail %s: %s", chat_id, e)
        return None


def show(c, text, markup=None):
    # edit -> (caption edit) -> delete + resend fallback
    chat, mid = c.message.chat.id, c.message.message_id
    text = text[:4090]
    try:
        bot.edit_message_text(text, chat, mid, reply_markup=markup, disable_web_page_preview=True)
        return
    except ApiTelegramException as e:
        err = str(e)
        if "not modified" in err:
            return
        if "no text in the message" in err:
            try:
                bot.edit_message_caption(text[:1020], chat, mid, reply_markup=markup)
                return
            except ApiTelegramException:
                pass
    try:
        bot.delete_message(chat, mid)
    except ApiTelegramException:
        pass
    send(chat, text, markup)


def alert(c, text):
    try:
        bot.answer_callback_query(c.id, text, show_alert=True)
    except ApiTelegramException:
        pass


def done(chat, text, back="m:home", label="🔙 Back"):
    send(chat, text, kb([(label, back)]))


def ask(c, text, state_name, back="m:home", **data):
    # Multi-step flow shuru karo: state set + cancel button
    set_state(c.from_user.id, state_name, back=back, **data)
    show(c, text, kb([("❌ Cancel", "x:c")]))


def ask_msg(chat, uid, text, state_name, back="m:home", **data):
    set_state(uid, state_name, back=back, **data)
    send(chat, text, kb([("❌ Cancel", "x:c")]))


def rate_limited(uid, kind):
    if is_staff(uid):
        return False
    limit, win = RATE[kind]
    dq = _rate[uid][kind]
    t = time.time()
    while dq and t - dq[0] > win:
        dq.popleft()
    if len(dq) >= limit:
        return True
    dq.append(t)
    return False


# ---- users ----
def get_user(uid, tg=None):
    with DB_LOCK:
        k = str(uid)
        u = DB["users"].get(k)
        if not u:
            u = {"id": uid, "name": "", "username": "", "joined": now(), "last_seen": now(),
                 "age_ok": False, "jc": 0, "onboarded": False, "banned": False, "blocked": False,
                 "plan": "free", "expiry": 0, "wallet": 0.0, "spent": 0, "ref_by": None,
                 "started": False, "refs": 0, "ref_earn": 0, "favs": [], "history": [],
                 "plan_views": [], "views": 0, "used_coupons": [], "txns": []}
            DB["users"][k] = u
        if tg:
            u["name"] = (tg.first_name or "") + ((" " + tg.last_name) if tg.last_name else "")
            u["username"] = tg.username or ""
        u["last_seen"] = now()
        save()
        return u


def plan_of(u):
    # Expire ho gaya plan to automatically Free par
    if u["plan"] != "free" and (u["plan"] not in DB["plans"] or (u["expiry"] and u["expiry"] < now())):
        u["plan"], u["expiry"], u["plan_views"] = "free", 0, []
        save()
    return DB["plans"].get(u["plan"]) or DB["plans"]["free"]


def level_of(u):
    return plan_of(u)["level"]


def credit(u, amt, note):
    u["wallet"] = round(u["wallet"] + amt, 2)
    u["txns"].append({"ts": now(), "amt": amt, "note": note})
    u["txns"] = u["txns"][-50:]
    save()


def activate_plan(u, pid):
    p = DB["plans"][pid]
    if u["plan"] == pid and u["expiry"] > now():
        u["expiry"] += p["days"] * 86400       # same plan = extend
    else:
        u["plan"] = pid
        u["expiry"] = now() + p["days"] * 86400 if p["days"] else 0
        u["plan_views"] = []
    u["spent"] += p["price"]
    save(True)


# ---- admin / roles ----
def admin_role(uid):
    if uid == OWNER_ID:
        return "owner"
    a = DB["admins"].get(str(uid))
    return a["role"] if a else None


def is_staff(uid):
    return admin_role(uid) is not None


def can(uid, perm):
    r = admin_role(uid)
    if not r:
        return False
    if r == "owner":
        return True
    if perm == "owner":
        return False
    p = ROLE_PERMS.get(r, set())
    return "*" in p or perm in p


def staff_for(perm):
    ids = {OWNER_ID}
    for k in DB["admins"]:
        if can(int(k), perm):
            ids.add(int(k))
    return ids


def notify_staff(perm, text, markup=None, photo=None):
    for sid in staff_for(perm):
        try:
            if photo:
                bot.send_photo(sid, photo, caption=text[:1020], reply_markup=markup)
            else:
                bot.send_message(sid, text[:4090], reply_markup=markup)
        except ApiTelegramException:
            pass


def audit(uid, action, detail=""):
    with DB_LOCK:
        DB["audit"].append({"ts": now(), "by": uid, "act": action, "d": str(detail)[:120]})
        DB["audit"] = DB["audit"][-AUDIT_LIMIT:]
        save()


# ---- content / sections ----
def sec_sorted(only_active=True):
    s = [x for x in DB["sections"].values() if x["active"] or not only_active]
    return sorted(s, key=lambda x: (x["order"], int(x["id"])))


def section_items(sid):
    items = [c for c in DB["content"].values() if c["section"] == sid]
    return sorted(items, key=lambda c: int(c["id"]))


def can_view(u, item):
    """(ok, reason). reason: demo/plan/preview/locked/limit/gone"""
    sec = DB["sections"].get(item["section"])
    if not sec or (not sec["active"] and not is_staff(u["id"])):
        return False, "gone"
    if is_staff(u["id"]) or item["type"] == "demo":
        return True, "demo"
    if level_of(u) >= sec["level"]:
        lim = plan_of(u)["limit"]
        if lim and item["id"] not in u["plan_views"] and len(u["plan_views"]) >= lim:
            return False, "limit"
        return True, "plan"
    ids = [i["id"] for i in section_items(sec["id"])]
    if item["id"] in ids[:sec["preview"]]:
        return True, "preview"
    return False, "locked"


def deliver(chat_id, item, markup=None):
    cap = "<b>%s</b>" % esc(item["title"])
    if item.get("desc"):
        cap += "\n" + esc(item["desc"])
    prot = bool(S("protect_content", True))
    k = item["kind"]
    try:
        if k == "video":
            bot.send_video(chat_id, item["file_id"], caption=cap[:1020], reply_markup=markup, protect_content=prot)
        elif k == "photo":
            bot.send_photo(chat_id, item["file_id"], caption=cap[:1020], reply_markup=markup, protect_content=prot)
        elif k == "document":
            bot.send_document(chat_id, item["file_id"], caption=cap[:1020], reply_markup=markup, protect_content=prot)
        elif k == "link":
            send(chat_id, cap + '\n\n🔗 <a href="%s">Open Link</a>' % esc(item["text"]), markup)
        else:
            send(chat_id, cap + "\n\n" + esc(item["text"]), markup)
    except ApiTelegramException as e:
        log.warning("deliver fail: %s", e)
        send(chat_id, "⚠️ Content bhejne mein error aaya. Support se contact karo.", markup)


def extract(m):
    # Message se content info nikalo (kind, file_id, text)
    ct = m.content_type
    if ct == "video":
        return {"kind": "video", "file_id": m.video.file_id, "text": "", "name": m.video.file_name or ""}
    if ct == "photo":
        return {"kind": "photo", "file_id": m.photo[-1].file_id, "text": "", "name": ""}
    if ct == "document":
        return {"kind": "document", "file_id": m.document.file_id, "text": "", "name": m.document.file_name or ""}
    if ct == "text" and m.text:
        t = m.text.strip()
        if re.match(r"^https?://\S+$", t):
            return {"kind": "link", "file_id": "", "text": t, "name": ""}
        return {"kind": "text", "file_id": "", "text": t, "name": ""}
    return None


def archive(m):
    # Private storage channel mein copy (best-effort)
    if STORAGE_CHANNEL_ID:
        try:
            bot.copy_message(STORAGE_CHANNEL_ID, m.chat.id, m.message_id)
        except Exception as e:
            log.warning("archive fail: %s", e)


def add_item(sec, ext, title, desc, typ):
    iid = nid("content")
    DB["content"][iid] = {"id": iid, "section": sec, "type": typ, "kind": ext["kind"],
                          "file_id": ext["file_id"], "text": ext["text"], "title": title[:100],
                          "desc": desc[:500], "added": now(), "views": 0}
    save()
    return iid


# ════════════════════════════════════════════════════════════════
# 5. KEYBOARDS
# ════════════════════════════════════════════════════════════════
def main_kb(u):
    rows = [
        [("📂 Sections", "s:l:0"), ("💎 Plans", "pl:list")],
        [("🎥 Request Video", "rq:home"), ("🆘 Help", "h:home")],
        [("👤 Profile", "u:prof"), ("💰 Wallet", "w:home")],
        [("🎟️ Coupons", "cp:home"), ("👥 Referral", "rf:home")],
    ]
    if is_staff(u["id"]):
        rows.append([("🛠 Admin Panel", "a:home")])
    return kb(*rows)


def support_url():
    return "https://t.me/" + str(S("support_username", SUPPORT_USERNAME)).lstrip("@")


def valid_link(x):
    return str(x).startswith(("http://", "https://", "tg://"))


# ════════════════════════════════════════════════════════════════
# 6. USER AUTH  (age gate, force-join, onboarding, /start)
# ════════════════════════════════════════════════════════════════
AGE_TEXT = ("🔞 <b>Age Verification</b>\n\nYeh bot sirf <b>18+</b> users ke liye hai.\n"
            "Kya aapki umar 18 saal ya usse zyada hai?")


def channel_cfg():
    ch = str(S("force_channel_id", "") or "")
    if not ch or "FORCE_CHANNEL" in ch:
        return None
    return ch


def is_member(uid, strict=False):
    ch = channel_cfg()
    if not ch:
        return True
    try:
        st = bot.get_chat_member(ch, uid).status
        return st in ("member", "administrator", "creator")
    except Exception as e:
        log.warning("member check fail: %s", e)
        return not strict  # bot channel mein admin na ho to fail-open


def needs_join(u):
    if not S("force_join") or not channel_cfg():
        return False
    if now() - u["jc"] < 600:
        return False
    if is_member(u["id"]):
        u["jc"] = now()
        return False
    return True


def join_kb():
    rows = []
    link = S("force_channel_link", "")
    if valid_link(link):
        rows.append([("📢 Join Channel", link)])
    rows.append([("✅ I've Joined – Verify", "jn:v")])
    return kb(*rows)


def onboard(u):
    # Pehli baar verify hone par referral reward
    u["onboarded"] = True
    ref = u.get("ref_by")
    if ref and str(ref) in DB["users"]:
        r = DB["users"][str(ref)]
        rew = float(S("ref_reward", 10))
        r["refs"] += 1
        r["ref_earn"] += rew
        credit(r, rew, "Referral reward")
        send(ref, "🎉 Aapke referral se <b>%s</b> join hua! Wallet mein %s add ho gaye." % (esc(u["name"]), money(rew)))
    save()


def gate(u, chat_id, c=None):
    # False return = user ko age/join screen dikha diya gaya
    if is_staff(u["id"]):
        return True

    def out(text, k):
        show(c, text, k) if c else send(chat_id, text, k)

    if not u["age_ok"]:
        out(AGE_TEXT, kb([("✅ Yes, 18+", "age:y"), ("❌ No", "age:n")]))
        return False
    if needs_join(u):
        out("📢 <b>Channel Join Required</b>\n\nBot use karne ke liye pehle channel join karo, phir Verify dabao.", join_kb())
        return False
    if not u["onboarded"]:
        onboard(u)
    return True


def menu_text(u):
    return str(S("welcome")).replace("{name}", esc(u["name"] or "User"))


@bot.message_handler(commands=["start"])
def cmd_start(m):
    if m.chat.type != "private":
        return
    uid = m.from_user.id
    if rate_limited(uid, "msg"):
        return
    first = str(uid) not in DB["users"]
    u = get_user(uid, m.from_user)
    parts = (m.text or "").split(maxsplit=1)
    if first and len(parts) > 1 and parts[1].startswith("ref_"):
        try:
            rid = int(parts[1][4:])
            if rid != uid and str(rid) in DB["users"]:
                u["ref_by"] = rid
        except ValueError:
            pass
    USER_STATES.pop(uid, None)
    if u["banned"]:
        return send(uid, "🚫 Aap ban ho chuke ho.")
    if S("maintenance") and not is_staff(uid):
        return send(uid, "🛠 Bot maintenance mode mein hai. Thodi der baad try karo.")
    if gate(u, uid):
        send(uid, menu_text(u), main_kb(u))


@route("age")
def r_age(c, p, u):
    if p[1] == "y":
        u["age_ok"] = True
        save()
        if gate(u, c.message.chat.id, c):
            show(c, menu_text(u), main_kb(u))
    else:
        show(c, "❌ Sorry, aap yeh bot use nahi kar sakte.")


@route("jn")
def r_join(c, p, u):
    if not is_member(u["id"], strict=True):
        return alert(c, "❌ Aapne abhi tak channel join nahi kiya!")
    u["jc"] = now()
    if gate(u, c.message.chat.id, c):
        show(c, menu_text(u), main_kb(u))


@route("x")
def r_cancel(c, p, u):
    st = USER_STATES.pop(c.from_user.id, None)
    dispatch(c, (st or {}).get("back", "m:home"))


@route("noop")
def r_noop(c, p, u):
    pass


# ════════════════════════════════════════════════════════════════
# 7. MAIN MENU / PROFILE
# ════════════════════════════════════════════════════════════════
@route("m")
def r_menu(c, p, u):
    USER_STATES.pop(c.from_user.id, None)
    show(c, menu_text(u), main_kb(u))


@route("u")
def r_user(c, p, u):
    act = p[1]
    uid = u["id"]
    if act == "prof":
        pl = plan_of(u)
        exp = "Lifetime ♾️" if pl["days"] >= 36500 else (fdt(u["expiry"]) if u["expiry"] else "—")
        txt = ("👤 <b>Profile</b>\n\n🆔 ID: <code>%s</code>\n📛 Name: %s\n💎 Plan: <b>%s</b> (Level %d)\n"
               "⏳ Expiry: %s\n💰 Wallet: %s\n📅 Joined: %s\n\n📊 <b>Stats</b>\n👁 Views: %d\n❤️ Favorites: %d\n"
               "👥 Referrals: %d\n💸 Total spent: %s") % (
            uid, esc(u["name"]), esc(pl["name"]), pl["level"], exp, money(u["wallet"]), fdt(u["joined"]),
            u["views"], len(u["favs"]), u["refs"], money(u["spent"]))
        show(c, txt, kb([("❤️ Favorites", "u:favs"), ("🕘 History", "u:hist")],
                        [("🔍 Search", "u:search")], [("🔙 Menu", "m:home")]))
    elif act in ("favs", "hist"):
        ids = u["favs"] if act == "favs" else list(reversed(u["history"]))[:15]
        items = [DB["content"][i] for i in ids if i in DB["content"]]
        title = "❤️ <b>Favorites</b>" if act == "favs" else "🕘 <b>Watch History</b>"
        if not items:
            return show(c, title + "\n\nAbhi kuch nahi hai.", kb([("🔙 Back", "u:prof")]))
        rows = [[(KIND_ICON[i["kind"]] + " " + i["title"][:40], "c:v:" + i["id"])] for i in items[:20]]
        rows.append([("🔙 Back", "u:prof")])
        show(c, title, kb(*rows))
    elif act == "search":
        ask(c, "🔍 Search karne ke liye title ka keyword bhejo:", "search", back="u:prof")


@state("search")
def st_search(m, st):
    uid = m.from_user.id
    if m.content_type != "text":
        return
    q = m.text.strip().lower()
    USER_STATES.pop(uid, None)
    u = get_user(uid)
    res = [i for i in DB["content"].values()
           if q in i["title"].lower() and DB["sections"].get(i["section"], {}).get("active")][:15]
    if not res:
        return done(uid, "😕 Kuch nahi mila.", "u:prof")
    rows = []
    for i in res:
        ok, _ = can_view(u, i)
        rows.append([("%s %s %s" % (KIND_ICON[i["kind"]], i["title"][:36], "" if ok else "🔒"), "c:v:" + i["id"])])
    rows.append([("🔙 Back", "u:prof")])
    send(uid, "🔍 <b>Results</b> for <i>%s</i>" % esc(q), kb(*rows))


# ════════════════════════════════════════════════════════════════
# 8. SECTIONS (locked / unlocked browsing)
# ════════════════════════════════════════════════════════════════
@route("s")
def r_sections(c, p, u):
    act = p[1]
    lvl = level_of(u)
    staff = is_staff(u["id"])
    if act == "l":
        page = int(p[2]) if len(p) > 2 else 0
        secs = sec_sorted()
        if not secs:
            return show(c, "📂 Abhi koi section nahi hai.", kb([("🔙 Menu", "m:home")]))
        rows = page_kb(secs, page, PER_PAGE, lambda s: (
            "%s %s %s (%d)" % (s["icon"], s["name"], "🔓" if (lvl >= s["level"] or staff) else "🔒",
                               len(section_items(s["id"]))), "s:o:%s:0" % s["id"]), "s:l")
        rows.append([("🔙 Menu", "m:home")])
        return show(c, "📂 <b>Sections</b>\n🔓 unlocked  |  🔒 upgrade required", kb(*rows))

    sec = DB["sections"].get(p[2])
    if not sec or not sec["active"]:
        return alert(c, "Section available nahi hai.")
    items = section_items(sec["id"])
    head = "%s <b>%s</b>\n%s\n" % (sec["icon"], esc(sec["name"]), esc(sec["description"]))

    if act == "o":
        page = int(p[3]) if len(p) > 3 else 0
        if lvl >= sec["level"] or staff:
            rows = page_kb(items, page, PER_PAGE, lambda i: (
                "%s %s%s" % (KIND_ICON[i["kind"]], i["title"][:40], " 🆓" if i["type"] == "demo" else ""),
                "c:v:" + i["id"]), "s:o:%s" % sec["id"])
            rows.append([("🔙 Sections", "s:l:0")])
            return show(c, head + "\n📦 Total items: <b>%d</b>" % len(items) if items else head + "\n(Abhi items nahi hain)", kb(*rows))
        rows = []
        if sec["preview"] and items:
            rows.append([("👀 Free Preview (%d)" % min(sec["preview"], len(items)), "s:pv:" + sec["id"])])
        rows.append([("💎 Upgrade to %s" % LEVEL_NAMES.get(sec["level"], "Plan"), "pl:list")])
        rows.append([("🔙 Sections", "s:l:0")])
        return show(c, head + "\n🔒 <b>Locked</b> — required: <b>%s</b>\n📦 Total items: <b>%d</b>\n👀 Free preview: <b>%d</b>"
                    % (LEVEL_NAMES.get(sec["level"], sec["level"]), len(items), sec["preview"]), kb(*rows))

    if act == "pv":
        prev = items[:sec["preview"]]
        rows = [[(KIND_ICON[i["kind"]] + " " + i["title"][:40], "c:v:" + i["id"])] for i in prev]
        rows.append([("💎 Upgrade", "pl:list")])
        rows.append([("🔙 Back", "s:o:%s:0" % sec["id"])])
        show(c, head + "\n👀 <b>Free Preview</b>", kb(*rows))


# ════════════════════════════════════════════════════════════════
# 9. CONTENT (watch, favorites, access check)
# ════════════════════════════════════════════════════════════════
@route("c")
def r_content(c, p, u):
    item = DB["content"].get(p[2])
    if not item:
        return alert(c, "Content nahi mila.")
    uid = u["id"]
    if p[1] == "f":
        if item["id"] in u["favs"]:
            u["favs"].remove(item["id"])
            alert(c, "💔 Favorite se hata diya")
        else:
            u["favs"].append(item["id"])
            alert(c, "❤️ Favorite mein add ho gaya")
        save()
        try:
            bot.edit_message_reply_markup(c.message.chat.id, c.message.message_id, reply_markup=content_kb(u, item))
        except ApiTelegramException:
            pass
        return
    ok, why = can_view(u, item)
    if not ok:
        sec = DB["sections"].get(item["section"])
        if why == "limit":
            txt = "⚠️ Aapke plan ki item limit (<b>%d</b>) poori ho gayi. Upgrade karo." % plan_of(u)["limit"]
        elif why == "gone":
            txt = "❌ Yeh content ab available nahi hai."
        else:
            txt = "🔒 Yeh content locked hai. Required: <b>%s</b>" % LEVEL_NAMES.get(sec["level"] if sec else 1, "Plan")
        return show(c, txt, kb([("💎 Upgrade", "pl:list")], [("🔙 Sections", "s:l:0")]))
    if why == "plan" and item["id"] not in u["plan_views"]:
        u["plan_views"].append(item["id"])
    u["views"] += 1
    item["views"] += 1
    if item["id"] in u["history"]:
        u["history"].remove(item["id"])
    u["history"] = (u["history"] + [item["id"]])[-50:]
    save()
    try:
        bot.answer_callback_query(c.id)
    except ApiTelegramException:
        pass
    deliver(c.message.chat.id, item, content_kb(u, item))


def content_kb(u, item):
    fav = "💔 Remove Favorite" if item["id"] in u["favs"] else "❤️ Favorite"
    return kb([(fav, "c:f:" + item["id"])], [("🔙 Section", "s:o:%s:0" % item["section"])])


# ════════════════════════════════════════════════════════════════
# 10. PAYMENT (plans, QR, proof, wallet purchase, approve/reject)
# ════════════════════════════════════════════════════════════════
def plans_sorted(active=True):
    return sorted([p for p in DB["plans"].values() if p["active"] or not active], key=lambda p: p["level"])


def plan_line(p):
    lim = "Unlimited" if not p["limit"] else str(p["limit"])
    days = "Lifetime" if p["days"] >= 36500 else ("%d days" % p["days"] if p["days"] else "—")
    return "💎 <b>%s</b> — %s • %s • %s items • Level %d" % (esc(p["name"]), money(p["price"]), days, lim, p["level"])


def qr_screen(chat, text, paid_cb):
    k = kb([("✅ I Paid", paid_cb)], [("❌ Cancel", "m:home")])
    url = S("qr_url", "")
    if valid_link(url):
        try:
            return bot.send_photo(chat, url, caption=text[:1020], reply_markup=k)
        except ApiTelegramException:
            text += "\n\n🔗 QR: " + esc(url)
    elif url:
        text += "\n\nUPI/Details: <code>%s</code>" % esc(url)
    send(chat, text, k)


@route("pl")
def r_plans(c, p, u):
    act = p[1]
    if act == "list":
        ps = plans_sorted()
        txt = "💎 <b>Subscription Plans</b>\n\n" + "\n".join(plan_line(x) for x in ps)
        txt += "\n\nAapka plan: <b>%s</b>" % esc(plan_of(u)["name"])
        rows = [[("%s — %s" % (x["name"], money(x["price"])) if x["price"] else x["name"] + " (Free)", "pl:v:" + x["id"])] for x in ps]
        rows.append([("🔙 Menu", "m:home")])
        return show(c, txt, kb(*rows))
    pl = DB["plans"].get(p[2])
    if not pl or not pl["active"]:
        return alert(c, "Plan available nahi hai.")
    if act == "v":
        txt = plan_line(pl)
        if pl["price"] <= 0:
            return show(c, txt + "\n\n🆓 Yeh free plan hai.", kb([("🔙 Plans", "pl:list")]))
        return show(c, txt, kb([("💳 Pay via QR/UPI", "pl:qr:" + pl["id"])],
                               [("💰 Pay from Wallet (%s)" % money(u["wallet"]), "pl:wal:" + pl["id"])],
                               [("🔙 Plans", "pl:list")]))
    if act == "qr":
        txt = ("💳 <b>Payment — %s</b>\n\nAmount: <b>%s</b>\n\n1️⃣ QR scan karke exact amount pay karo\n"
               "2️⃣ <b>I Paid</b> dabao\n3️⃣ Screenshot ya UTR number bhejo") % (esc(pl["name"]), money(pl["price"]))
        try:
            bot.delete_message(c.message.chat.id, c.message.message_id)
        except ApiTelegramException:
            pass
        return qr_screen(c.message.chat.id, txt, "pl:paid:" + pl["id"])
    if act == "paid":
        set_state(u["id"], "proof", back="pl:list", kind="plan", plan=pl["id"], amount=pl["price"])
        return show(c, "📤 Payment ka <b>screenshot</b> ya <b>UTR number</b> bhejo.", kb([("❌ Cancel", "x:c")]))
    if act == "wal":
        if u["wallet"] < pl["price"]:
            return alert(c, "❌ Wallet balance kam hai. Pehle top-up karo.")
        credit(u, -pl["price"], "Plan: " + pl["name"])
        activate_plan(u, pl["id"])
        audit(u["id"], "wallet_buy", pl["id"])
        show(c, "✅ <b>%s</b> activate ho gaya!\nBalance: %s" % (esc(pl["name"]), money(u["wallet"])), kb([("📂 Sections", "s:l:0")]))


@state("proof")
def st_proof(m, st):
    uid = m.from_user.id
    pay = {"id": nid("pay"), "uid": uid, "kind": st["kind"], "plan": st.get("plan"), "amount": st["amount"],
           "file_id": None, "utr": None, "status": "pending", "created": now(), "by": None, "ts": 0}
    if m.content_type == "photo":
        pay["file_id"] = m.photo[-1].file_id
        pay["utr"] = (m.caption or "").strip()[:30] or None
    elif m.content_type == "text":
        t = m.text.strip()
        if not re.match(r"^[A-Za-z0-9]{6,30}$", t):
            return send(uid, "⚠️ UTR valid nahi lag raha (6-30 letters/digits). Dobara bhejo ya screenshot do.")
        pay["utr"] = t
    else:
        return send(uid, "⚠️ Screenshot ya UTR text bhejo.")
    USER_STATES.pop(uid, None)
    DB["payments"][pay["id"]] = pay
    save(True)
    u = get_user(uid)
    if S("auto_approve"):
        approve_payment(pay["id"], 0)
        return
    send(uid, "⏳ Payment <b>#%s</b> submit ho gaya. Admin verify karke activate karega.\nSupport: @%s"
         % (pay["id"], esc(str(S("support_username")).lstrip("@"))), kb([("🏠 Menu", "m:home")]))
    what = DB["plans"][pay["plan"]]["name"] if pay["kind"] == "plan" and pay["plan"] in DB["plans"] else "Wallet Top-up"
    cap = "💳 <b>New Payment #%s</b>\n👤 %s (<code>%s</code>)\n📦 %s\n💵 %s\n🔢 UTR: %s" % (
        pay["id"], esc(u["name"]), uid, esc(what), money(pay["amount"]), esc(pay["utr"] or "—"))
    notify_staff("payments", cap, kb([("✅ Approve", "a:pay:ok:" + pay["id"]), ("❌ Reject", "a:pay:no:" + pay["id"])]),
                 photo=pay["file_id"])


def approve_payment(pid, by):
    with DB_LOCK:
        p = DB["payments"].get(pid)
        if not p or p["status"] != "pending":
            return False
        u = DB["users"].get(str(p["uid"]))
        p["status"], p["by"], p["ts"] = "approved", by, now()
        if p["kind"] == "plan" and p["plan"] in DB["plans"]:
            activate_plan(u, p["plan"])
            msg = "✅ Payment approved! <b>%s</b> activate ho gaya 🎉" % esc(DB["plans"][p["plan"]]["name"])
        else:
            credit(u, p["amount"], "Wallet top-up #" + pid)
            msg = "✅ Payment approved! Wallet mein %s add ho gaye." % money(p["amount"])
        save(True)
    send(p["uid"], msg, kb([("🏠 Menu", "m:home")]))
    audit(by, "pay_approve", "#" + pid)
    return True


def reject_payment(pid, by):
    p = DB["payments"].get(pid)
    if not p or p["status"] != "pending":
        return False
    p["status"], p["by"], p["ts"] = "rejected", by, now()
    save(True)
    send(p["uid"], "❌ Payment <b>#%s</b> reject ho gaya. Galat ho to support se contact karo." % pid)
    audit(by, "pay_reject", "#" + pid)
    return True


# ════════════════════════════════════════════════════════════════
# 11. WALLET
# ════════════════════════════════════════════════════════════════
@route("w")
def r_wallet(c, p, u):
    act = p[1]
    if act == "home":
        tx = "\n".join("%s %s • %s" % ("➕" if t["amt"] > 0 else "➖", money(abs(t["amt"])), esc(t["note"]))
                       for t in reversed(u["txns"][-8:])) or "Koi transaction nahi."
        return show(c, "💰 <b>Wallet</b>\n\nBalance: <b>%s</b>\n\n<b>Recent</b>\n%s" % (money(u["wallet"]), tx),
                    kb([("➕ Add Money", "w:add")], [("🎟️ Redeem Coupon", "cp:home")], [("🔙 Menu", "m:home")]))
    if act == "add":
        return ask(c, "💵 Kitne rupaye add karne hain? (min ₹10)", "topup_amt", back="w:home")
    if act == "paid":
        amt = float(p[2])
        set_state(u["id"], "proof", back="w:home", kind="topup", plan=None, amount=amt)
        show(c, "📤 Payment ka <b>screenshot</b> ya <b>UTR</b> bhejo.", kb([("❌ Cancel", "x:c")]))


@state("topup_amt")
def st_topup(m, st):
    uid = m.from_user.id
    try:
        amt = float((m.text or "").strip())
        assert 10 <= amt <= 100000
    except Exception:
        return send(uid, "⚠️ Valid amount bhejo (10 - 100000).")
    USER_STATES.pop(uid, None)
    qr_screen(uid, "💳 <b>Wallet Top-up</b>\n\nAmount: <b>%s</b>\nQR se pay karo, phir <b>I Paid</b> dabao." % money(amt),
              "w:paid:%g" % amt)


# ════════════════════════════════════════════════════════════════
# 12. COUPONS
# ════════════════════════════════════════════════════════════════
@route("cp")
def r_coupon(c, p, u):
    ask(c, "🎟️ Apna <b>coupon code</b> bhejo:", "coupon", back="m:home")


@state("coupon")
def st_coupon(m, st):
    uid = m.from_user.id
    if m.content_type != "text":
        return
    code = m.text.strip().upper()
    u = get_user(uid)
    cp = DB["coupons"].get(code)
    if not cp or not cp.get("active", True):
        return send(uid, "❌ Invalid coupon code.", kb([("🔙 Back", "m:home")]))
    if uid in cp["used_by"]:
        return send(uid, "⚠️ Aap yeh coupon pehle use kar chuke ho.")
    if len(cp["used_by"]) >= cp["max_uses"]:
        return send(uid, "⚠️ Coupon ki limit khatam ho gayi.")
    USER_STATES.pop(uid, None)
    cp["used_by"].append(uid)
    u["used_coupons"].append(code)
    if cp.get("plan") and cp["plan"] in DB["plans"]:
        activate_plan(u, cp["plan"])
        txt = "🎉 Coupon applied! <b>%s</b> plan activate ho gaya." % esc(DB["plans"][cp["plan"]]["name"])
    else:
        credit(u, cp["value"], "Coupon " + code)
        txt = "🎉 Coupon applied! Wallet mein %s add ho gaye." % money(cp["value"])
    save(True)
    done(uid, txt, "m:home", "🏠 Menu")


# ════════════════════════════════════════════════════════════════
# 13. REFERRAL
# ════════════════════════════════════════════════════════════════
@route("rf")
def r_referral(c, p, u):
    link = "https://t.me/%s?start=ref_%s" % (BOT_USERNAME.lstrip("@"), u["id"])
    txt = ("👥 <b>Referral Program</b>\n\nHar successful invite par aapko <b>%s</b> wallet mein milenge.\n\n"
           "🔗 Your link:\n<code>%s</code>\n\n👥 Invited: <b>%d</b>\n💰 Earned: <b>%s</b>") % (
        money(float(S("ref_reward", 10))), link, u["refs"], money(u["ref_earn"]))
    show(c, txt, kb([("📤 Share Link", "https://t.me/share/url?url=%s" % quote(link))], [("🔙 Menu", "m:home")]))


# ════════════════════════════════════════════════════════════════
# 14. VIDEO REQUESTS
# ════════════════════════════════════════════════════════════════
def pending_requests():
    r = [x for x in DB["requests"].values() if x["status"] == "pending"]
    return sorted(r, key=lambda x: (-len(x["votes"]), -x["created"]))


@route("rq")
def r_requests(c, p, u):
    act = p[1]
    uid = u["id"]
    if act == "home":
        return show(c, "🎥 <b>Video Requests</b>\n\nNayi video request karo ya doosron ki requests ko upvote karo.",
                    kb([("➕ New Request", "rq:new")], [("🔥 Top Requests", "rq:top")],
                       [("📋 My Requests", "rq:my")], [("🔙 Menu", "m:home")]))
    if act == "new":
        mine = [x for x in pending_requests() if x["uid"] == uid]
        if len(mine) >= 5:
            return alert(c, "Max 5 pending requests allowed.")
        return ask(c, "✍️ Kaunsi video/content chahiye? Title/description bhejo:", "req_new", back="rq:home")
    if act == "top":
        rs = pending_requests()[:10]
        if not rs:
            return show(c, "Abhi koi pending request nahi.", kb([("🔙 Back", "rq:home")]))
        rows = [[("👍 %d • %s" % (len(x["votes"]), x["text"][:35]), "rq:up:" + x["id"])] for x in rs]
        rows.append([("🔙 Back", "rq:home")])
        return show(c, "🔥 <b>Top Requests</b>\nUpvote karne ke liye tap karo:", kb(*rows))
    if act == "up":
        x = DB["requests"].get(p[2])
        if not x or x["status"] != "pending":
            return alert(c, "Request ab pending nahi hai.")
        if uid in x["votes"]:
            x["votes"].remove(uid)
            alert(c, "Vote hata diya")
        else:
            x["votes"].append(uid)
            alert(c, "👍 Upvoted!")
        save()
        return dispatch(c, "rq:top")
    if act == "my":
        mine = [x for x in DB["requests"].values() if x["uid"] == uid][-10:]
        txt = "📋 <b>My Requests</b>\n\n" + ("\n".join("#%s • %s • %s • 👍%d" % (x["id"], esc(x["text"][:30]), x["status"], len(x["votes"]))
                                                  for x in mine) or "Koi request nahi.")
        show(c, txt, kb([("🔙 Back", "rq:home")]))


@state("req_new")
def st_req_new(m, st):
    uid = m.from_user.id
    if m.content_type != "text" or len(m.text.strip()) < 3:
        return send(uid, "⚠️ Text mein request bhejo.")
    rid = nid("req")
    DB["requests"][rid] = {"id": rid, "uid": uid, "text": m.text.strip()[:300], "votes": [uid],
                           "status": "pending", "created": now()}
    USER_STATES.pop(uid, None)
    save()
    done(uid, "✅ Request <b>#%s</b> submit ho gayi!" % rid, "rq:home")
    notify_staff("requests", "🎥 <b>New Request #%s</b>\n%s" % (rid, esc(m.text[:300])), kb([("📋 Open", "a:req:v:" + rid)]))


# ════════════════════════════════════════════════════════════════
# 15. HELP / TICKETS
# ════════════════════════════════════════════════════════════════
TK_CATS = ["Payment", "Content", "Account", "Bug", "Other"]
TK_PRI = {"low": "🟢 Low", "med": "🟡 Medium", "high": "🔴 High"}


def ticket_text(t):
    icon = "🟢 Open" if t["status"] == "open" else "🔒 Closed"
    s = "🎫 <b>Ticket #%s</b> • %s\n📂 %s | ⚡ %s | 🕒 %s\n" % (t["id"], icon, esc(t["cat"]), TK_PRI.get(t["pri"], t["pri"]), fdt(t["created"]))
    for mm in t["msgs"][-8:]:
        who = "👤 User" if mm["from"] == "user" else "🛠 Support"
        s += "\n%s <i>%s</i>\n%s\n" % (who, fdt(mm["ts"]), esc(mm["text"]))
    return s[-3900:]


@route("h")
def r_help(c, p, u):
    act = p[1]
    uid = u["id"]
    if act == "home":
        return show(c, "🆘 <b>Help & Support</b>\n\nKoi problem ho to ticket banao.",
                    kb([("🎫 New Ticket", "h:new")], [("📋 My Tickets", "h:my")],
                       [("💬 Contact Support", support_url())], [("🔙 Menu", "m:home")]))
    if act == "new":
        rows = [[(x, "h:cat:" + x)] for x in TK_CATS] + [[("🔙 Back", "h:home")]]
        return show(c, "📂 Category chuno:", kb(*rows))
    if act == "cat":
        return show(c, "⚡ Priority chuno:", kb([(v, "h:pri:%s:%s" % (p[2], k)) for k, v in TK_PRI.items()], [("🔙 Back", "h:new")]))
    if act == "pri":
        return ask(c, "✍️ Apni problem detail mein likho:", "tk_msg", back="h:home", cat=p[2], pri=p[3])
    if act == "skip":
        st = USER_STATES.get(uid)
        if st and st["s"] == "tk_shot":
            create_ticket(uid, st, None)
        return
    if act == "my":
        ts = [t for t in DB["tickets"].values() if t["uid"] == uid][-10:]
        rows = [[("🎫 #%s • %s • %s" % (t["id"], t["status"], t["cat"]), "h:v:" + t["id"])] for t in reversed(ts)]
        rows.append([("🔙 Back", "h:home")])
        return show(c, "📋 <b>My Tickets</b>" if ts else "Koi ticket nahi.", kb(*rows))
    t = DB["tickets"].get(p[2])
    if not t or t["uid"] != uid:
        return alert(c, "Ticket nahi mila.")
    if act == "v":
        rows = []
        if t["status"] == "open":
            rows.append([("💬 Reply", "h:r:" + t["id"]), ("🔒 Close", "h:c:" + t["id"])])
        rows.append([("🔙 Back", "h:my")])
        return show(c, ticket_text(t), kb(*rows))
    if act == "r":
        return ask(c, "✍️ Apna reply likho:", "tk_reply", back="h:v:" + t["id"], tid=t["id"])
    if act == "c":
        t["status"] = "closed"
        save()
        dispatch(c, "h:v:" + t["id"])


@state("tk_msg")
def st_tk_msg(m, st):
    uid = m.from_user.id
    if m.content_type != "text":
        return send(uid, "⚠️ Text mein likho.")
    set_state(uid, "tk_shot", back="h:home", cat=st["cat"], pri=st["pri"], text=m.text.strip()[:1000])
    send(uid, "📸 Screenshot bhejna chahte ho? Photo bhejo ya Skip dabao.", kb([("⏭ Skip", "h:skip")], [("❌ Cancel", "x:c")]))


@state("tk_shot")
def st_tk_shot(m, st):
    if m.content_type != "photo":
        return send(m.from_user.id, "⚠️ Photo bhejo ya Skip dabao.", kb([("⏭ Skip", "h:skip")]))
    create_ticket(m.from_user.id, st, m.photo[-1].file_id)


def create_ticket(uid, st, shot):
    tid = nid("ticket")
    DB["tickets"][tid] = {"id": tid, "uid": uid, "cat": st["cat"], "pri": st["pri"], "status": "open",
                          "created": now(), "shot": shot,
                          "msgs": [{"from": "user", "text": st["text"], "ts": now()}]}
    USER_STATES.pop(uid, None)
    save(True)
    done(uid, "✅ Ticket <b>#%s</b> create ho gaya. Jaldi reply milega." % tid, "h:my", "📋 My Tickets")
    notify_staff("tickets", "🎫 <b>New Ticket #%s</b> (%s, %s)\n%s" % (tid, st["cat"], TK_PRI.get(st["pri"]), esc(st["text"][:500])),
                 kb([("💬 Open", "a:tkt:v:" + tid)]), photo=shot)


@state("tk_reply")
def st_tk_reply(m, st):
    uid = m.from_user.id
    t = DB["tickets"].get(st["tid"])
    if not t or m.content_type != "text":
        return
    t["msgs"].append({"from": "user", "text": m.text.strip()[:1000], "ts": now()})
    t["status"] = "open"
    USER_STATES.pop(uid, None)
    save()
    done(uid, "✅ Reply bhej diya.", "h:v:" + t["id"])
    notify_staff("tickets", "💬 Ticket <b>#%s</b> par naya user reply:\n%s" % (t["id"], esc(m.text[:500])), kb([("Open", "a:tkt:v:" + t["id"])]))


# ════════════════════════════════════════════════════════════════
# 16. ADMIN PANEL
# ════════════════════════════════════════════════════════════════
def admin_home_view(uid):
    us = DB["users"].values()
    active = sum(1 for x in us if level_of(x) > 0)
    rev = sum(p["amount"] for p in DB["payments"].values() if p["status"] == "approved")
    pp = sum(1 for p in DB["payments"].values() if p["status"] == "pending")
    pr = len(pending_requests())
    pt = sum(1 for t in DB["tickets"].values() if t["status"] == "open")
    today = now() - 86400
    txt = ("🛠 <b>Admin Dashboard</b> (%s)\n\n👥 Users: <b>%d</b> (+%d 24h) | 🚫 Banned: %d\n💎 Active subs: <b>%d</b>\n"
           "💰 Revenue: <b>%s</b>\n\n⏳ Pending payments: <b>%d</b>\n🎥 Pending requests: <b>%d</b>\n🎫 Open tickets: <b>%d</b>\n"
           "📦 Sections: %d | Items: %d") % (
        admin_role(uid), len(DB["users"]), sum(1 for x in us if x["joined"] > today), sum(1 for x in us if x["banned"]),
        active, money(rev), pp, pr, pt, len(DB["sections"]), len(DB["content"]))
    btn = [("👥 Users", "a:usr:home"), ("💳 Payments", "a:pay:home"), ("📂 Sections", "a:sec:home"),
           ("🎬 Content", "a:cnt:home"), ("💎 Plans", "a:pln:home"), ("🎟 Coupons", "a:cpn:home"),
           ("🎥 Requests", "a:req:l:0"), ("🎫 Tickets", "a:tkt:l:0"), ("📢 Broadcast", "a:bc:home"),
           ("📊 Analytics", "a:ana:home"), ("⚙️ Settings", "a:set:home"), ("💾 Backup", "a:bk:home"),
           ("🛡 Admins", "a:adm:home"), ("📜 Audit Log", "a:log:home")]
    allowed = [(t, d) for t, d in btn if can(uid, ADMIN_PERM[d.split(":")[1]])]
    rows = [allowed[i:i + 2] for i in range(0, len(allowed), 2)] + [[("🏠 User Menu", "m:home")]]
    return txt, kb(*rows)


@bot.message_handler(commands=["admin"])
def cmd_admin(m):
    if m.chat.type == "private" and is_staff(m.from_user.id):
        t, k = admin_home_view(m.from_user.id)
        send(m.chat.id, t, k)


@route("a")
def r_admin(c, p, u):
    uid = u["id"]
    if not is_staff(uid):
        return alert(c, "⛔ Access denied")
    mod = p[1] if len(p) > 1 else "home"
    if mod == "home":
        USER_STATES.pop(uid, None)
        t, k = admin_home_view(uid)
        return show(c, t, k)
    fn = ADMIN_MODS.get(mod)
    if not fn:
        return
    if not can(uid, ADMIN_PERM.get(mod, "owner")):
        return alert(c, "⛔ Is section ki permission nahi hai.")
    fn(c, p[2:] or ["home"], uid)


BK = ("🔙 Admin", "a:home")

# ---------- 16.1 Users ----------
def user_label(x):
    return "%s • %s • %s" % ((x["name"] or "User")[:18], DB["plans"].get(x["plan"], {"name": "Free"})["name"], x["id"])


def mod_users(c, a, uid):
    act = a[0]
    if act == "home":
        return show(c, "👥 <b>User Manager</b>", kb([("📋 List Users", "a:usr:l:0")], [("🔍 Search", "a:usr:s")], [BK]))
    if act == "l":
        us = sorted(DB["users"].values(), key=lambda x: -x["joined"])
        rows = page_kb(us, int(a[1]), PER_PAGE, lambda x: (user_label(x), "a:usr:v:%s" % x["id"]), "a:usr:l")
        return show(c, "👥 <b>Users</b> (%d)" % len(us), kb(*rows, [("🔙 Back", "a:usr:home")]))
    if act == "s":
        return ask(c, "🔍 User ID / username / name bhejo:", "usr_search", back="a:usr:home")
    x = DB["users"].get(a[1]) if len(a) > 1 else None
    if not x:
        return alert(c, "User nahi mila")
    ID = a[1]
    if act == "v":
        pl = plan_of(x)
        txt = ("👤 <b>%s</b> @%s\n🆔 <code>%s</code>\n💎 %s (exp: %s)\n💰 Wallet: %s\n💸 Spent: %s\n🚫 Banned: %s\n📅 Joined: %s"
               % (esc(x["name"]), esc(x["username"] or "-"), ID, esc(pl["name"]), fdt(x["expiry"]), money(x["wallet"]),
                  money(x["spent"]), "Yes" if x["banned"] else "No", fdt(x["joined"])))
        return show(c, txt, kb([("✅ Unban" if x["banned"] else "🚫 Ban", "a:usr:b:" + ID), ("🎁 Give Plan", "a:usr:gp:" + ID)],
                               [("💰 Adjust Wallet", "a:usr:w:" + ID), ("✉️ Message", "a:usr:dm:" + ID)],
                               [("⬇️ Remove Plan", "a:usr:rp:" + ID)], [("🔙 Back", "a:usr:l:0")]))
    if act == "b":
        if int(ID) == OWNER_ID:
            return alert(c, "Owner ko ban nahi kar sakte")
        x["banned"] = not x["banned"]
        save()
        audit(uid, "ban_toggle", ID)
        return mod_users(c, ["v", ID], uid)
    if act == "gp":
        if len(a) > 2:
            activate_plan(x, a[2])
            audit(uid, "give_plan", "%s->%s" % (ID, a[2]))
            send(int(ID), "🎁 Aapko <b>%s</b> plan mila!" % esc(DB["plans"][a[2]]["name"]))
            return mod_users(c, ["v", ID], uid)
        rows = [[(pl["name"], "a:usr:gp:%s:%s" % (ID, pl["id"]))] for pl in plans_sorted(False) if pl["id"] != "free"]
        return show(c, "Plan chuno:", kb(*rows, [("🔙 Back", "a:usr:v:" + ID)]))
    if act == "rp":
        x["plan"], x["expiry"], x["plan_views"] = "free", 0, []
        save()
        audit(uid, "remove_plan", ID)
        return mod_users(c, ["v", ID], uid)
    if act == "w":
        return ask(c, "💰 Amount bhejo: <code>+100</code> add ya <code>-50</code> deduct", "usr_wallet", back="a:usr:v:" + ID, target=ID)
    if act == "dm":
        return ask(c, "✉️ User ko bhejne wala message likho:", "usr_dm", back="a:usr:v:" + ID, target=ID)


@state("usr_search")
def st_usr_search(m, st):
    q = (m.text or "").strip().lower().lstrip("@")
    res = [x for x in DB["users"].values() if q == str(x["id"]) or q in x["username"].lower() or q in x["name"].lower()][:10]
    USER_STATES.pop(m.from_user.id, None)
    rows = [[(user_label(x), "a:usr:v:%s" % x["id"])] for x in res] + [[("🔙 Back", "a:usr:home")]]
    send(m.chat.id, "🔍 Results: %d" % len(res), kb(*rows))


@state("usr_wallet")
def st_usr_wallet(m, st):
    try:
        amt = float(m.text.strip())
    except Exception:
        return send(m.chat.id, "⚠️ Number bhejo, e.g. +100 / -50")
    x = DB["users"].get(st["target"])
    USER_STATES.pop(m.from_user.id, None)
    credit(x, amt, "Admin adjustment")
    save(True)
    audit(m.from_user.id, "wallet_adjust", "%s %+g" % (st["target"], amt))
    send(int(st["target"]), "💰 Wallet update: %s%s" % ("+" if amt > 0 else "-", money(abs(amt))))
    done(m.chat.id, "✅ Done. New balance: %s" % money(x["wallet"]), "a:usr:v:" + st["target"])


@state("usr_dm")
def st_usr_dm(m, st):
    USER_STATES.pop(m.from_user.id, None)
    try:
        bot.copy_message(int(st["target"]), m.chat.id, m.message_id)
        txt = "✅ Message bhej diya."
    except ApiTelegramException as e:
        txt = "❌ Fail: %s" % esc(e)
    audit(m.from_user.id, "dm", st["target"])
    done(m.chat.id, txt, "a:usr:v:" + st["target"])


# ---------- 16.2 Payments ----------
def mod_payments(c, a, uid):
    act = a[0]
    if act == "home":
        pend = [p for p in DB["payments"].values() if p["status"] == "pending"]
        rows = [[("#%s • %s • %s" % (p["id"], money(p["amount"]), p["kind"]), "a:pay:v:" + p["id"])] for p in pend[:15]]
        auto = "🟢 ON" if S("auto_approve") else "🔴 OFF"
        rows += [[("⚡ Auto-approve: " + auto, "a:pay:auto")], [("🕘 History", "a:pay:h")], [BK]]
        return show(c, "💳 <b>Payment Manager</b>\nPending: <b>%d</b>" % len(pend), kb(*rows))
    if act == "auto":
        DB["settings"]["auto_approve"] = not S("auto_approve")
        save()
        audit(uid, "auto_approve", S("auto_approve"))
        return mod_payments(c, ["home"], uid)
    if act == "h":
        hist = sorted([p for p in DB["payments"].values() if p["status"] != "pending"], key=lambda p: -p["ts"])[:15]
        txt = "🕘 <b>Recent</b>\n\n" + ("\n".join("#%s %s %s %s" % (p["id"], "✅" if p["status"] == "approved" else "❌", money(p["amount"]), p["uid"]) for p in hist) or "—")
        return show(c, txt, kb([("🔙 Back", "a:pay:home")]))
    p = DB["payments"].get(a[1])
    if not p:
        return alert(c, "Payment nahi mila")
    if act == "v":
        txt = "💳 <b>Payment #%s</b>\n👤 <code>%s</code>\n📦 %s %s\n💵 %s\n🔢 UTR: %s\n📌 %s • %s" % (
            p["id"], p["uid"], p["kind"], p.get("plan") or "", money(p["amount"]), esc(p["utr"] or "—"), p["status"], fdt(p["created"]))
        if p["file_id"]:
            try:
                bot.send_photo(c.message.chat.id, p["file_id"], caption="Proof #" + p["id"])
            except ApiTelegramException:
                pass
        k = [("✅ Approve", "a:pay:ok:" + p["id"]), ("❌ Reject", "a:pay:no:" + p["id"])] if p["status"] == "pending" else []
        return show(c, txt, kb(k, [("🔙 Back", "a:pay:home")]))
    if act in ("ok", "no"):
        ok = approve_payment(a[1], uid) if act == "ok" else reject_payment(a[1], uid)
        show(c, ("✅ Payment #%s %s" % (a[1], "approved" if act == "ok" else "rejected")) if ok else "⚠️ Already processed.",
             kb([("💳 Payments", "a:pay:home")]))


# ---------- 16.3 Sections ----------
def mod_sections(c, a, uid):
    act = a[0]
    if act == "home":
        rows = [[("%s %s %s" % (s["icon"], s["name"], "🟢" if s["active"] else "🔴"), "a:sec:v:" + s["id"])] for s in sec_sorted(False)]
        rows += [[("➕ New Section", "a:sec:new")], [BK]]
        return show(c, "📂 <b>Section Manager</b>", kb(*rows))
    if act == "new":
        return ask(c, "➕ Format bhejo:\n<code>Name | Emoji | Description | Level(0-4) | FreePreviewCount</code>\n\nEx: <code>Movies | 🎬 | Latest movies | 1 | 3</code>",
                   "sec_new", back="a:sec:home")
    s = DB["sections"].get(a[1]) if len(a) > 1 else None
    if not s:
        return alert(c, "Section nahi mila")
    ID = s["id"]
    if act == "v":
        txt = "%s <b>%s</b>\n%s\n\n🔑 Level: %s (%d)\n👀 Preview: %d\n📦 Items: %d\n🔘 Active: %s" % (
            s["icon"], esc(s["name"]), esc(s["description"]), LEVEL_NAMES[s["level"]], s["level"], s["preview"],
            len(section_items(ID)), "Yes" if s["active"] else "No")
        return show(c, txt, kb([("🔘 Toggle Active", "a:sec:t:" + ID), ("🔑 Level", "a:sec:lv:" + ID)],
                               [("✏️ Name", "a:sec:e:%s:name" % ID), ("😀 Emoji", "a:sec:e:%s:icon" % ID)],
                               [("📝 Desc", "a:sec:e:%s:description" % ID), ("👀 Preview", "a:sec:e:%s:preview" % ID)],
                               [("⬆️ Up", "a:sec:mu:" + ID), ("⬇️ Down", "a:sec:md:" + ID)],
                               [("🗑 Delete", "a:sec:d:" + ID), ("🔙 Back", "a:sec:home")]))
    if act == "t":
        s["active"] = not s["active"]
        save()
        audit(uid, "sec_toggle", ID)
        return mod_sections(c, ["v", ID], uid)
    if act == "lv":
        if len(a) > 2:
            s["level"] = int(a[2])
            save()
            audit(uid, "sec_level", "%s=%s" % (ID, a[2]))
            return mod_sections(c, ["v", ID], uid)
        return show(c, "🔑 Required level:", kb([(LEVEL_NAMES[i], "a:sec:lv:%s:%d" % (ID, i)) for i in range(5)], [("🔙", "a:sec:v:" + ID)]))
    if act == "e":
        return ask(c, "✏️ Naya <b>%s</b> bhejo:" % a[2], "sec_edit", back="a:sec:v:" + ID, sid=ID, field=a[2])
    if act in ("mu", "md"):
        order = sec_sorted(False)
        i = order.index(s)
        j = i - 1 if act == "mu" else i + 1
        if 0 <= j < len(order):
            order[i], order[j] = order[j], order[i]
            for n, x in enumerate(order):
                x["order"] = n
            save()
        return mod_sections(c, ["home"], uid)
    if act == "d":
        return show(c, "⚠️ <b>%s</b> aur uske <b>%d</b> items delete karne hain?" % (esc(s["name"]), len(section_items(ID))),
                    kb([("✅ Yes, delete", "a:sec:dd:" + ID), ("❌ No", "a:sec:v:" + ID)]))
    if act == "dd":
        for i in section_items(ID):
            DB["content"].pop(i["id"], None)
        DB["sections"].pop(ID, None)
        save(True)
        audit(uid, "sec_delete", ID)
        mod_sections(c, ["home"], uid)


@state("sec_new")
def st_sec_new(m, st):
    try:
        n, ic, d, lv, pv = [x.strip() for x in m.text.split("|")][:5]
        lv, pv = int(lv), int(pv)
        assert 0 <= lv <= 4 and pv >= 0
    except Exception:
        return send(m.chat.id, "⚠️ Format galat. Dobara bhejo (5 fields, | se alag).")
    sid = nid("sec")
    DB["sections"][sid] = {"id": sid, "name": n[:40], "icon": ic[:4], "description": d[:300], "level": lv, "preview": pv,
                           "active": True, "order": len(DB["sections"])}
    USER_STATES.pop(m.from_user.id, None)
    save(True)
    audit(m.from_user.id, "sec_create", sid)
    done(m.chat.id, "✅ Section created!", "a:sec:v:" + sid)


@state("sec_edit")
def st_sec_edit(m, st):
    s = DB["sections"].get(st["sid"])
    v = (m.text or "").strip()
    if not s or not v:
        return
    if st["field"] == "preview":
        try:
            v = int(v)
        except ValueError:
            return send(m.chat.id, "⚠️ Number bhejo.")
    s[st["field"]] = v
    USER_STATES.pop(m.from_user.id, None)
    save()
    audit(m.from_user.id, "sec_edit", "%s.%s" % (st["sid"], st["field"]))
    done(m.chat.id, "✅ Updated.", "a:sec:v:" + st["sid"])


# ---------- 16.4 Content ----------
def mod_content(c, a, uid):
    act = a[0]
    if act == "home":
        rows = [[("%s %s (%d)" % (s["icon"], s["name"], len(section_items(s["id"]))), "a:cnt:s:" + s["id"])] for s in sec_sorted(False)]
        return show(c, "🎬 <b>Content Manager</b>\nSection chuno:" if rows else "Pehle section banao.", kb(*rows, [BK]))
    if act == "s":
        s = DB["sections"].get(a[1])
        if not s:
            return
        return show(c, "%s <b>%s</b> — %d items" % (s["icon"], esc(s["name"]), len(section_items(s["id"]))),
                    kb([("➕ Single Upload", "a:cnt:us:" + s["id"]), ("📦 Bulk Upload", "a:cnt:ub:" + s["id"])],
                       [("📋 List Items", "a:cnt:l:%s:0" % s["id"])], [("🔙 Back", "a:cnt:home")]))
    if act == "l":
        items = section_items(a[1])
        rows = page_kb(items, int(a[2]), PER_PAGE, lambda i: ("%s %s [%s]" % (KIND_ICON[i["kind"]], i["title"][:30], i["type"]), "a:cnt:i:" + i["id"]), "a:cnt:l:" + a[1])
        return show(c, "📋 <b>Items</b>", kb(*rows, [("🔙 Back", "a:cnt:s:" + a[1])]))
    if act == "us":
        return ask(c, "📤 Content bhejo (video / photo / document / link / text):", "up_single", back="a:cnt:s:" + a[1], sec=a[1], step="media")
    if act == "ub":
        set_state(uid, "up_bulk", back="a:cnt:s:" + a[1], sec=a[1], typ="paid", count=0)
        return show(c, bulk_text("paid", 0), bulk_kb("paid"))
    if act == "bt":
        st = USER_STATES.get(uid)
        if st and st["s"] == "up_bulk":
            st["typ"] = "demo" if st["typ"] == "paid" else "paid"
            return show(c, bulk_text(st["typ"], st["count"]), bulk_kb(st["typ"]))
    if act == "bd":
        st = USER_STATES.pop(uid, None)
        if st:
            audit(uid, "bulk_upload", "%s x%d" % (st["sec"], st["count"]))
            return show(c, "✅ Bulk upload complete: <b>%d</b> items." % st["count"], kb([("🔙 Section", "a:cnt:s:" + st["sec"])]))
    if act == "ut":  # single upload ka final step: type choose
        st = USER_STATES.pop(uid, None)
        if st and st["s"] == "up_single" and st["step"] == "type":
            iid = add_item(st["sec"], st["ext"], st["title"], st["desc"], a[1])
            audit(uid, "content_add", iid)
            return show(c, "✅ Item <b>#%s</b> save ho gaya!" % iid, kb([("➕ Aur Upload", "a:cnt:us:" + st["sec"])], [("🔙 Section", "a:cnt:s:" + st["sec"])]))
    i = DB["content"].get(a[1]) if len(a) > 1 else None
    if not i:
        return alert(c, "Item nahi mila")
    ID = i["id"]
    if act == "i":
        return show(c, "%s <b>%s</b>\n%s\n\n🏷 Type: %s | 👁 Views: %d | Section: %s" % (
            KIND_ICON[i["kind"]], esc(i["title"]), esc(i["desc"]), i["type"], i["views"], DB["sections"].get(i["section"], {}).get("name", "?")),
            kb([("👁 Preview", "a:cnt:pv:" + ID), ("🏷 Demo/Paid", "a:cnt:t:" + ID)],
               [("✏️ Title", "a:cnt:e:%s:title" % ID), ("📝 Desc", "a:cnt:e:%s:desc" % ID)],
               [("📂 Move", "a:cnt:mv:" + ID), ("🗑 Delete", "a:cnt:d:" + ID)],
               [("🔙 Back", "a:cnt:l:%s:0" % i["section"])]))
    if act == "pv":
        return deliver(c.message.chat.id, i)
    if act == "t":
        i["type"] = "demo" if i["type"] == "paid" else "paid"
        save()
        return mod_content(c, ["i", ID], uid)
    if act == "e":
        return ask(c, "✏️ Naya <b>%s</b> bhejo:" % a[2], "cnt_edit", back="a:cnt:i:" + ID, iid=ID, field=a[2])
    if act == "mv":
        if len(a) > 2:
            i["section"] = a[2]
            save()
            return mod_content(c, ["i", ID], uid)
        rows = [[(s["icon"] + " " + s["name"], "a:cnt:mv:%s:%s" % (ID, s["id"]))] for s in sec_sorted(False)]
        return show(c, "📂 Naya section:", kb(*rows, [("🔙", "a:cnt:i:" + ID)]))
    if act == "d":
        return show(c, "⚠️ Item delete karein?", kb([("✅ Yes", "a:cnt:dd:" + ID), ("❌ No", "a:cnt:i:" + ID)]))
    if act == "dd":
        DB["content"].pop(ID, None)
        save(True)
        audit(uid, "content_delete", ID)
        show(c, "🗑 Deleted.", kb([("🔙 Section", "a:cnt:s:" + i["section"])]))


def bulk_text(typ, n):
    return ("📦 <b>Bulk Upload</b>\n\nAb ek ke baad ek files/links/text bhejte jao — har message ek item banega.\n"
            "Title = caption ya file name.\n\nDefault type: <b>%s</b>\nSaved: <b>%d</b>" % (typ, n))


def bulk_kb(typ):
    return kb([("🏷 Type: %s (toggle)" % typ, "a:cnt:bt")], [("✅ Done", "a:cnt:bd")])


@state("up_bulk")
def st_up_bulk(m, st):
    ext = extract(m)
    if not ext:
        return
    title = ((m.caption or "").split("\n")[0].strip() or ext["name"] or (ext["text"][:40] if ext["kind"] in ("text", "link") else "")
             or "Item %s" % (st["count"] + 1))
    iid = add_item(st["sec"], ext, title, "", st["typ"])
    archive(m)
    st["count"] += 1
    send(m.chat.id, "✅ #%s saved (%d)" % (iid, st["count"]), kb([("✅ Done", "a:cnt:bd")]))


@state("up_single")
def st_up_single(m, st):
    uid = m.from_user.id
    step = st["step"]
    if step == "media":
        ext = extract(m)
        if not ext:
            return send(uid, "⚠️ Supported: video, photo, document, link, text.")
        archive(m)
        st["ext"], st["step"] = ext, "title"
        st["cap"] = (m.caption or "").split("\n")[0].strip() or ext["name"]
        return send(uid, "✏️ <b>Title</b> bhejo (default ke liye <code>-</code>):", kb([("❌ Cancel", "x:c")]))
    if m.content_type != "text":
        return
    t = m.text.strip()
    if step == "title":
        st["title"] = (st["cap"] or "Untitled") if t == "-" else t
        st["step"] = "desc"
        return send(uid, "📝 <b>Description</b> bhejo (skip: <code>-</code>):", kb([("❌ Cancel", "x:c")]))
    if step == "desc":
        st["desc"] = "" if t == "-" else t
        st["step"] = "type"
        send(uid, "🏷 Type chuno:", kb([("🆓 Demo (free)", "a:cnt:ut:demo"), ("💎 Paid", "a:cnt:ut:paid")]))


@state("cnt_edit")
def st_cnt_edit(m, st):
    i = DB["content"].get(st["iid"])
    if i and m.content_type == "text":
        i[st["field"]] = m.text.strip()[:500]
        USER_STATES.pop(m.from_user.id, None)
        save()
        done(m.chat.id, "✅ Updated.", "a:cnt:i:" + i["id"])


# ---------- 16.5 Plans ----------
def mod_plans(c, a, uid):
    act = a[0]
    if act == "home":
        rows = [[("%s %s %s" % (p["name"], money(p["price"]), "🟢" if p["active"] else "🔴"), "a:pln:v:" + p["id"])] for p in plans_sorted(False)]
        return show(c, "💎 <b>Plans Editor</b>", kb(*rows, [("➕ Add Plan", "a:pln:new")], [BK]))
    if act == "new":
        return ask(c, "➕ Format:\n<code>Name | Price | Days | ItemLimit(0=unlimited) | Level(1-4)</code>\nEx: <code>Gold | 299 | 60 | 0 | 3</code>",
                   "pln_new", back="a:pln:home")
    p = DB["plans"].get(a[1]) if len(a) > 1 else None
    if not p:
        return alert(c, "Plan nahi mila")
    ID = p["id"]
    if act == "v":
        return show(c, plan_line(p) + "\nActive: %s" % ("Yes" if p["active"] else "No"),
                    kb([("✏️ Name", "a:pln:e:%s:name" % ID), ("💵 Price", "a:pln:e:%s:price" % ID)],
                       [("📆 Days", "a:pln:e:%s:days" % ID), ("📦 Limit", "a:pln:e:%s:limit" % ID)],
                       [("🔑 Level", "a:pln:e:%s:level" % ID), ("🔘 Toggle", "a:pln:t:" + ID)],
                       [("?? Delete", "a:pln:d:" + ID), ("🔙 Back", "a:pln:home")]))
    if act == "t":
        if ID == "free":
            return alert(c, "Free plan disable nahi ho sakta")
        p["active"] = not p["active"]
        save()
        return mod_plans(c, ["v", ID], uid)
    if act == "e":
        return ask(c, "✏️ Naya <b>%s</b> bhejo:" % a[2], "pln_edit", back="a:pln:v:" + ID, pid=ID, field=a[2])
    if act == "d":
        if ID == "free":
            return alert(c, "Free plan delete nahi hoga")
        return show(c, "⚠️ Plan <b>%s</b> delete karein?" % esc(p["name"]), kb([("✅ Yes", "a:pln:dd:" + ID), ("❌ No", "a:pln:v:" + ID)]))
    if act == "dd":
        DB["plans"].pop(ID, None)
        save(True)
        audit(uid, "plan_delete", ID)
        mod_plans(c, ["home"], uid)


@state("pln_new")
def st_pln_new(m, st):
    try:
        n, pr, d, lim, lv = [x.strip() for x in m.text.split("|")][:5]
        pr, d, lim, lv = float(pr), int(d), int(lim), int(lv)
        assert 1 <= lv <= 4
    except Exception:
        return send(m.chat.id, "⚠️ Format galat. Dobara bhejo.")
    pid = "p" + nid("plan")
    DB["plans"][pid] = {"id": pid, "name": n[:30], "price": pr, "days": d, "limit": lim, "level": lv, "active": True}
    USER_STATES.pop(m.from_user.id, None)
    save(True)
    audit(m.from_user.id, "plan_create", pid)
    done(m.chat.id, "✅ Plan added!", "a:pln:home")


@state("pln_edit")
def st_pln_edit(m, st):
    p = DB["plans"].get(st["pid"])
    v = (m.text or "").strip()
    try:
        f = st["field"]
        p[f] = v[:30] if f == "name" else (float(v) if f == "price" else int(v))
    except Exception:
        return send(m.chat.id, "⚠️ Valid value bhejo.")
    USER_STATES.pop(m.from_user.id, None)
    save(True)
    audit(m.from_user.id, "plan_edit", "%s.%s" % (st["pid"], st["field"]))
    done(m.chat.id, "✅ Updated.", "a:pln:v:" + st["pid"])


# ---------- 16.6 Coupons ----------
def mod_coupons(c, a, uid):
    act = a[0]
    if act == "home":
        rows = [[("➕ Create", "a:cpn:new"), ("🎲 Bulk Generate", "a:cpn:bulk")], [("📋 List", "a:cpn:l:0")], [BK]]
        return show(c, "🎟 <b>Coupon Manager</b> (%d coupons)" % len(DB["coupons"]), kb(*rows))
    if act == "new":
        return ask(c, "Format: <code>CODE | Value | MaxUses | [PlanID optional]</code>\nEx: <code>WELCOME50 | 50 | 100</code>", "cpn_new", back="a:cpn:home")
    if act == "bulk":
        return ask(c, "Format: <code>Count | Value | MaxUses</code> (har code ke liye)\nEx: <code>20 | 25 | 1</code>", "cpn_bulk", back="a:cpn:home")
    if act == "l":
        cs = list(DB["coupons"].values())[::-1]
        rows = page_kb(cs, int(a[1]), PER_PAGE, lambda x: ("%s • %s • %d/%d" % (x["code"], money(x["value"]), len(x["used_by"]), x["max_uses"]), "a:cpn:v:" + x["code"]), "a:cpn:l")
        return show(c, "📋 <b>Coupons</b>", kb(*rows, [("🔙 Back", "a:cpn:home")]))
    if act == "v":
        return show(c, "🎟 <code>%s</code> — delete karein?" % esc(a[1]), kb([("🗑 Delete", "a:cpn:dd:" + a[1])], [("🔙", "a:cpn:l:0")]))
    if act == "dd":
        DB["coupons"].pop(a[1], None)
        save(True)
        audit(uid, "coupon_delete", a[1])
        mod_coupons(c, ["l", "0"], uid)


@state("cpn_new")
def st_cpn_new(m, st):
    try:
        parts = [x.strip() for x in m.text.split("|")]
        code, val, mx = parts[0].upper(), float(parts[1]), int(parts[2])
        plan = parts[3] if len(parts) > 3 else None
        assert re.match(r"^[A-Z0-9]{3,20}$", code) and code not in DB["coupons"] and (not plan or plan in DB["plans"])
    except Exception:
        return send(m.chat.id, "⚠️ Format galat / code already exists.")
    DB["coupons"][code] = {"code": code, "value": val, "max_uses": mx, "used_by": [], "plan": plan, "active": True, "created": now()}
    USER_STATES.pop(m.from_user.id, None)
    save(True)
    audit(m.from_user.id, "coupon_create", code)
    done(m.chat.id, "✅ Coupon <code>%s</code> created." % code, "a:cpn:home")


@state("cpn_bulk")
def st_cpn_bulk(m, st):
    try:
        n, val, mx = [x.strip() for x in m.text.split("|")][:3]
        n, val, mx = int(n), float(val), int(mx)
        assert 1 <= n <= 200
    except Exception:
        return send(m.chat.id, "⚠️ Format galat (max 200).")
    codes = []
    while len(codes) < n:
        code = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
        if code not in DB["coupons"]:
            DB["coupons"][code] = {"code": code, "value": val, "max_uses": mx, "used_by": [], "plan": None, "active": True, "created": now()}
            codes.append(code)
    USER_STATES.pop(m.from_user.id, None)
    save(True)
    audit(m.from_user.id, "coupon_bulk", "x%d" % n)
    done(m.chat.id, "✅ %d coupons (%s each):\n\n<code>%s</code>" % (n, money(val), "\n".join(codes)), "a:cpn:home")


# ---------- 16.7 Requests (admin) ----------
def mod_requests(c, a, uid):
    act = a[0]
    if act == "l":
        rs = pending_requests()
        rows = page_kb(rs, int(a[1]), PER_PAGE, lambda x: ("👍%d • %s" % (len(x["votes"]), x["text"][:35]), "a:req:v:" + x["id"]), "a:req:l")
        return show(c, "🎥 <b>Pending Requests</b> (%d)" % len(rs), kb(*rows, [BK]))
    x = DB["requests"].get(a[1])
    if not x:
        return alert(c, "Request nahi mili")
    if act == "v":
        return show(c, "🎥 <b>Request #%s</b>\n👤 <code>%s</code>\n👍 %d votes\n📌 %s\n\n%s" % (x["id"], x["uid"], len(x["votes"]), x["status"], esc(x["text"])),
                    kb([("✅ Approve", "a:req:s:%s:approved" % x["id"]), ("❌ Reject", "a:req:s:%s:rejected" % x["id"])],
                       [("📥 Mark Added", "a:req:s:%s:added" % x["id"])], [("🔙", "a:req:l:0")]))
    if act == "s":
        x["status"] = a[2]
        save()
        audit(uid, "req_" + a[2], x["id"])
        msg = {"approved": "✅ approve ho gayi (jaldi add hogi)", "rejected": "❌ reject ho gayi", "added": "🎉 content add ho gaya hai! Sections check karo"}[a[2]]
        targets = set(x["votes"]) | {x["uid"]} if a[2] == "added" else {x["uid"]}
        for t in targets:
            send(t, "🎥 Request <b>#%s</b> (%s) %s" % (x["id"], esc(x["text"][:40]), msg))
        mod_requests(c, ["l", "0"], uid)


# ---------- 16.8 Tickets (admin) ----------
def mod_tickets(c, a, uid):
    act = a[0]
    if act == "l":
        ts = sorted(DB["tickets"].values(), key=lambda t: (t["status"] != "open", -t["created"]))
        rows = page_kb(ts, int(a[1]), PER_PAGE, lambda t: ("%s #%s • %s • %s" % ("🟢" if t["status"] == "open" else "🔒", t["id"], t["cat"], t["pri"]), "a:tkt:v:" + t["id"]), "a:tkt:l")
        return show(c, "🎫 <b>Tickets</b> (%d)" % len(ts), kb(*rows, [BK]))
    t = DB["tickets"].get(a[1])
    if not t:
        return alert(c, "Ticket nahi mila")
    ID = t["id"]
    if act == "v":
        if t.get("shot"):
            try:
                bot.send_photo(c.message.chat.id, t["shot"], caption="Screenshot #" + ID)
            except ApiTelegramException:
                pass
        st_btn = ("🔒 Close", "a:tkt:c:" + ID) if t["status"] == "open" else ("🔓 Reopen", "a:tkt:o:" + ID)
        return show(c, ticket_text(t) + "\n👤 User: <code>%s</code>" % t["uid"], kb([("💬 Reply", "a:tkt:r:" + ID), st_btn], [("🔙", "a:tkt:l:0")]))
    if act == "r":
        return ask(c, "✍️ Reply likho (ticket #%s):" % ID, "tk_admin_reply", back="a:tkt:v:" + ID, tid=ID)
    if act in ("c", "o"):
        t["status"] = "closed" if act == "c" else "open"
        save()
        audit(uid, "ticket_" + act, ID)
        send(t["uid"], "🎫 Ticket <b>#%s</b> %s." % (ID, "close kar diya gaya" if act == "c" else "dobara open kiya gaya"))
        mod_tickets(c, ["v", ID], uid)


@state("tk_admin_reply")
def st_tk_admin_reply(m, st):
    t = DB["tickets"].get(st["tid"])
    if not t or m.content_type != "text":
        return
    t["msgs"].append({"from": "admin", "text": m.text.strip()[:1000], "ts": now()})
    USER_STATES.pop(m.from_user.id, None)
    save()
    audit(m.from_user.id, "ticket_reply", t["id"])
    send(t["uid"], "💬 <b>Support reply</b> (Ticket #%s):\n\n%s" % (t["id"], esc(m.text[:1000])), kb([("📋 View", "h:v:" + t["id"])]))
    done(m.chat.id, "✅ Reply bhej diya.", "a:tkt:v:" + t["id"])


# ════════════════════════════════════════════════════════════════
# 17. BROADCAST
# ════════════════════════════════════════════════════════════════
def audience(kind):
    out = []
    for u in DB["users"].values():
        if u["banned"] or u.get("blocked"):
            continue
        lv = level_of(u)
        if (kind == "all" or (kind == "paid" and lv > 0) or (kind == "free" and lv == 0)
                or (kind.startswith("plan_") and u["plan"] == kind[5:])):
            out.append(u["id"])
    return out


def run_broadcast(aud, chat, mid, report_to=None):
    ids = audience(aud)
    ok = fail = 0
    for uid in ids:
        try:
            bot.copy_message(uid, chat, mid)
            ok += 1
        except ApiTelegramException as e:
            fail += 1
            if "blocked" in str(e) or "deactivated" in str(e):
                DB["users"][str(uid)]["blocked"] = True
        except Exception:
            fail += 1
        time.sleep(0.05)  # Telegram flood limit se bachne ke liye
    save()
    if report_to:
        send(report_to, "📢 Broadcast complete\n✅ Sent: %d\n❌ Failed: %d" % (ok, fail))


def mod_broadcast(c, a, uid):
    act = a[0]
    if act == "home":
        rows = [[("👥 All", "a:bc:aud:all"), ("💎 Paid", "a:bc:aud:paid"), ("🆓 Free", "a:bc:aud:free")],
                [("📦 Specific Plan", "a:bc:plans")], [("⏰ Scheduled (%d)" % sum(1 for s in DB["scheduled"].values() if s["status"] == "pending"), "a:bc:sl")], [BK]]
        return show(c, "📢 <b>Broadcast</b>\nAudience chuno:", kb(*rows))
    if act == "plans":
        rows = [[(p["name"], "a:bc:aud:plan_" + p["id"])] for p in plans_sorted(False)]
        return show(c, "Plan chuno:", kb(*rows, [("🔙", "a:bc:home")]))
    if act == "aud":
        return ask(c, "✍️ Broadcast ka message bhejo (text/photo/video — jo bhi ho, copy hoga). Audience: <b>%s</b> (%d users)" % (a[1], len(audience(a[1]))),
                   "bc_msg", back="a:bc:home", aud=a[1])
    if act == "now":
        st = USER_STATES.pop(uid, None)
        if st and st["s"] == "bc_ready":
            audit(uid, "broadcast", st["aud"])
            threading.Thread(target=run_broadcast, args=(st["aud"], st["chat"], st["mid"], uid), daemon=True).start()
            return show(c, "🚀 Broadcast shuru ho gaya. Report aayegi.", kb([BK]))
    if act == "sch":
        st = USER_STATES.get(uid)
        if st and st["s"] == "bc_ready":
            st["s"] = "bc_when"
            return show(c, "⏰ Kab bhejna hai? Minutes (e.g. <code>30</code>) ya <code>YYYY-MM-DD HH:MM</code>", kb([("❌ Cancel", "x:c")]))
    if act == "sl":
        rows = [[("%s • %s • %s" % (s["id"], s["aud"], fdt(s["when"])), "a:bc:sx:" + s["id"])] for s in DB["scheduled"].values() if s["status"] == "pending"]
        return show(c, "⏰ <b>Scheduled</b> (tap = cancel)", kb(*rows, [("🔙", "a:bc:home")]))
    if act == "sx":
        if a[1] in DB["scheduled"]:
            DB["scheduled"][a[1]]["status"] = "cancelled"
            save()
        mod_broadcast(c, ["sl"], uid)


@state("bc_msg")
def st_bc_msg(m, st):
    uid = m.from_user.id
    set_state(uid, "bc_ready", back="a:bc:home", aud=st["aud"], chat=m.chat.id, mid=m.message_id)
    send(m.chat.id, "✅ Message save. Audience: <b>%s</b> (%d users)" % (st["aud"], len(audience(st["aud"]))),
         kb([("🚀 Send Now", "a:bc:now"), ("⏰ Schedule", "a:bc:sch")], [("❌ Cancel", "x:c")]))


@state("bc_ready")
def st_bc_ready(m, st):
    pass  # buttons se aage badho


@state("bc_when")
def st_bc_when(m, st):
    t = (m.text or "").strip()
    try:
        when = now() + int(t) * 60 if t.isdigit() else int(datetime.strptime(t, "%Y-%m-%d %H:%M").timestamp())
        assert when > now()
    except Exception:
        return send(m.chat.id, "⚠️ Format galat ya time past mein hai.")
    sid = nid("sched")
    DB["scheduled"][sid] = {"id": sid, "aud": st["aud"], "chat": st["chat"], "mid": st["mid"], "when": when, "status": "pending", "by": m.from_user.id}
    USER_STATES.pop(m.from_user.id, None)
    save(True)
    audit(m.from_user.id, "broadcast_sched", sid)
    done(m.chat.id, "⏰ Scheduled for %s" % fdt(when), "a:bc:home")


# ════════════════════════════════════════════════════════════════
# 18. ANALYTICS + SETTINGS + BACKUP + ADMINS + AUDIT
# ════════════════════════════════════════════════════════════════
def mod_analytics(c, a, uid):
    appr = [p for p in DB["payments"].values() if p["status"] == "approved"]
    rev = lambda days: sum(p["amount"] for p in appr if p["ts"] > now() - days * 86400)
    growth = []
    for d in range(6, -1, -1):
        lo = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=d)
        n = sum(1 for u in DB["users"].values() if lo.timestamp() <= u["joined"] < lo.timestamp() + 86400)
        growth.append("%s %s %d" % (lo.strftime("%d-%b"), "█" * min(n, 20), n))
    top = sorted(DB["content"].values(), key=lambda i: -i["views"])[:5]
    sales = defaultdict(int)
    for p in appr:
        if p["kind"] == "plan":
            sales[p["plan"]] += 1
    txt = ("📊 <b>Analytics</b>\n\n💰 <b>Revenue</b>\nToday-24h: %s\n7d: %s\n30d: %s\nAll: %s\n\n👥 <b>User growth (7d)</b>\n<code>%s</code>\n\n"
           "🔥 <b>Top content</b>\n%s\n\n🛒 <b>Plan sales</b>\n%s") % (
        money(rev(1)), money(rev(7)), money(rev(30)), money(rev(99999)), "\n".join(growth),
        "\n".join("%d. %s (%d👁)" % (n + 1, esc(i["title"][:30]), i["views"]) for n, i in enumerate(top)) or "—",
        "\n".join("%s: %d" % (DB["plans"].get(k, {"name": k})["name"], v) for k, v in sales.items()) or "—")
    show(c, txt, kb([BK]))


SET_TOGGLES = {"force_join": "Force Join", "maintenance": "Maintenance", "auto_approve": "Auto-approve", "protect_content": "Protect Content"}
SET_VALUES = {"qr_url": "Payment QR URL", "support_username": "Support Username", "welcome": "Welcome Msg",
              "force_channel_id": "Force Channel ID", "force_channel_link": "Force Channel Link",
              "ref_reward": "Referral Reward ₹", "backup_hours": "Backup Hours"}


def mod_settings(c, a, uid):
    act = a[0]
    if act == "home":
        rows = [[("%s %s" % ("🟢" if S(k) else "🔴", v), "a:set:t:" + k)] for k, v in SET_TOGGLES.items()]
        rows += [[("✏️ " + v, "a:set:e:" + k)] for k, v in SET_VALUES.items()] + [[BK]]
        return show(c, "⚙️ <b>Settings</b>", kb(*rows))
    if act == "t":
        DB["settings"][a[1]] = not S(a[1])
        save()
        audit(uid, "setting", "%s=%s" % (a[1], S(a[1])))
        return mod_settings(c, ["home"], uid)
    if act == "e":
        return ask(c, "✏️ <b>%s</b> ki nayi value bhejo:\n(Abhi: <code>%s</code>)" % (SET_VALUES[a[1]], esc(str(S(a[1]))[:200])), "set_edit", back="a:set:home", key=a[1])


@state("set_edit")
def st_set_edit(m, st):
    if m.content_type != "text":
        return
    k, v = st["key"], m.text.strip()
    if k in ("ref_reward", "backup_hours"):
        try:
            v = float(v) if k == "ref_reward" else max(1, int(v))
        except ValueError:
            return send(m.chat.id, "⚠️ Number bhejo.")
    DB["settings"][k] = v
    USER_STATES.pop(m.from_user.id, None)
    save(True)
    audit(m.from_user.id, "setting", k)
    done(m.chat.id, "✅ Saved.", "a:set:home")


def mod_backup(c, a, uid):
    act = a[0]
    if act == "home":
        return show(c, "💾 <b>Backup</b>\nLast auto-backup: %s" % fdt(DB["meta"]["last_backup"]),
                    kb([("📤 Export Now", "a:bk:ex")], [("📥 Import JSON", "a:bk:im")], [BK]))
    if act == "ex":
        db_backup()
        try:
            with open(DB_FILE, "rb") as f:
                bot.send_document(c.message.chat.id, f, visible_file_name="backup_%s.json" % datetime.now().strftime("%Y%m%d_%H%M"))
        except Exception as e:
            alert(c, "Export fail: %s" % e)
        audit(uid, "backup_export")
    if act == "im":
        ask(c, "📥 Backup <b>.json</b> file bhejo.\n⚠️ Current data replace ho jayega (pehle auto-backup banega).", "bk_import", back="a:bk:home")


@state("bk_import")
def st_bk_import(m, st):
    if m.content_type != "document":
        return send(m.chat.id, "⚠️ JSON document bhejo.")
    try:
        raw = bot.download_file(bot.get_file(m.document.file_id).file_path)
        data = json.loads(raw.decode("utf-8"))
        assert isinstance(data.get("users"), dict) and isinstance(data.get("plans"), dict)
    except Exception as e:
        return send(m.chat.id, "❌ Invalid backup: %s" % esc(e))
    db_backup()
    with DB_LOCK:
        base = default_db()
        for k, v in base.items():
            data.setdefault(k, v)
        for k, v in base["settings"].items():
            data["settings"].setdefault(k, v)
        DB.clear()
        DB.update(data)
        save(True)
    USER_STATES.pop(m.from_user.id, None)
    audit(m.from_user.id, "backup_import")
    done(m.chat.id, "✅ Import complete. Users: %d" % len(DB["users"]), "a:bk:home")


def mod_admins(c, a, uid):
    act = a[0]
    if act == "home":
        rows = [[("%s • %s" % (k, v["role"]), "a:adm:v:" + k)] for k, v in DB["admins"].items()]
        return show(c, "🛡 <b>Admin Roles</b>\nRoles: full, users, content, view", kb(*rows, [("➕ Add Admin", "a:adm:add")], [BK]))
    if act == "add":
        return ask(c, "Format: <code>UserID role</code>\nRoles: <code>full</code> | <code>users</code> | <code>content</code> | <code>view</code>", "adm_add", back="a:adm:home")
    if act == "v":
        return show(c, "🛡 Admin <code>%s</code> (%s)" % (a[1], DB["admins"].get(a[1], {}).get("role")), kb([("🗑 Remove", "a:adm:rm:" + a[1])], [("🔙", "a:adm:home")]))
    if act == "rm":
        DB["admins"].pop(a[1], None)
        save(True)
        audit(uid, "admin_remove", a[1])
        mod_admins(c, ["home"], uid)


@state("adm_add")
def st_adm_add(m, st):
    try:
        i, role = m.text.split()
        int(i)
        assert role in ROLE_PERMS and role != "owner"
    except Exception:
        return send(m.chat.id, "⚠️ Format: <code>123456 content</code>")
    DB["admins"][i] = {"role": role, "added": now()}
    USER_STATES.pop(m.from_user.id, None)
    save(True)
    audit(m.from_user.id, "admin_add", "%s:%s" % (i, role))
    send(int(i), "🛡 Aapko <b>%s</b> admin role mila. /admin use karo." % role)
    done(m.chat.id, "✅ Admin added.", "a:adm:home")


def mod_log(c, a, uid):
    logs = DB["audit"][-20:][::-1]
    txt = "📜 <b>Audit Log</b> (last 20 / %d)\n\n" % len(DB["audit"]) + "\n".join(
        "<code>%s</code> %s <b>%s</b> %s" % (datetime.fromtimestamp(x["ts"]).strftime("%d/%m %H:%M"), x["by"] or "auto", x["act"], esc(x["d"])) for x in logs)
    show(c, txt or "Empty", kb([BK]))


ADMIN_MODS = {"usr": mod_users, "pay": mod_payments, "sec": mod_sections, "cnt": mod_content, "pln": mod_plans,
              "cpn": mod_coupons, "req": mod_requests, "tkt": mod_tickets, "bc": mod_broadcast, "ana": mod_analytics,
              "set": mod_settings, "bk": mod_backup, "adm": mod_admins, "log": mod_log}


# ════════════════════════════════════════════════════════════════
# 19. BACKGROUND THREADS  (db flush, scheduled broadcast, auto-backup)
# ════════════════════════════════════════════════════════════════
def background_loop():
    tick = 0
    while True:
        time.sleep(3)
        tick += 3
        try:
            if _dirty:
                db_save()
            if tick % 21 == 0:   # ~har 20s: scheduled broadcasts
                for s in list(DB["scheduled"].values()):
                    if s["status"] == "pending" and s["when"] <= now():
                        s["status"] = "sent"
                        save()
                        threading.Thread(target=run_broadcast, args=(s["aud"], s["chat"], s["mid"], s["by"]), daemon=True).start()
            if tick % 60 == 0:
                if now() - DB["meta"]["last_backup"] >= int(S("backup_hours", 6)) * 3600:
                    db_backup()
                t = time.time()
                for k in [k for k, v in _last_cb.items() if t - v > 10]:
                    _last_cb.pop(k, None)
        except Exception as e:
            log.error("bg error: %s", e)


# ════════════════════════════════════════════════════════════════
# 20. DISPATCHERS + MAIN ENTRY
# ════════════════════════════════════════════════════════════════
def dispatch(c, data):
    parts = data.split(":")
    fn = ROUTES.get(parts[0])
    if fn:
        fn(c, parts, get_user(c.from_user.id))


@bot.callback_query_handler(func=lambda c: True)
def on_callback(c):
    uid = c.from_user.id
    try:
        if rate_limited(uid, "cb"):
            return alert(c, "⏳ Thoda slow karo!")
        key = (uid, c.data, c.message.message_id)
        t = time.time()
        if t - _last_cb.get(key, 0) < 0.8:   # duplicate tap protection
            return
        _last_cb[key] = t
        u = get_user(uid, c.from_user)
        if u["banned"]:
            return alert(c, "🚫 Aap ban ho.")
        if S("maintenance") and not is_staff(uid):
            return alert(c, "🛠 Maintenance mode chal raha hai.")
        head = c.data.split(":")[0]
        if head not in ("age", "jn", "x", "noop", "a") and not gate(u, c.message.chat.id, c):
            return
        dispatch(c, c.data)
    except ApiTelegramException as e:
        log.warning("API error in callback %s: %s", c.data, e)
    except Exception:
        log.exception("callback error: %s", c.data)
    finally:
        try:
            bot.answer_callback_query(c.id)
        except Exception:
            pass


@bot.message_handler(commands=["cancel"])
def cmd_cancel(m):
    USER_STATES.pop(m.from_user.id, None)
    send(m.chat.id, "❌ Cancelled.", kb([("🏠 Menu", "m:home")]))


@bot.message_handler(func=lambda m: True,
                     content_types=["text", "photo", "video", "document", "audio", "voice", "animation", "video_note"])
def on_message(m):
    if m.chat.type != "private":
        return
    uid = m.from_user.id
    try:
        if rate_limited(uid, "msg"):
            return
        u = get_user(uid, m.from_user)
        if u["banned"]:
            return
        if S("maintenance") and not is_staff(uid):
            return send(uid, "🛠 Maintenance mode chal raha hai.")
        st = USER_STATES.get(uid)
        if st and st["s"] in STATE_HANDLERS:
            if is_staff(uid) is False and (st["s"].startswith(("usr_", "sec_", "cnt_", "up_", "pln_", "cpn_", "bc_", "set_", "bk_", "adm_", "tk_admin"))):
                USER_STATES.pop(uid, None)   # safety: non-admin admin-state nahi chala sakta
                return
            return STATE_HANDLERS[st["s"]](m, st)
        if gate(u, uid):
            send(uid, menu_text(u), main_kb(u))
    except ApiTelegramException as e:
        log.warning("API error in message: %s", e)
    except Exception:
        log.exception("message error")


if __name__ == "__main__":
    DB.update(db_load())
    db_save()
    atexit.register(lambda: DB and db_save())
    threading.Thread(target=background_loop, daemon=True).start()
    log.info("Bot started ✅")
    bot.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)