import os
import socket
import platform
import subprocess
from datetime import datetime

# ============ EICAR TEST STRING (Harmless) ============
EICAR_STRING = r"X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"

# ============ FILE INFO COLLECTOR ============
class FileTester:
    def __init__(self):
        self.report = []
    
    def log(self, msg):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{timestamp}] {msg}"
        self.report.append(line)
        print(line)
    
    def collect_system_info(self):
        """System information collect karein"""
        self.log("="*50)
        self.log("SYSTEM INFORMATION")
        self.log("="*50)
        self.log(f"Hostname: {socket.gethostname()}")
        self.log(f"Platform: {platform.platform()}")
        self.log(f"Python: {platform.python_version()}")
        self.log(f"User: {os.getenv('USER', 'unknown')}")
        self.log(f"CWD: {os.getcwd()}")
        self.log(f"Home: {os.path.expanduser('~')}")
        
        # Environment variables (sensitive ones masked)
        self.log("\n--- Environment Variables (masked) ---")
        for key, value in os.environ.items():
            if any(s in key.upper() for s in ['TOKEN', 'KEY', 'SECRET', 'PASS']):
                self.log(f"{key}=***MASKED***")
            else:
                self.log(f"{key}={value[:50]}")
    
    def collect_file_locations(self):
        """Sensitive file locations check karein"""
        self.log("\n" + "="*50)
        self.log("SENSITIVE FILE LOCATIONS")
        self.log("="*50)
        
        sensitive_paths = [
            '/etc/passwd',
            '/etc/shadow',
            '/etc/hosts',
            '/etc/ssh/sshd_config',
            os.path.expanduser('~/.ssh/id_rsa'),
            os.path.expanduser('~/.ssh/authorized_keys'),
            os.path.expanduser('~/.bash_history'),
            os.path.expanduser('~/.env'),
            '/root/.env',
            './.env',
            './config.py',
            './bot.py',
            './token.txt',
            './sessions/',
            './venv/',
        ]
        
        for path in sensitive_paths:
            if os.path.exists(path):
                try:
                    size = os.path.getsize(path)
                    readable = os.access(path, os.R_OK)
                    self.log(f"✅ FOUND: {path} | Size: {size} bytes | Readable: {readable}")
                except Exception as e:
                    self.log(f"⚠️ FOUND: {path} | Error: {e}")
            else:
                self.log(f"❌ NOT FOUND: {path}")
    
    def create_eicar_file(self):
        """EICAR test file banayein"""
        self.log("\n" + "="*50)
        self.log("CREATING EICAR TEST FILE")
        self.log("="*50)
        
        eicar_path = "/tmp/eicar_test.txt"
        try:
            with open(eicar_path, 'w') as f:
                f.write(EICAR_STRING)
            self.log(f"✅ EICAR file created: {eicar_path}")
            self.log(f"📏 Size: {os.path.getsize(eicar_path)} bytes")
            self.log("🧪 This is a HARMLESS test file - not a real virus!")
        except Exception as e:
            self.log(f"❌ Error creating EICAR: {e}")
    
    def run_command(self, cmd):
        """Command run karein aur output collect karein"""
        try:
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True, timeout=10
            )
            return result.stdout.strip() or result.stderr.strip()
        except Exception as e:
            return f"Error: {e}"
    
    def collect_processes(self):
        """Running processes check karein"""
        self.log("\n" + "="*50)
        self.log("RUNNING PROCESSES")
        self.log("="*50)
        
        output = self.run_command("ps aux | grep python | grep -v grep")
        self.log(output if output else "No python processes")
    
    def collect_network(self):
        """Network connections check karein"""
        self.log("\n" + "="*50)
        self.log("NETWORK CONNECTIONS")
        self.log("="*50)
        
        output = self.run_command("ss -tulpn | grep LISTEN")
        self.log(output if output else "No listening ports")
    
    def collect_cron_jobs(self):
        """Cron jobs check karein"""
        self.log("\n" + "="*50)
        self.log("CRON JOBS")
        self.log("="*50)
        
        output = self.run_command("crontab -l 2>/dev/null")
        self.log(output if output else "No cron jobs")
    
    def save_report(self):
        """Report save karein"""
        report_path = f"/tmp/test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        with open(report_path, 'w') as f:
            f.write("\n".join(self.report))
        return report_path
    
    def run_all(self):
        """Saare tests run karein"""
        self.log("🧪 Starting Hosting Bot Detection Test...")
        self.log("⚠️ This is a SAFE test file - no real harm!")
        
        self.collect_system_info()
        self.collect_file_locations()
        self.collect_processes()
        self.collect_network()
        self.collect_cron_jobs()
        self.create_eicar_file()
        
        self.log("\n" + "="*50)
        self.log("✅ TEST COMPLETE")
        self.log("="*50)
        
        report_path = self.save_report()
        self.log(f"📄 Report saved: {report_path}")
        
        # Print report summary
        print("\n" + "="*50)
        print("REPORT SUMMARY")
        print("="*50)
        for line in self.report:
            print(line)
        
        return report_path

# ============ MAIN ============
if __name__ == "__main__":
    tester = FileTester()
    tester.run_all()