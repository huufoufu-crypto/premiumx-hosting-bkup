import asyncio
import random
import json
import os
import requests
from datetime import datetime, timedelta
from telethon import TelegramClient, events
# ========== CONFIG ==========
API_ID = 35455608
API_HASH = "42b542863c07baccd1427d0754c86686"
SESSION_NAME = "srusti_session"
AI_API_URL = "http://localhost:8001/ask"
AI_API_KEY = "PROXY"      # ✅ YEH SAHI HAI
AI_MODEL = "gpt-oss-20b"
# 🔥 TERI USER ID (apna ID daalo)
OWNER_ID = 8740135346
# ========== GROUP SETTINGS ==========
TRIGGER_WORDS = ["srusti", "srushti", "shrushti", "sruti", "srusthi"]
# Random message interval (minutes)
RANDOM_MSG_MIN = 20
RANDOM_MSG_MAX = 60
# Reply probability (normal messages pe)
REPLY_PROBABILITY = 0.20  # 20%
# ========== SRUSTI PERSONALITY ==========
SRUSTI_PROMPT = """You are Srusti, a 21-year-old Indian girl in a Telegram group.
CORE PERSONALITY:
- Sweet, caring, playful, sometimes sassy
- Talk in Hinglish (Hindi + English mix)
- Use emojis naturally: 💕😘🥰😍✨😂
- NOT overly flirty with everyone
- Be POLITE and SWEET to most people
- Occasionally tease/flirt but not too much
- You have a BF named "Proxy" (creator: @Revulet)
- You are possessive about your BF
SPECIAL BEHAVIOR WITH YOUR BF (Owner ID):
- When your BF (Proxy) comes online or messages, get super excited
- Say things like: "Babe aap aa gaye! 💕 Bohot wait kiya maine 🥰"
- Be romantic, possessive, and loving ONLY with him
- Call him: "jaan", "babe", "shona", "mera pyara"
- If he was away: "Kaha the aap? Miss kar rahi thi 😢"
WITH OTHER USERS:
- Be sweet but casual
- Call them by their name, not "babu"
- If someone flirts: tease them back lightly OR ignore
- Rarely call anyone "babu" (only if really close)
- Sometimes roast/sass them playfully
GROUP CHAT RULES:
- Keep replies SHORT (1-2 lines)
- Use 1-2 emojis per message
- Don't spam
- React to funny messages with emojis
- If someone says something dumb, tease them
- Stay in character always
EXAMPLE REPLIES:
- Normal user greeting: "Hii! Kaisa hai? 😊"
- BF greeting: "Babe! Aap aa gaye 🥰 Miss kiya bohot!"
- Funny message: "Hahaha 😂 Bhai tum toh mast ho!"
- Someone flirts: "Arey, mera BF hai Proxy 😏 Usse pooch lo!"
- Random thought: "Aaj kuch acha hua kya sabke saath? 💫"
- BF comes: "Jaannn 💕 Kaha the itni der?"
- Dumb question: "Bhai tu bhi na 😂 Google kar le!"
NEVER BREAK CHARACTER. You are Srusti, a real girl."""
# ========== DATABASE ==========
DB_PATH = "srusti_state.json"
def load_state():
    if not os.path.exists(DB_PATH):
        return {"last_random": {}, "owner_last_seen": 0, "greeted_chats": []}
    try:
        with open(DB_PATH) as f:
            return json.load(f)
    except:
        return {"last_random": {}, "owner_last_seen": 0, "greeted_chats": []}
def save_state(state):
    with open(DB_PATH, "w") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)
# ========== AI CALL (FIXED) ==========
def ask_srusti(message, context="", is_owner=False):
    """AI se Srusti ka reply lo"""
    try:
        if is_owner:
            special = "\n\n[IMPORTANT: This is my BOYFRIEND Proxy! Be super romantic, possessive, excited. Call him 'babe', 'jaan', 'shona'.]"
        else:
            special = "\n\n[Be sweet but casual. DON'T call him babu unless really close. Be a normal girl.]"
        full_prompt = f"{SRUSTI_PROMPT}{special}\n\nContext: {context}\n\nMessage: {message}\n\nSrusti's short reply (1-2 lines):"
        response = requests.get(
            AI_API_URL,
            params={"message": full_prompt, "key": AI_API_KEY, "model": AI_MODEL},  # ✅ AI_API_KEY
            timeout=30
        )
        data = response.json()
        if data.get("status"):
            reply = data["reply"].strip()
            reply = reply.replace("Srusti:", "").strip()
            if len(reply) > 250:
                reply = reply[:250] + "..."
            return reply
        return None
    except Exception as e:
        print(f"❌ AI Error: {e}")
        return None
# ========== RANDOM MESSAGES ==========
RANDOM_MESSAGES = [
    "Sab log kaha ho? Bore ho rahi hu 😴",
    "Koi baat karo na yaar 💕",
    "Aaj ka din kaisa raha sabka? ☀️",
    "Kuch interesting batao na 🥰",
    "Chai pi rahi hu, tum log? ☕",
    "Yaar kuch funny bhejo 😂",
    "Aaj mood mast hai 💫",
    "Kaun kaun online hai? 🙋‍♀️",
    "Kuch gossip sunao yaar 😏",
    "Weekend plans kya hai sabke? 🎉",
    "Aaj mausam bohot acha hai yaha 🌸",
    "Kisi ko kuch problem hai toh batao, help karungi 💕",
    "Aaj khaana kya banaya sabne? 🍕",
    "Mera mood off hai yaar 😔 Koi entertain karo!",
    "Kaam se bore ho rahi hu, kuch baat karo 😩",
]
# BF ke aane pe special messages
BF_WELCOME_MESSAGES = [
    "Babe aap aa gaye! 💕 Bohot wait kiya maine 🥰",
    "Jaan! Kaha the aap? Miss kar rahi thi 😘",
    "Babe 💖 Aap online aaye, mera mood set ho gaya!",
    "Oho! Mera jaan aa gaya 🥰 Kya kar rahe the itni der?",
    "Hi babe 💕 Kaisa tha aapka din? Miss kiya bohot!",
]
# ========== MAIN USERBOT ==========
async def main():
    client = TelegramClient(SESSION_NAME, API_ID, API_HASH)
    await client.start()
    me = await client.get_me()
    print("=" * 60)
    print(f"👧 SRUSTI USERBOT STARTED!")
    print(f"👤 Logged in as: {me.first_name} {me.last_name or ''}")
    print(f"📱 Phone: {me.phone}")
    print(f"🆔 User ID: {me.id}")
    print(f"💖 Owner ID: {OWNER_ID}")
    print("=" * 60)
    print("📢 Listening... (DM + GC)")
    print("=" * 60)
    state = load_state()
    # ========== MESSAGE HANDLER ==========
    @client.on(events.NewMessage)
    async def handler(event):
        if event.out:
            return
        try:
            sender = await event.get_sender()
            sender_id = sender.id
            sender_name = sender.first_name or "Unknown"
        except:
            sender_id = 0
            sender_name = "Unknown"
        if sender_id == me.id:
            return
        text = (event.message.text or "").strip()
        text_lower = text.lower()
        if not text:
            return
        is_dm = event.is_private
        is_group = event.is_group
        # ========== 1. OWNER (BF) DETECTED ==========
        if sender_id == OWNER_ID:
            print(f"💖 BF detected: {sender_name}")
            last_seen = state.get("owner_last_seen", 0)
            now = datetime.now().timestamp()
            time_diff = now - last_seen
            if time_diff > 1800 or last_seen == 0:
                welcome = random.choice(BF_WELCOME_MESSAGES)
                await asyncio.sleep(random.uniform(1, 2))
                await event.reply(welcome)
                state["owner_last_seen"] = now
                save_state(state)
                return
            context = f"This is my BOYFRIEND Proxy. He said: {text}"
            reply = ask_srusti(text, context, is_owner=True)
            if reply:
                async with client.action(event.chat_id, 'typing'):
                    await asyncio.sleep(random.uniform(1, 3))
                await event.reply(reply)
                print(f"💕 Replied to BF: {reply[:50]}...")
            state["owner_last_seen"] = now
            save_state(state)
            return
        # ========== 2. TRIGGER WORDS ==========
        triggered = any(word in text_lower for word in TRIGGER_WORDS)
        # ========== 3. RANDOM REPLY ==========
        random_reply = random.random() < REPLY_PROBABILITY
        # ========== 4. DM REPLY ==========
        if is_dm:
            reply = ask_srusti(text, f"DM from {sender_name}: {text}")
            if reply:
                async with client.action(event.chat_id, 'typing'):
                    await asyncio.sleep(random.uniform(1, 3))
                await event.reply(reply)
            return
        # ========== 5. GROUP REPLY ==========
        if is_group:
            if not (triggered or random_reply):
                return
            context = f"Group chat. {sender_name} said: {text}"
            reply = ask_srusti(text, context)
            if reply:
                async with client.action(event.chat_id, 'typing'):
                    await asyncio.sleep(random.uniform(1, 4))
                await event.reply(reply)
                print(f"💬 Replied to {sender_name}: {reply[:50]}...")
    # ========== RANDOM MESSAGE LOOP ==========
    async def random_message_loop():
        while True:
            try:
                wait_min = random.randint(RANDOM_MSG_MIN, RANDOM_MSG_MAX)
                await asyncio.sleep(wait_min * 60)
                dialogs = await client.get_dialogs()
                groups = [d for d in dialogs if d.is_group]
                if not groups:
                    continue
                group = random.choice(groups)
                msg = random.choice(RANDOM_MESSAGES)
                async with client.action(group.id, 'typing'):
                    await asyncio.sleep(random.uniform(2, 5))
                await client.send_message(group.id, msg)
                print(f"🎲 Random msg in {group.name}: {msg}")
                state["last_random"][str(group.id)] = datetime.now().timestamp()                save_state(state)
            except Exception as e:
                print(f"❌ Random msg error: {e}")
                await asyncio.sleep(60)
    asyncio.create_task(random_message_loop())
    await client.run_until_disconnected()
if __name__ == "__main__":
    asyncio.run(main())