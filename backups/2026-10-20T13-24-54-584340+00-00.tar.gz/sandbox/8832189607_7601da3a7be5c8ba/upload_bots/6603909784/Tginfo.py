import asyncio
import re
import random
from typing import Optional, List

import aiohttp
from pyrogram import Client
from pyrogram.errors import FloodWait
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

# ============== CONFIG ==============
API_ID = 29969433
API_HASH = "884f9ffa4e8ece099cccccade82effac"
PHONE_NUMBER = "+919214045762"
BOT_TOKEN = "8653713781:AAGbXvDPjDUjIDPobF3cj4-AMCTR_I9v3_A"
TARGET_BOT = "@telebrecheddb_bot"
# ===================================

tg_client: Optional[Client] = None


# ============== SCRAPER ==============

MT_SOURCES = [
    "https://mtpro.xyz/api/?type=mtproto",
    "https://raw.githubusercontent.com/hookzof/socks5_list/master/mtproto.txt"
]


async def fetch_mtproto_links():
    links = set()

    async with aiohttp.ClientSession() as session:
        tasks = [session.get(url, timeout=10) for url in MT_SOURCES]
        responses = await asyncio.gather(*tasks, return_exceptions=True)

        for resp in responses:
            try:
                text = await resp.text()
                found = re.findall(r"tg://proxy\?server=.*?secret=.*?", text)
                links.update(found)
            except:
                continue

    return list(links)


def parse_mtproto(link: str):
    try:
        server = re.search(r"server=([^&]+)", link).group(1)
        port = int(re.search(r"port=(\d+)", link).group(1))
        secret = re.search(r"secret=([^&]+)", link).group(1)

        return {
            "hostname": server,
            "port": port,
            "secret": secret
        }
    except:
        return None


# ============== TESTER ==============

async def test_proxy(proxy):
    try:
        client = Client(
            "test",
            api_id=API_ID,
            api_hash=API_HASH,
            proxy={
                "scheme": "mtproto",
                "hostname": proxy["hostname"],
                "port": proxy["port"],
                "secret": proxy["secret"],
            },
            no_updates=True,
        )

        await asyncio.wait_for(client.connect(), timeout=8)
        await client.disconnect()

        return proxy
    except:
        return None


async def get_working_proxies(limit=5):
    print("🔍 Fetching MTProto proxies...")
    links = await fetch_mtproto_links()

    proxies = []
    for link in links:
        parsed = parse_mtproto(link)
        if parsed:
            proxies.append(parsed)

    random.shuffle(proxies)

    tasks = [test_proxy(p) for p in proxies[:50]]

    working = []
    for coro in asyncio.as_completed(tasks):
        res = await coro
        if res:
            print(f"✅ Working: {res['hostname']}")
            working.append(res)

        if len(working) >= limit:
            break

    return working


# ============== INIT CLIENT ==============

async def init_client():
    global tg_client

    proxies = await get_working_proxies()

    if not proxies:
        raise RuntimeError("❌ No working MTProto proxies")

    for proxy in proxies:
        try:
            print(f"🔄 Connecting via {proxy['hostname']}")

            tg_client = Client(
                "main",
                api_id=API_ID,
                api_hash=API_HASH,
                phone_number=PHONE_NUMBER,
                proxy={
                    "scheme": "mtproto",
                    "hostname": proxy["hostname"],
                    "port": proxy["port"],
                    "secret": proxy["secret"],
                },
                no_updates=True,
            )

            await asyncio.wait_for(tg_client.start(), timeout=15)

            print("✅ Connected!")
            return

        except Exception as e:
            print(f"❌ Failed: {e}")
            try:
                await tg_client.stop()
            except:
                pass

    raise RuntimeError("❌ Could not connect")


# ============== CORE ==============

async def send_and_wait(username: str):
    global tg_client

    username = username.replace("@", "")
    msg = f"t.me/{username}"
try:
        sent = await tg_client.send_message(TARGET_BOT, msg)
    except FloodWait as e:
        await asyncio.sleep(e.value)
        sent = await tg_client.send_message(TARGET_BOT, msg)

    for _ in range(25):
        async for m in tg_client.get_chat_history(TARGET_BOT, limit=5):
            if m.id > sent.id and m.text:
                return m.text
        await asyncio.sleep(2)

    return None


# ============== BOT ==============

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Send /check @username")


async def check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        return await update.message.reply_text("Usage: /check @username")

    msg = await update.message.reply_text("🔍 Checking...")

    result = await send_and_wait(context.args[0])

    if not result:
        return await msg.edit_text("❌ Failed")

    await msg.edit_text(result, parse_mode=None)


# ============== MAIN ==============

async def main():
    await init_client()

    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("check", check))

    print("🤖 Bot running...")
    await app.run_polling()


if name == "main":
    asyncio.run(main())