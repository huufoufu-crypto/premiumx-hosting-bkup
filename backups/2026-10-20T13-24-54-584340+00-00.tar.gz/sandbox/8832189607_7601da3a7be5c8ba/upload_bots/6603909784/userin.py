import re
import io
import zipfile
import logging
import requests
from typing import Optional
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

# ================== CONFIG ==================
YOUR_BOT_TOKEN = "8909384473:AAFjdr0ILObj1kDRAjqlyoAskEVfIvCjICI"   # token of THIS bot
MAX_FILE_SIZE = 5 * 1024 * 1024          # 5 MB upload limit
# ============================================

TOKEN_REGEX = re.compile(r"\d{8,10}:[A-Za-z0-9_-]{35}")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)


# ---------- Helpers ----------
def get_bot_info(token: str) -> Optional[dict]:
    """Call Telegram getMe with the token."""
    try:
        r = requests.get(f"https://api.telegram.org/bot{token}/getMe", timeout=10)
        data = r.json()
        if data.get("ok"):
            return data["result"]
    except Exception as e:
        logging.error(f"getMe failed for {token[:10]}...: {e}")
    return None


def format_result(token: str, info: Optional[dict]) -> str:
    if info:
        return (
            f"✅ <b>Bot Identified</b>\n"
            f"🆔 ID: <code>{info['id']}</code>\n"
            f"👤 Name: {info.get('first_name', 'N/A')}\n"
            f"🔗 Username: @{info.get('username', 'N/A')}\n"
            f"📛 Is Bot: {info.get('is_bot', False)}\n"
            f"👥 Can Join Groups: {info.get('can_join_groups', False)}\n"
            f"📨 Read All Group Msgs: {info.get('can_read_all_group_messages', False)}\n"
            f"⚡ Inline Queries: {info.get('supports_inline_queries', False)}\n"
            f"🔑 Token: <code>{token}</code>"
        )
    return f"❌ Token <code>{token[:12]}...</code> is invalid or revoked."


def extract_tokens_from_text(text: str) -> set:
    return set(TOKEN_REGEX.findall(text))


def extract_from_py(content: bytes) -> set:
    """Read .py bytes and pull tokens."""
    try:
        return extract_tokens_from_text(content.decode("utf-8", errors="ignore"))
    except Exception:
        return set()


def extract_from_zip(content: bytes) -> set:
    """Walk a zip and read every .py / .txt / .env / .json file inside."""
    found = set()
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            for name in z.namelist():
                if name.endswith("/"):
                    continue
                if not name.lower().endswith(
                    (".py", ".txt", ".env", ".json", ".cfg", ".ini", ".yaml", ".yml")
                ):
                    continue
                try:
                    data = z.read(name)
                except Exception:
                    continue
                toks = extract_tokens_from_text(
                    data.decode("utf-8", errors="ignore")
                )
                if toks:
                    logging.info(f"Found {len(toks)} token(s) in {name}")
                    found.update(toks)
    except zipfile.BadZipFile:
        logging.warning("Bad zip file received")
    return found


# ---------- Handlers ----------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 Send me:\n"
        "• A <b>bot token</b> as text\n"
        "• A <b>.py</b> file\n"
        "• A <b>.zip</b> file containing .py files\n\n"
        "I'll extract the token and return the bot's username & info.",
        parse_mode="HTML",
    )


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()

    tokens = extract_tokens_from_text(text)
    if not tokens and ":" in text and len(text.split(":")) == 2:
        tokens = {text}

    if not tokens:
        await update.message.reply_text(
            "❌ No valid token found in your message."
        )
        return

    replies = [format_result(t, get_bot_info(t)) for t in tokens]
    await update.message.reply_text(
        "\n\n---\n\n".join(replies), parse_mode="HTML"
    )


async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    doc = update.message.document
    if not doc:
        return

    if doc.file_size and doc.file_size > MAX_FILE_SIZE:
        await update.message.reply_text("❌ File too large (max 5 MB).")
        return

    fname = (doc.file_name or "").lower()
    if not (fname.endswith(".py") or fname.endswith(".zip")):
        await update.message.reply_text(
            "❌ Only <b>.py</b> or <b>.zip</b> files are supported.",
            parse_mode="HTML",
        )
        return

    status = await update.message.reply_text("🔎 Scanning file...")

    try:
        tg_file = await doc.get_file()
        content = await tg_file.download_as_bytearray()
    except Exception as e:
        await status.edit_text(f"❌ Failed to download file: {e}")
        return

    if fname.endswith(".zip"):
        tokens = extract_from_zip(bytes(content))
    else:
        tokens = extract_from_py(bytes(content))

    if not tokens:
        await status.edit_text("❌ No bot token found in the file.")
        return

    replies = [format_result(t, get_bot_info(t)) for t in tokens]
    header = f"📄 Found <b>{len(tokens)}</b> token(s) in <code>{doc.file_name}</code>:\n\n"
    await status.edit_text(
        header + "\n\n---\n\n".join(replies),
        parse_mode="HTML",
    )


# ---------- Main ----------
def main():
    if YOUR_BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        raise ValueError("Set YOUR_BOT_TOKEN first.")

    app = Application.builder().token(YOUR_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    print("Bot is running...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()