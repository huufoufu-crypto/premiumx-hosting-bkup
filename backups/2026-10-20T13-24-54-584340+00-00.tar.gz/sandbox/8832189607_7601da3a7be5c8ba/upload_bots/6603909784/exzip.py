import os
import sys
import json
import uuid
import time
import asyncio
import logging
import zipfile
import tarfile
import shutil
from pathlib import Path
from datetime import datetime, timezone, timedelta

from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    ReplyKeyboardMarkup, KeyboardButton, BotCommand
)
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    filters, ContextTypes
)
from telegram.constants import ParseMode
from telegram.error import InvalidToken, NetworkError, TimedOut, Conflict

try:
    import py7zr
except ImportError:
    py7zr = None

from PIL import Image
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

# ══════════════════════════════════════════════════════
#  CONFIG  —  HARDCODED (env vars intentionally ignored)
# ══════════════════════════════════════════════════════
BOT_TOKEN = "8871686327:AAEMZmvRCfgx7cw8MRv_1LRpPJ5PLyiEd0Q"

# ── Owner (HARDCODED — cannot be overridden) ──────────
OWNER_USERNAME = "Ralt_18"          # your @username without @
OWNER_ID       = 6603909784         # your Telegram numeric ID (from screenshot)

# Optional proxy
PROXY_URL = ""                      # leave empty if unused

# Timezone (IST by default)
LOCAL_TZ = timezone(timedelta(hours=5, minutes=30), name="IST")

def now_local() -> datetime:
    return datetime.now(LOCAL_TZ)

def fmt_dt(dt: datetime) -> str:
    return dt.strftime("%d %b %Y • %H:%M:%S %Z")

def _pretty_iso(iso: str) -> str:
    try:
        return fmt_dt(datetime.fromisoformat(iso))
    except Exception:
        return iso or "—"

TEMP_DIR = Path("./temp_files"); TEMP_DIR.mkdir(exist_ok=True)
SAVE_DIR = Path("./user_storage"); SAVE_DIR.mkdir(exist_ok=True)
USERS_DB = Path("./users.json")
ADMINS_DB = Path("./admins.json")

# ══════════════════════════════════════════════════════
#  LOGGING
# ══════════════════════════════════════════════════════
logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
    level=logging.INFO,
    datefmt="%Y-%m-%d %H:%M:%S",
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.INFO)
log = logging.getLogger("FileToolsBot")

# ══════════════════════════════════════════════════════
#  STYLE HELPERS
# ══════════════════════════════════════════════════════
def bold(t):   return f"<b>{t}</b>"
def italic(t): return f"<i>{t}</i>"
def bi(t):     return f"<b><i>{t}</i></b>"
def code(t):   return f"<code>{t}</code>"
def under(t):  return f"<u>{t}</u>"

DIV = "━━━━━━━━━━━━━━━━━━━━"
MAX_PREVIEW = 700

# ══════════════════════════════════════════════════════
#  ADMIN / USER STORAGE
# ══════════════════════════════════════════════════════
def is_owner(user) -> bool:
    """Hardcoded owner check — matches by ID first, then username."""
    if user is None:
        return False
    # 1) ID check (highest priority)
    if user.id == OWNER_ID:
        return True
    # 2) Username fallback
    uname = (user.username or "").strip().lstrip("@").lower()
    if uname and uname == OWNER_USERNAME.strip().lower():
        return True
    return False

def load_admins() -> dict:
    if ADMINS_DB.exists():
        try:
            d = json.loads(ADMINS_DB.read_text(encoding="utf-8"))
            return {"ids": d.get("ids", []), "usernames": d.get("usernames", [])}
        except Exception as e:
            log.warning(f"admins.json corrupted, resetting: {e}")
    return {"ids": [], "usernames": []}

def save_admins(d: dict):
    try:
        ADMINS_DB.write_text(json.dumps(d, indent=2), encoding="utf-8")
    except Exception as e:
        log.error(f"admins save failed: {e}")

def is_admin(user) -> bool:
    if is_owner(user): return True
    a = load_admins()
    if user.id in a["ids"]: return True
    if user.username and user.username.lower() in [u.lower() for u in a["usernames"]]:
        return True
    return False

def load_users() -> dict:
    if USERS_DB.exists():
        try:
            return json.loads(USERS_DB.read_text(encoding="utf-8"))
        except Exception as e:
            log.warning(f"users.json corrupted, resetting: {e}")
    return {}

def save_users(u: dict):
    try:
        USERS_DB.write_text(json.dumps(u, indent=2), encoding="utf-8")
    except Exception as e:
        log.error(f"users save failed: {e}")

def register_user(user) -> dict:
    users = load_users()
    uid = str(user.id)
    now = now_local()

    if uid not in users:
        users[uid] = {
            "name": user.first_name or "User",
            "username": user.username or "",
            "joined": now.isoformat(),
            "last_seen": now.isoformat(),
        }
    else:
        users[uid]["name"] = user.first_name or users[uid].get("name", "User")
        users[uid]["username"] = user.username or users[uid].get("username", "")
        users[uid]["last_seen"] = now.isoformat()

    save_users(users)
    return users[uid]

# ══════════════════════════════════════════════════════
#  USER FILE STORAGE
# ══════════════════════════════════════════════════════
def user_save_dir(user_id: int) -> Path:
    d = SAVE_DIR / str(user_id)
    (d / "files").mkdir(parents=True, exist_ok=True)
    return d

def load_saved_index(user_id: int) -> list:
    idx = user_save_dir(user_id) / "index.json"
    if idx.exists():
        try:
            return json.loads(idx.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []

def save_saved_index(user_id: int, data: list):
    idx = user_save_dir(user_id) / "index.json"
    idx.write_text(json.dumps(data, indent=2), encoding="utf-8")

# ══════════════════════════════════════════════════════
#  CRYPTO
# ══════════════════════════════════════════════════════
def derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,
                     salt=salt, iterations=100_000)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def lock_file(filepath: str, password: str) -> str:
    salt = os.urandom(16)
    key = derive_key(password, salt)
    f = Fernet(key)
    with open(filepath, "rb") as fp:
        data = fp.read()
    out = filepath + ".locked"
    with open(out, "wb") as fp:
        fp.write(salt + f.encrypt(data))
    return out

def unlock_file(filepath: str, password: str) -> str:
    with open(filepath, "rb") as fp:
        salt = fp.read(16)
        enc = fp.read()
    key = derive_key(password, salt)
    try:
        data = Fernet(key).decrypt(enc)
    except Exception:
        raise ValueError("Wrong password")
    out = filepath[:-len(".locked")] if filepath.endswith(".locked") else filepath + ".unlocked"
    with open(out, "wb") as fp:
        fp.write(data)
    return out

# ══════════════════════════════════════════════════════
#  ARCHIVE
# ══════════════════════════════════════════════════════
def extract_archive(filepath: str, password, out_dir: str) -> list:
    suffix = Path(filepath).suffix.lower()
    os.makedirs(out_dir, exist_ok=True)

    if suffix == ".zip":
        with zipfile.ZipFile(filepath) as zf:
            zf.extractall(out_dir, pwd=password.encode() if password else None)
    elif suffix == ".7z":
        if py7zr is None:
            raise ValueError("py7zr not installed (pip install py7zr)")
        with py7zr.SevenZipFile(filepath, mode="r", password=password) as z:
            z.extractall(out_dir)
    elif suffix in (".tar", ".gz", ".bz2", ".xz", ".tgz"):
        with tarfile.open(filepath) as tf:
            tf.extractall(out_dir)
    elif suffix == ".rar":
        rc = os.system(
            f'unrar x -o+ {"-p" + password if password else ""} '
            f'"{filepath}" "{out_dir}" >/dev/null 2>&1'
        )
        if rc != 0:
            raise ValueError("rar extraction failed")
    else:
        raise ValueError(f"Unsupported: {suffix}")

    out = []
    for root, _, files in os.walk(out_dir):
        for f in files:
            out.append(os.path.join(root, f))
    return out

# ══════════════════════════════════════════════════════
#  IMAGES → PDF
# ══════════════════════════════════════════════════════
def images_to_pdf(paths: list, out: str):
    imgs = []
    for p in paths:
        try:
            img = Image.open(p)
            if img.mode != "RGB":
                img = img.convert("RGB")
            imgs.append(img)
        except Exception as e:
            log.warning(f"Skip {p}: {e}")
    if not imgs:
        raise ValueError("No valid images")
    imgs[0].save(out, "PDF", save_all=True, append_images=imgs[1:])

# ══════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════
def cleanup(*paths):
    for p in paths:
        try:
            if p and os.path.isdir(p):
                shutil.rmtree(p)
            elif p and os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass

def safe_name(name: str, default_ext: str = "") -> str:
    name = (name or "").strip().replace("/", "_").replace("\\", "_")
    if not name:
        name = "file" + default_ext
    return name[:100]

def fmt_size(n: int) -> str:
    if n < 1024: return f"{n} B"
    if n < 1024 * 1024: return f"{n/1024:.1f} KB"
    return f"{n/1024/1024:.1f} MB"

def analyze_file(path: str, name: str) -> dict:
    try:
        size = os.path.getsize(path)
    except Exception:
        size = 0
    ext = Path(name).suffix.lower()
    icon = "📄"; extra = ""

    if ext in (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"):
        icon = "🖼️"
        try:
            with Image.open(path) as im:
                extra = f" {im.width}×{im.height}"
        except Exception:
            pass
    elif ext in (".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz"):
        icon = "📦"
    elif ext in (".txt", ".md", ".py", ".json", ".csv", ".log",
                 ".html", ".css", ".js", ".xml", ".yaml", ".yml", ".ini", ".cfg"):
        icon = "📝"
        try:
            txt = Path(path).read_text(encoding="utf-8", errors="ignore")
            extra = f" · {len(txt)} chars"
        except Exception:
            pass
    elif ext == ".pdf":
        icon = "📕"
    elif ext in (".mp3", ".wav", ".ogg", ".m4a", ".flac"):
        icon = "🎵"
    elif ext in (".mp4", ".mov", ".avi", ".mkv", ".webm"):
        icon = "🎬"
    elif ext in (".doc", ".docx"):
        icon = "📘"
    elif ext in (".xls", ".xlsx"):
        icon = "📗"
    elif ext in (".ppt", ".pptx"):
        icon = "📙"
    elif ext in (".apk", ".exe", ".msi"):
        icon = "⚙️"
    return {"icon": icon, "size": size, "extra": extra}

def parse_line_spec(spec: str, total: int) -> set:
    result = set()
    for part in spec.split(","):
        part = part.strip()
        if not part: continue
        if "-" in part:
            try:
                a, b = part.split("-", 1)
                a, b = int(a.strip()), int(b.strip())
                if a > b: a, b = b, a
                for i in range(max(1, a), min(total, b) + 1):
                    result.add(i)
            except ValueError:
                pass
        else:
            try:
                i = int(part)
                if 1 <= i <= total:
                    result.add(i)
            except ValueError:
                pass
    return result

# ══════════════════════════════════════════════════════
#  KEYBOARDS
# ══════════════════════════════════════════════════════
def main_kb(show_admin=False):
    rows = [
        [KeyboardButton("📦 Extract Archive"), KeyboardButton("🔒 Lock File")],
        [KeyboardButton("📁 Build ZIP"),       KeyboardButton("💾 My Files")],
        [KeyboardButton("🖼️ Image to PDF"),   KeyboardButton("✏️ File Editor")],
        [KeyboardButton("📝 Text to File"),   KeyboardButton("🛠️ Tools")],
        [KeyboardButton("❓ Help"),            KeyboardButton("📊 Status")],
    ]
    if show_admin:
        rows.append([KeyboardButton("👑 Admin Panel")])
    return ReplyKeyboardMarkup(
        rows, resize_keyboard=True, one_time_keyboard=False, is_persistent=True,
        input_field_placeholder="Tap a menu button…"
    )

def pdf_kb():
    return ReplyKeyboardMarkup(
        [[KeyboardButton("✅ Generate PDF")], [KeyboardButton("🔙 Cancel PDF")]],
        resize_keyboard=True, one_time_keyboard=False, is_persistent=True,
        input_field_placeholder="Send images…"
    )

def textfile_kb():
    return ReplyKeyboardMarkup(
        [
            [KeyboardButton("👁️ View Lines"), KeyboardButton("🗑️ Delete Line")],
            [KeyboardButton("✅ Create File")],
            [KeyboardButton("🔙 Cancel")],
        ],
        resize_keyboard=True, one_time_keyboard=False, is_persistent=True,
        input_field_placeholder="Type text…"
    )

def editor_kb():
    return ReplyKeyboardMarkup(
        [
            [KeyboardButton("✏️ Replace Content"), KeyboardButton("➕ Append Text")],
            [KeyboardButton("🗑️ Delete Line"),    KeyboardButton("👁️ View File")],
            [KeyboardButton("💾 Save & Send")],
            [KeyboardButton("🔙 Cancel")],
        ],
        resize_keyboard=True, one_time_keyboard=False, is_persistent=True,
        input_field_placeholder="Choose action…"
    )

def zipfolder_kb():
    return ReplyKeyboardMarkup(
        [[KeyboardButton("📦 Create ZIP")], [KeyboardButton("🔙 Cancel")]],
        resize_keyboard=True, one_time_keyboard=False, is_persistent=True,
        input_field_placeholder="Send files to add…"
    )

def savefiles_kb():
    return ReplyKeyboardMarkup(
        [
            [KeyboardButton("➕ Add Files")],
            [KeyboardButton("📂 View Saved")],
            [KeyboardButton("🔙 Done")],
        ],
        resize_keyboard=True, one_time_keyboard=False, is_persistent=True,
        input_field_placeholder="Send files to save…"
    )

def filename_kb():
    return ReplyKeyboardMarkup(
        [[KeyboardButton("🔙 Cancel")]],
        resize_keyboard=True, one_time_keyboard=False, is_persistent=True,
        input_field_placeholder="Type the filename…"
    )

def lock_choice_kb():
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("🔒 Yes, Lock it", callback_data="lock_yes"),
        InlineKeyboardButton("📤 No, Send Plain", callback_data="lock_no"),
    ]])

def pdf_lock_choice():
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("🔒 Yes, Lock it", callback_data="pdf_yes"),
        InlineKeyboardButton("📤 No, Send Plain", callback_data="pdf_no"),
    ]])

def admin_panel_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📋 List Admins", callback_data="adm_list")],
        [
            InlineKeyboardButton("➕ Add Admin",    callback_data="adm_add"),
            InlineKeyboardButton("➖ Remove Admin", callback_data="adm_remove"),
        ],
        [InlineKeyboardButton("📊 Bot Stats", callback_data="adm_stats")],
    ])

# ══════════════════════════════════════════════════════
#  ZIP FOLDER BUILDER
# ══════════════════════════════════════════════════════
def folder_list_kb(files: list):
    if not files:
        return None
    rows = []
    for i, f in enumerate(files):
        nm = f["name"]
        if len(nm) > 22: nm = nm[:19] + "…"
        rows.append([InlineKeyboardButton(
            f"{i+1}. {f.get('icon','📄')} {nm}",
            callback_data=f"zfb_sel_{i}"
        )])
    rows.append([InlineKeyboardButton("🗑️ Clear All", callback_data="zfb_clear")])
    rows.append([InlineKeyboardButton("📦 Create ZIP", callback_data="zfb_done")])
    return InlineKeyboardMarkup(rows)

def folder_file_kb(files: list, idx: int):
    if idx < 0 or idx >= len(files):
        return folder_list_kb(files)
    f = files[idx]
    nm = f["name"]
    if len(nm) > 30: nm = nm[:27] + "…"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"📄 {nm}", callback_data="zfb_noop")],
        [
            InlineKeyboardButton("⬆️ Move Up",   callback_data=f"zfb_up_{idx}"),
            InlineKeyboardButton("⬇️ Move Down", callback_data=f"zfb_dn_{idx}"),
        ],
        [
            InlineKeyboardButton("✏️ Rename", callback_data=f"zfb_rn_{idx}"),
            InlineKeyboardButton("🗑️ Delete", callback_data=f"zfb_rm_{idx}"),
        ],
        [InlineKeyboardButton("🔙 Back to Folder", callback_data="zfb_back")],
    ])

def build_folder_preview(files: list) -> str:
    if not files:
        return (
            f"{bi('📁  FOLDER BUILDER')}\n{DIV}\n\n"
            f"{italic('Folder is empty. Send files to add them.')}\n\n"
            f"💡 {italic('Tap a file to reorder, rename, or delete it.')}"
        )
    total = sum(f.get("size", 0) for f in files)
    lines = []
    for i, f in enumerate(files):
        icon = f.get("icon", "📄")
        size = f.get("size", 0)
        extra = f.get("extra", "")
        nm = f["name"]
        if len(nm) > 28: nm = nm[:25] + "…"
        lines.append(
            f"{icon}  {bold(str(i+1) + '.')} {code(nm)}\n"
            f"       {italic(fmt_size(size) + extra)}"
        )
    return (
        f"{bi('📁  FOLDER PREVIEW')}\n{DIV}\n\n"
        + "\n".join(lines) + "\n"
        + f"{DIV}\n"
        + f"📊  {bold('Total:')} {code(str(len(files)) + ' file(s)')}  •  {code(fmt_size(total))}\n\n"
        + f"{italic('Tap any file below to reorder / rename / delete')}"
    )

def build_folder_file_view(files: list, idx: int) -> str:
    if idx < 0 or idx >= len(files):
        return build_folder_preview(files)
    f = files[idx]
    total = len(files)
    up_hint = "✅ Top"     if idx == 0            else f"⬆️ will swap with #{idx}"
    dn_hint = "✅ Bottom"  if idx == total - 1    else f"⬇️ will swap with #{idx + 2}"
    return (
        f"{bi('📄  MANAGE FILE')}\n{DIV}\n\n"
        f"{f.get('icon','📄')}  {bold('Name:')} {code(f['name'])}\n"
        f"📏  {bold('Size:')} {code(fmt_size(f.get('size', 0)) + f.get('extra', ''))}\n"
        f"📍  {bold('Position:')} {code(f'{idx + 1} of {total}')}\n"
        f"{DIV}\n"
        f"⬆️ {italic(up_hint)}\n"
        f"⬇️ {italic(dn_hint)}\n"
        f"{DIV}\n"
        f"{italic('Choose an action:')}"
    )

# ══════════════════════════════════════════════════════
#  MY FILES
# ══════════════════════════════════════════════════════
def saved_files_kb(items: list):
    if not items:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Add Files", callback_data="svf_add")],
        ])
    rows = []
    for it in items:
        nm = it["name"]
        if len(nm) > 25: nm = nm[:22] + "…"
        fid = it["id"]
        rows.append([
            InlineKeyboardButton(f"📥 {nm}", callback_data=f"svf_dl_{fid}"),
            InlineKeyboardButton("🗑️",        callback_data=f"svf_rm_{fid}"),
        ])
    rows.append([InlineKeyboardButton("➕ Add Files", callback_data="svf_add")])
    rows.append([InlineKeyboardButton("🗑️ Clear All", callback_data="svf_clear")])
    return InlineKeyboardMarkup(rows)

def build_saved_view(items: list) -> str:
    if not items:
        return (
            f"{bi('💾  MY FILES')}\n{DIV}\n\n"
            f"{italic('Your storage is empty.')}\n\n"
            f"💡 {italic('Tap ➕ Add Files or just send files to save them.')}"
        )
    total = sum(it.get("size", 0) for it in items)
    return (
        f"{bi('💾  MY FILES')}\n{DIV}\n\n"
        f"📂  {bold('Saved:')} {code(str(len(items)) + ' file(s)')}\n"
        f"📏  {bold('Total:')} {code(fmt_size(total))}\n"
        f"{DIV}\n"
        f"{italic('Tap 📥 to download • 🗑️ to delete')}"
    )

# ══════════════════════════════════════════════════════
#  WELCOME
# ══════════════════════════════════════════════════════
async def send_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    info = register_user(user)
    owner = is_owner(user)
    admin = is_admin(user)

    if owner:   role = "👑 Owner • Administrator"
    elif admin: role = "🛡️ Administrator"
    else:       role = "👤 User"

    joined_str = _pretty_iso(info.get("joined", ""))
    seen_str   = _pretty_iso(info.get("last_seen", ""))

    caption = (
        f"⚡  {bi('F I L E   T O O L S   B O T')}  ⚡\n"
        f"✨ {italic('Welcome back,')} {bold(user.first_name)} ✨\n"
        f"{DIV}\n"
        f"👤  {bold('User')}         ➜  {under('@' + (user.username or 'NoUsername'))}\n"
        f"🆔  {bold('User ID')}      ➜  {code(str(user.id))}\n"
        f"🎖️  {bold('Role')}         ➜  {role}\n"
        f"📅  {bold('First joined')} ➜  {code(joined_str)}\n"
        f"🕒  {bold('Last seen')}    ➜  {code(seen_str)}\n"
        f"{DIV}\n"
        f"👑  {bold('Developer')}    ➜  {italic('@' + OWNER_USERNAME)}\n"
        f"🚀  {italic('Use the menu below to begin')} ✨"
    )
    kb = main_kb(show_admin=(owner or admin))
    try:
        photos = await context.bot.get_user_profile_photos(user.id, limit=1)
        if photos.total_count > 0:
            fid = photos.photos[0][0].file_id
            await update.message.reply_photo(
                photo=fid, caption=caption,
                parse_mode=ParseMode.HTML, reply_markup=kb)
            return
    except Exception as e:
        log.warning(f"PFP failed: {e}")
    await update.message.reply_text(caption, parse_mode=ParseMode.HTML, reply_markup=kb)

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await send_welcome(update, context)

async def cmd_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    await update.message.reply_text(
        f"{bi('🆔  YOUR INFO')}\n{DIV}\n\n"
        f"👤 {code(str(u.id))}\n"
        f"📛 @{u.username or 'none'}\n"
        f"🎖️ {'👑 Owner' if is_owner(u) else ('🛡️ Admin' if is_admin(u) else '👤 User')}",
        parse_mode=ParseMode.HTML)

# ══════════════════════════════════════════════════════
#  FINALIZERS
# ══════════════════════════════════════════════════════
async def finalize_generic(update, context, src_path: str, out_name: str,
                            password=None, caption_ok: str = "📄  File ready!"):
    user = update.effective_user
    chat_id = update.effective_chat.id
    try:
        if password:
            locked = lock_file(str(src_path), password)
            with open(locked, "rb") as fh:
                await context.bot.send_document(
                    chat_id=chat_id, document=fh,
                    filename=out_name + ".locked",
                    caption=bi("🔒  Locked & sent!") + "\n"
                            + italic("Send back to unlock anytime."),
                    parse_mode=ParseMode.HTML)
            cleanup(src_path, locked)
        else:
            with open(src_path, "rb") as fh:
                await context.bot.send_document(
                    chat_id=chat_id, document=fh,
                    filename=out_name,
                    caption=bi(caption_ok),
                    parse_mode=ParseMode.HTML)
            cleanup(src_path)
    except Exception as e:
        log.exception("finalize failed")
        await context.bot.send_message(
            chat_id=chat_id,
            text=f"{bold('❌  Failed:')} {code(str(e))}",
            parse_mode=ParseMode.HTML)
    context.user_data.clear()
    await context.bot.send_message(
        chat_id=chat_id,
        text=italic("✅ Done! Menu is below 👇"),
        parse_mode=ParseMode.HTML,
        reply_markup=main_kb(show_admin=is_admin(user)))

async def finalize_text_file(update, context, password=None):
    content = context.user_data.get("text_file_content", "")
    fname = context.user_data.get("output_filename", "note.txt")
    tmp = TEMP_DIR / f"txt_{update.effective_user.id}_{int(time.time())}_{fname}"
    tmp.write_text(content, encoding="utf-8")
    await finalize_generic(update, context, str(tmp), fname, password,
                           caption_ok="📄  Your text file is ready!")

async def finalize_editor_file(update, context, password=None):
    content = context.user_data.get("editor_content", "")
    fname = context.user_data.get("output_filename", "edited.txt")
    tmp = TEMP_DIR / f"edit_{update.effective_user.id}_{int(time.time())}_{fname}"
    tmp.write_text(content, encoding="utf-8")
    await finalize_generic(update, context, str(tmp), fname, password,
                           caption_ok="📄  Edited file ready!")

async def finalize_zip(update, context, password=None):
    files = list(context.user_data.get("zip_folder_files", []))
    if not files:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=bold("⚠️  Folder is empty — nothing to ZIP."),
            parse_mode=ParseMode.HTML,
            reply_markup=main_kb(is_admin(update.effective_user)))
        context.user_data.clear()
        return
    fname = context.user_data.get("output_filename", "folder.zip")
    tmp = TEMP_DIR / f"zip_{update.effective_user.id}_{int(time.time())}.zip"
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
            used = set()
            for f in files:
                arc = f["name"]
                base, ext2 = os.path.splitext(arc)
                n = 1
                while arc in used:
                    arc = f"{base}_{n}{ext2}"
                    n += 1
                used.add(arc)
                try:
                    zf.write(f["path"], arc)
                except Exception as e:
                    log.warning(f"skip {arc}: {e}")
        await finalize_generic(update, context, str(tmp), fname, password,
                               caption_ok=f"📦  ZIP created with {len(files)} file(s)!")
    except Exception as e:
        log.exception("zip failed")
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=f"{bold('❌  ZIP failed:')} {code(str(e))}",
            parse_mode=ParseMode.HTML)
    for f in files:
        cleanup(f.get("path", ""))

# ══════════════════════════════════════════════════════
#  CALLBACK HANDLER
# ══════════════════════════════════════════════════════
async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data
    admin = is_admin(update.effective_user)

    try:
        if data == "zfb_noop":
            return

        if data.startswith("zfb_sel_"):
            idx = int(data.split("_")[-1])
            files = context.user_data.get("zip_folder_files", [])
            if 0 <= idx < len(files):
                context.user_data["zfb_selected"] = idx
                text = build_folder_file_view(files, idx)
                try:
                    await q.message.edit_text(text, parse_mode=ParseMode.HTML,
                                              reply_markup=folder_file_kb(files, idx))
                except Exception:
                    await q.message.reply_text(text, parse_mode=ParseMode.HTML,
                                               reply_markup=folder_file_kb(files, idx))
            return

        if data == "zfb_back":
            files = context.user_data.get("zip_folder_files", [])
            context.user_data.pop("zfb_selected", None)
            text = build_folder_preview(files)
            try:
                await q.message.edit_text(text, parse_mode=ParseMode.HTML,
                                          reply_markup=folder_list_kb(files))
            except Exception:
                await q.message.reply_text(text, parse_mode=ParseMode.HTML,
                                           reply_markup=folder_list_kb(files))
            return

        if data.startswith("zfb_up_"):
            idx = int(data.split("_")[-1])
            files = context.user_data.get("zip_folder_files", [])
            if 0 < idx < len(files):
                files[idx - 1], files[idx] = files[idx], files[idx - 1]
                new_idx = idx - 1
            else:
                new_idx = idx
            context.user_data["zfb_selected"] = new_idx
            text = build_folder_file_view(files, new_idx)
            try:
                await q.message.edit_text(text, parse_mode=ParseMode.HTML,
                                          reply_markup=folder_file_kb(files, new_idx))
            except Exception:
                await q.message.reply_text(text, parse_mode=ParseMode.HTML,
                                           reply_markup=folder_file_kb(files, new_idx))
            return

        if data.startswith("zfb_dn_"):
            idx = int(data.split("_")[-1])
            files = context.user_data.get("zip_folder_files", [])
            if 0 <= idx < len(files) - 1:
                files[idx + 1], files[idx] = files[idx], files[idx + 1]
                new_idx = idx + 1
            else:
                new_idx = idx
            context.user_data["zfb_selected"] = new_idx
            text = build_folder_file_view(files, new_idx)
            try:
                await q.message.edit_text(text, parse_mode=ParseMode.HTML,
                                          reply_markup=folder_file_kb(files, new_idx))
            except Exception:
                await q.message.reply_text(text, parse_mode=ParseMode.HTML,
                                           reply_markup=folder_file_kb(files, new_idx))
            return

        if data.startswith("zfb_rn_"):
            idx = int(data.split("_")[-1])
            files = context.user_data.get("zip_folder_files", [])
            if 0 <= idx < len(files):
                context.user_data["zfb_selected"] = idx
                context.user_data["awaiting"] = "zfb_rename_input"
                f = files[idx]
                await q.message.edit_text(
                    f"{bi('✏️  RENAME FILE')}\n{DIV}\n\n"
                    f"Current: {code(f['name'])}\n\n"
                    f"{italic('Send the new filename.')}",
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("🔙 Cancel", callback_data="zfb_back")
                    ]]))
            return

        if data.startswith("zfb_rm_"):
            idx = int(data.split("_")[-1])
            files = context.user_data.get("zip_folder_files", [])
            if 0 <= idx < len(files):
                removed = files.pop(idx)
                cleanup(removed.get("path", ""))
            context.user_data.pop("zfb_selected", None)
            text = build_folder_preview(files)
            try:
                await q.message.edit_text(text, parse_mode=ParseMode.HTML,
                                          reply_markup=folder_list_kb(files))
            except Exception:
                await q.message.reply_text(text, parse_mode=ParseMode.HTML,
                                           reply_markup=folder_list_kb(files))
            return

        if data == "zfb_clear":
            files = context.user_data.get("zip_folder_files", [])
            for f in files:
                cleanup(f.get("path", ""))
            files.clear()
            context.user_data.pop("zfb_selected", None)
            text = build_folder_preview(files)
            try:
                await q.message.edit_text(text, parse_mode=ParseMode.HTML)
            except Exception:
                await q.message.reply_text(text, parse_mode=ParseMode.HTML)
            return

        if data == "zfb_done":
            files = context.user_data.get("zip_folder_files", [])
            if not files:
                await q.answer("Folder is empty!", show_alert=True)
                return
            context.user_data["awaiting"] = "zip_filename"
            await q.message.reply_text(
                f"{bi('📄  ZIP FILENAME')}\n{DIV}\n\n"
                f"{italic('Send the filename for your ZIP.')}\n"
                f"{bold('Tap')} {code('/keep')} {bold('for default')} {code('folder.zip')}\n\n"
                f"📦  {bold('Files:')} {code(str(len(files)))}",
                parse_mode=ParseMode.HTML, reply_markup=filename_kb())
            return

        if data == "svf_add":
            context.user_data["awaiting"] = "savefiles_upload"
            items = load_saved_index(update.effective_user.id)
            await q.message.reply_text(
                f"{bi('➕  ADD FILES TO STORAGE')}\n{DIV}\n\n"
                f"{italic('Send me files to save.')}\n\n"
                f"📂  {bold('Currently stored:')} {code(str(len(items)) + ' file(s)')}\n\n"
                f"💡 {italic('Tap 🔙 Done when finished')}",
                parse_mode=ParseMode.HTML, reply_markup=savefiles_kb())
            return

        if data.startswith("svf_dl_"):
            fid = data[len("svf_dl_"):]
            uid = update.effective_user.id
            items = load_saved_index(uid)
            target = next((it for it in items if it["id"] == fid), None)
            if not target:
                await q.answer("File not found", show_alert=True)
                return
            fdir = user_save_dir(uid) / "files"
            matches = list(fdir.glob(f"{fid}*"))
            if not matches:
                await q.answer("File missing on disk", show_alert=True)
                return
            try:
                with open(matches[0], "rb") as fh:
                    await q.message.reply_document(
                        document=fh, filename=target["name"],
                        caption=bi(f"📥  {target['name']}"),
                        parse_mode=ParseMode.HTML)
            except Exception as e:
                await q.message.reply_text(
                    f"{bold('❌  Send failed:')} {code(str(e))}",
                    parse_mode=ParseMode.HTML)
            return

        if data.startswith("svf_rm_"):
            fid = data[len("svf_rm_"):]
            uid = update.effective_user.id
            items = load_saved_index(uid)
            target = next((it for it in items if it["id"] == fid), None)
            if target:
                fdir = user_save_dir(uid) / "files"
                for p in fdir.glob(f"{fid}*"):
                    cleanup(str(p))
                items = [it for it in items if it["id"] != fid]
                save_saved_index(uid, items)
            view = build_saved_view(items)
            try:
                await q.message.edit_text(view, parse_mode=ParseMode.HTML,
                                          reply_markup=saved_files_kb(items))
            except Exception:
                await q.message.reply_text(view, parse_mode=ParseMode.HTML,
                                           reply_markup=saved_files_kb(items))
            return

        if data == "svf_clear":
            uid = update.effective_user.id
            fdir = user_save_dir(uid) / "files"
            for p in fdir.glob("*"):
                cleanup(str(p))
            save_saved_index(uid, [])
            view = build_saved_view([])
            try:
                await q.message.edit_text(view, parse_mode=ParseMode.HTML,
                                          reply_markup=saved_files_kb([]))
            except Exception:
                await q.message.reply_text(view, parse_mode=ParseMode.HTML,
                                           reply_markup=saved_files_kb([]))
            return

        if data == "svf_cancel":
            context.user_data.pop("awaiting", None)
            uid = update.effective_user.id
            items = load_saved_index(uid)
            view = build_saved_view(items)
            try:
                await q.message.edit_text(view, parse_mode=ParseMode.HTML,
                                          reply_markup=saved_files_kb(items))
            except Exception:
                await q.message.reply_text(view, parse_mode=ParseMode.HTML,
                                           reply_markup=saved_files_kb(items))
            return

        if data == "pdf_yes":
            context.user_data["awaiting"] = "pdf_lock_password"
            await q.message.edit_text(
                f"{bi('🔐  SET PDF PASSWORD')}\n{DIV}\n\n"
                f"{italic('Send a password to encrypt the PDF.')}\n"
                f"⚠️  {bold('Cannot be recovered!')}",
                parse_mode=ParseMode.HTML)
        elif data == "pdf_no":
            pdf_path = context.user_data.get("pending_pdf")
            fname = context.user_data.get("output_filename", "converted.pdf")
            imgs = context.user_data.get("pdf_images", [])
            if pdf_path and os.path.exists(pdf_path):
                with open(pdf_path, "rb") as f:
                    await q.message.reply_document(
                        document=f, filename=fname,
                        caption=bi("📄  Your PDF is ready!"),
                        parse_mode=ParseMode.HTML)
            cleanup(pdf_path or "", *imgs)
            context.user_data.clear()
            await q.message.reply_text(
                italic("✅ Done! Menu below 👇"),
                parse_mode=ParseMode.HTML, reply_markup=main_kb(admin))

        elif data == "lock_yes":
            flow = context.user_data.get("lock_flow")
            if flow == "text_file":  context.user_data["awaiting"] = "text_file_password"
            elif flow == "editor":   context.user_data["awaiting"] = "editor_password"
            elif flow == "zip":      context.user_data["awaiting"] = "zip_password"
            await q.message.edit_text(
                f"{bi('🔐  SET PASSWORD')}\n{DIV}\n\n"
                f"{italic('Send a password to encrypt the file.')}",
                parse_mode=ParseMode.HTML)
        elif data == "lock_no":
            flow = context.user_data.get("lock_flow")
            if flow == "text_file":  await finalize_text_file(update, context, password=None)
            elif flow == "editor":   await finalize_editor_file(update, context, password=None)
            elif flow == "zip":      await finalize_zip(update, context, password=None)

        elif data == "adm_list":
            if not admin: return
            a = load_admins()
            ids = "\n".join([f"• {code(str(i))}" for i in a["ids"]]) or italic("(none)")
            uns = "\n".join([f"• @{u}" for u in a["usernames"]]) or italic("(none)")
            await q.message.edit_text(
                f"{bi('📋  ADMINS LIST')}\n{DIV}\n\n"
                f"👑  {bold('Owner')} ➜ @{OWNER_USERNAME}\n\n"
                f"{bold('By ID:')}\n{ids}\n\n"
                f"{bold('By Username:')}\n{uns}",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back", callback_data="adm_back")],
                ]))
        elif data == "adm_back":
            if not admin: return
            await q.message.edit_text(
                f"{bi('👑  ADMIN PANEL')}\n{DIV}\n\n"
                f"{italic('Choose an action:')}",
                parse_mode=ParseMode.HTML, reply_markup=admin_panel_kb())
        elif data == "adm_add":
            if not admin: return
            context.user_data["awaiting"] = "admin_add_input"
            await q.message.edit_text(
                f"{bi('➕  ADD ADMIN')}\n{DIV}\n\n"
                f"{italic('Send a numeric user ID or @username.')}",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back", callback_data="adm_back")],
                ]))
        elif data == "adm_remove":
            if not admin: return
            context.user_data["awaiting"] = "admin_remove_input"
            await q.message.edit_text(
                f"{bi('➖  REMOVE ADMIN')}\n{DIV}\n\n"
                f"{italic('Send a numeric user ID or @username.')}",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back", callback_data="adm_back")],
                ]))
        elif data == "adm_stats":
            if not admin: return
            users = load_users()
            a = load_admins()
            await q.message.edit_text(
                f"{bi('📊  BOT STATS')}\n{DIV}\n\n"
                f"👥  {bold('Users')}    ➜  {code(str(len(users)))}\n"
                f"🛡️  {bold('Admins')}   ➜  {code(str(len(a['ids']) + len(a['usernames']) + 1))}\n"
                f"🕒  {bold('Time')}     ➜  {code(fmt_dt(now_local()))}",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back", callback_data="adm_back")],
                ]))

    except Exception as e:
        log.exception("Callback error")
        try:
            await q.message.reply_text(
                f"{bold('⚠️ Error:')} {code(str(e))}",
                parse_mode=ParseMode.HTML, reply_markup=main_kb(admin))
        except Exception:
            pass

# ══════════════════════════════════════════════════════
#  FILE HANDLER
# ══════════════════════════════════════════════════════
async def on_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    admin = is_admin(update.effective_user)
    awaiting = context.user_data.get("awaiting")

    if msg.photo:
        photo = msg.photo[-1]
        tg_file = await photo.get_file()
        fname = f"photo_{photo.file_unique_id}.jpg"
        ext = ".jpg"
    elif msg.document:
        doc = msg.document
        tg_file = await doc.get_file()
        fname = doc.file_name or "file"
        ext = Path(fname).suffix.lower()
    else:
        return

    log.info(f"File: {fname} | awaiting={awaiting}")

    if ext == ".locked":
        tmp = TEMP_DIR / f"unlock_{msg.message_id}_{fname}"
        await tg_file.download_to_drive(str(tmp))
        context.user_data["locked_file"] = str(tmp)
        context.user_data["awaiting"] = "unlock_password"
        await msg.reply_text(
            f"{bi('🔐  LOCKED FILE DETECTED')}\n{DIV}\n\n"
            f"{italic('Send me the password to unlock it.')}",
            parse_mode=ParseMode.HTML)
        return

    if awaiting == "savefiles_upload":
        uid = update.effective_user.id
        fid = uuid.uuid4().hex[:12]
        dest = user_save_dir(uid) / "files" / f"{fid}{ext}"
        await tg_file.download_to_drive(str(dest))
        info = analyze_file(str(dest), fname)
        items = load_saved_index(uid)
        items.append({
            "id": fid, "name": fname,
            "size": info["size"], "icon": info["icon"], "extra": info["extra"],
            "saved_at": now_local().isoformat(),
        })
        save_saved_index(uid, items)
        await msg.reply_text(
            f"{bi('💾  FILE SAVED')}\n{DIV}\n\n"
            f"{info['icon']}  {code(fname)}\n"
            f"📏  {code(fmt_size(info['size']) + info['extra'])}\n\n"
            f"📂  {bold('Total saved:')} {code(str(len(items)))}",
            parse_mode=ParseMode.HTML, reply_markup=savefiles_kb())
        return

    if awaiting == "zip_folder_collect":
        tmp = TEMP_DIR / f"zf_{msg.message_id}_{fname}"
        await tg_file.download_to_drive(str(tmp))
        info = analyze_file(str(tmp), fname)
        files = context.user_data.setdefault("zip_folder_files", [])
        files.append({"path": str(tmp), "name": fname, **info})
        await msg.reply_text(build_folder_preview(files),
                             parse_mode=ParseMode.HTML,
                             reply_markup=folder_list_kb(files))
        return

    if awaiting == "lock_file":
        tmp = TEMP_DIR / f"lock_{msg.message_id}_{fname}"
        await tg_file.download_to_drive(str(tmp))
        context.user_data["file_to_lock"] = str(tmp)
        context.user_data["original_name"] = fname
        context.user_data["awaiting"] = "lock_filename"
        await msg.reply_text(
            f"{bi('📄  OUTPUT FILENAME')}\n{DIV}\n\n"
            f"{italic('Send the filename for the locked file.')}\n"
            f"{bold('Or tap')} {code('/keep')} {bold('to keep original.')}\n\n"
            f"Original: {code(fname)}",
            parse_mode=ParseMode.HTML, reply_markup=filename_kb())
        return

    if awaiting == "editor_file_upload":
        text_exts = (".txt", ".md", ".py", ".json", ".csv", ".log",
                     ".html", ".css", ".js", ".xml", ".yaml", ".yml",
                     ".ini", ".cfg", ".conf", ".sh", ".bat")
        if ext not in text_exts and not (msg.document and (msg.document.mime_type or "").startswith("text/")):
            await msg.reply_text(
                f"{bold('❌  Not a text file.')}\n"
                f"{italic('Send .txt, .md, .py, .json, .csv, etc.')}",
                parse_mode=ParseMode.HTML, reply_markup=editor_kb())
            return
        tmp = TEMP_DIR / f"edit_{msg.message_id}_{fname}"
        await tg_file.download_to_drive(str(tmp))
        try:
            content = Path(tmp).read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            await msg.reply_text(
                f"{bold('❌  Cannot read:')} {code(str(e))}",
                parse_mode=ParseMode.HTML, reply_markup=main_kb(admin))
            context.user_data.clear()
            return
        context.user_data["editor_file_path"] = str(tmp)
        context.user_data["editor_file_name"] = fname
        context.user_data["editor_content"] = content
        context.user_data["awaiting"] = "editor_actions"
        preview = content[:MAX_PREVIEW] + ("\n…(truncated)" if len(content) > MAX_PREVIEW else "")
        n_lines = len(content.split("\n"))
        await msg.reply_text(
            f"{bi('✏️  FILE EDITOR')}\n{DIV}\n\n"
            f"📄  {bold('File:')} {code(fname)}\n"
            f"📏  {bold('Size:')} {code(str(len(content)) + ' chars')}  •  "
            f"{bold('Lines:')} {code(str(n_lines))}\n"
            f"{DIV}\n"
            f"{bold('Preview:')}\n<pre>{preview}</pre>\n"
            f"{DIV}\n"
            f"{italic('Choose action below 👇')}",
            parse_mode=ParseMode.HTML, reply_markup=editor_kb())
        return

    if awaiting == "pdf_images" and ext in (".jpg", ".jpeg", ".png", ".bmp", ".gif", ".webp"):
        tmp = TEMP_DIR / f"pdf_{msg.message_id}_{fname}"
        await tg_file.download_to_drive(str(tmp))
        context.user_data.setdefault("pdf_images", []).append(str(tmp))
        count = len(context.user_data["pdf_images"])
        await msg.reply_text(
            f"{bi('🖼️  IMAGE ADDED')}\n{DIV}\n\n"
            f"📸  {bold(f'Total: {count} image(s)')}\n"
            f"{italic('Send more or tap ✅ Generate PDF below')}",
            parse_mode=ParseMode.HTML, reply_markup=pdf_kb())
        return

    if ext in (".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz", ".tgz"):
        tmp = TEMP_DIR / f"arch_{msg.message_id}_{fname}"
        await tg_file.download_to_drive(str(tmp))
        out_dir = TEMP_DIR / f"extract_{msg.message_id}"
        context.user_data["archive_file"] = str(tmp)
        context.user_data["out_dir"] = str(out_dir)
        try:
            files = extract_archive(str(tmp), None, str(out_dir))
            await send_extracted(update, context, files)
        except Exception as e:
            err = str(e).lower()
            needs_pass = any(k in err for k in ("password", "encrypted", "pwd", "pass"))
            if needs_pass:
                context.user_data["awaiting"] = "archive_password"
                await msg.reply_text(
                    f"{bi('🔒  PASSWORD REQUIRED')}\n{DIV}\n\n"
                    f"{italic('This archive is password-protected.')}\n"
                    f"{bold('Send the password:')}",
                    parse_mode=ParseMode.HTML)
            else:
                await msg.reply_text(
                    f"{bold('❌  Extraction failed')}\n{code(str(e))}",
                    parse_mode=ParseMode.HTML)
        return

    await msg.reply_text(
        f"{bold('❓  Unsupported file')}\n"
        f"{italic('Use the menu below first.')}",
        parse_mode=ParseMode.HTML, reply_markup=main_kb(admin))

async def send_extracted(update, context, files):
    msg = update.message
    if not files:
        await msg.reply_text(bold("⚠️  Archive was empty."), parse_mode=ParseMode.HTML)
        return
    await msg.reply_text(
        f"{bi('✅  EXTRACTION COMPLETE')}\n{DIV}\n\n"
        f"📁  {bold(f'Found {len(files)} file(s)')}",
        parse_mode=ParseMode.HTML)
    for fp in files[:10]:
        try:
            with open(fp, "rb") as fh:
                await msg.reply_document(
                    document=fh, filename=os.path.basename(fp),
                    caption=italic(os.path.basename(fp)),
                    parse_mode=ParseMode.HTML)
        except Exception:
            pass
    if len(files) > 10:
        zip_path = TEMP_DIR / f"bundled_{msg.message_id}.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for fp in files:
                zf.write(fp, os.path.basename(fp))
        with open(zip_path, "rb") as fh:
            await msg.reply_document(
                document=fh, filename="remaining.zip",
                caption=bi("📦  Remaining bundled"),
                parse_mode=ParseMode.HTML)
        cleanup(zip_path)
    cleanup(context.user_data.get("archive_file", ""),
            context.user_data.get("out_dir", ""))
    context.user_data.clear()
    await msg.reply_text(
        italic("Tap a menu button to continue 👇"),
        parse_mode=ParseMode.HTML,
        reply_markup=main_kb(is_admin(update.effective_user)))

# ══════════════════════════════════════════════════════
#  TEXT HANDLER
# ══════════════════════════════════════════════════════
async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    user = update.effective_user
    admin = is_admin(user)
    awaiting = context.user_data.get("awaiting")

    if text == "📦 Extract Archive":
        context.user_data.clear(); context.user_data["awaiting"] = "archive_file"
        await update.message.reply_text(
            f"{bi('📦  EXTRACT ARCHIVE')}\n{DIV}\n\n"
            f"{italic('Send any archive:')}\n"
            f"• {code('zip')}  • {code('rar')}  • {code('7z')}  • {code('tar')}",
            parse_mode=ParseMode.HTML, reply_markup=main_kb(admin)); return

    if text == "🔒 Lock File":
        context.user_data.clear(); context.user_data["awaiting"] = "lock_file"
        await update.message.reply_text(
            f"{bi('🔒  LOCK FILE')}\n{DIV}\n\n"
            f"{italic('Send me any file to encrypt.')}",
            parse_mode=ParseMode.HTML, reply_markup=main_kb(admin)); return

    if text == "📁 Build ZIP":
        for f in context.user_data.get("zip_folder_files", []):
            cleanup(f.get("path", ""))
        context.user_data.clear()
        context.user_data["awaiting"] = "zip_folder_collect"
        context.user_data["zip_folder_files"] = []
        await update.message.reply_text(
            build_folder_preview([]), parse_mode=ParseMode.HTML,
            reply_markup=zipfolder_kb()); return

    if text == "💾 My Files":
        context.user_data.clear()
        uid = user.id
        items = load_saved_index(uid)
        await update.message.reply_text(
            build_saved_view(items), parse_mode=ParseMode.HTML,
            reply_markup=saved_files_kb(items))
        context.user_data["awaiting"] = "savefiles_upload"
        return

    if text == "➕ Add Files":
        context.user_data["awaiting"] = "savefiles_upload"
        items = load_saved_index(user.id)
        await update.message.reply_text(
            f"{bi('➕  ADD FILES TO STORAGE')}\n{DIV}\n\n"
            f"{italic('Send me files to save.')}\n\n"
            f"📂  {bold('Currently stored:')} {code(str(len(items)) + ' file(s)')}",
            parse_mode=ParseMode.HTML, reply_markup=savefiles_kb()); return

    if text == "📂 View Saved":
        uid = user.id
        items = load_saved_index(uid)
        await update.message.reply_text(
            build_saved_view(items), parse_mode=ParseMode.HTML,
            reply_markup=saved_files_kb(items)); return

    if text == "🔙 Done":
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(
            italic("Exited My Files. Menu below 👇"),
            parse_mode=ParseMode.HTML, reply_markup=main_kb(admin)); return

    if text == "🖼️ Image to PDF":
        context.user_data.clear()
        context.user_data["awaiting"] = "pdf_images"
        context.user_data["pdf_images"] = []
        await update.message.reply_text(
            f"{bi('🖼️  IMAGE TO PDF')}\n{DIV}\n\n"
            f"{italic('Send images one by one.')}",
            parse_mode=ParseMode.HTML, reply_markup=pdf_kb()); return

    if text == "✅ Generate PDF":
        imgs = context.user_data.get("pdf_images", [])
        if not imgs:
            await update.message.reply_text(bold("⚠️  No images yet."),
                parse_mode=ParseMode.HTML, reply_markup=pdf_kb()); return
        pdf_path = TEMP_DIR / f"pdf_{user.id}_{update.message.message_id}.pdf"
        try:
            images_to_pdf(imgs, str(pdf_path))
            context.user_data["pending_pdf"] = str(pdf_path)
            context.user_data["awaiting"] = "pdf_filename"
            await update.message.reply_text(
                f"{bi('📄  PDF FILENAME')}\n{DIV}\n\n"
                f"{italic('Send the filename for your PDF.')}\n"
                f"{bold('Tap')} {code('/keep')} {bold('for default')} {code('converted.pdf')}",
                parse_mode=ParseMode.HTML, reply_markup=filename_kb())
        except Exception as e:
            log.exception("PDF build failed")
            await update.message.reply_text(
                f"{bold('❌  PDF failed')} {code(str(e))}",
                parse_mode=ParseMode.HTML, reply_markup=pdf_kb())
        return

    if text == "🔙 Cancel PDF":
        cleanup(*context.user_data.get("pdf_images", []))
        context.user_data.clear()
        await update.message.reply_text(italic("Cancelled."),
            parse_mode=ParseMode.HTML, reply_markup=main_kb(admin)); return

    if text == "📝 Text to File":
        context.user_data.clear()
        context.user_data["awaiting"] = "text_to_file_input"
        context.user_data["text_file_lines"] = []
        await update.message.reply_text(
            f"{bi('📝  TEXT TO FILE')}\n{DIV}\n\n"
            f"{italic('Type/paste text (multiple messages ok).')}\n"
            f"• {bold('👁️ View Lines')} — see what you have\n"
            f"• {bold('🗑️️ Delete Line')} — remove specific lines\n"
            f"• {bold('✅ Create File')} — save when done",
            parse_mode=ParseMode.HTML, reply_markup=textfile_kb()); return

    if text == "👁️ View Lines" and awaiting == "text_to_file_input":
        lines = context.user_data.get("text_file_lines", [])
        if not lines:
            await update.message.reply_text(bold("⚠️  No lines yet."),
                parse_mode=ParseMode.HTML, reply_markup=textfile_kb()); return
        show = lines[:50]
        numbered = "\n".join([f"{i+1:>3} │ {l}" for i, l in enumerate(show)])
        if len(lines) > 50: numbered += f"\n… ({len(lines) - 50} more lines)"
        if len(numbered) > MAX_PREVIEW: numbered = numbered[:MAX_PREVIEW] + "\n…"
        await update.message.reply_text(
            f"{bi('👁️  CURRENT TEXT')}\n{DIV}\n\n"
            f"📏  {bold('Total:')} {code(f'{len(lines)} lines')}\n"
            f"{DIV}\n<pre>{numbered}</pre>\n{DIV}\n"
            f"{italic('Send more, delete, or tap ✅ Create File')}",
            parse_mode=ParseMode.HTML, reply_markup=textfile_kb()); return

    if text == "🗑️ Delete Line" and awaiting == "text_to_file_input":
        lines = context.user_data.get("text_file_lines", [])
        if not lines:
            await update.message.reply_text(bold("⚠️  No lines yet."),
                parse_mode=ParseMode.HTML, reply_markup=textfile_kb()); return
        show = lines[:30]
        numbered = "\n".join([f"{i+1:>3} │ {l}" for i, l in enumerate(show)])
        if len(lines) > 30: numbered += f"\n… ({len(lines) - 30} more lines)"
        if len(numbered) > MAX_PREVIEW: numbered = numbered[:MAX_PREVIEW] + "\n…"
        context.user_data["awaiting"] = "text_delete_lines"
        await update.message.reply_text(
            f"{bi('🗑️  DELETE LINE(S)')}\n{DIV}\n\n"
            f"📏  {bold('Total:')} {code(f'{len(lines)} lines')}\n\n"
            f"<pre>{numbered}</pre>\n"
            f"{DIV}\n"
            f"{italic('Send line number(s):')}\n"
            f"• {code('3')}  • {code('3-5')}  • {code('1,3-5,8')}",
            parse_mode=ParseMode.HTML, reply_markup=textfile_kb()); return

    if text == "✅ Create File" and awaiting == "text_to_file_input":
        lines = context.user_data.get("text_file_lines", [])
        if not lines:
            await update.message.reply_text(bold("⚠️  No text received."),
                parse_mode=ParseMode.HTML, reply_markup=textfile_kb()); return
        context.user_data["text_file_content"] = "\n".join(lines)
        context.user_data["awaiting"] = "text_file_filename"
        await update.message.reply_text(
            f"{bi('📄  FILENAME')}\n{DIV}\n\n"
            f"{italic('Send a filename')} {code('(e.g. notes.txt)')}",
            parse_mode=ParseMode.HTML, reply_markup=filename_kb()); return

    if text == "🔙 Cancel":
        for f in context.user_data.get("zip_folder_files", []):
            cleanup(f.get("path", ""))
        context.user_data.clear()
        await update.message.reply_text(italic("Cancelled."),
            parse_mode=ParseMode.HTML, reply_markup=main_kb(admin)); return

    if text == "✏️ File Editor":
        context.user_data.clear(); context.user_data["awaiting"] = "editor_file_upload"
        await update.message.reply_text(
            f"{bi('✏️  FILE EDITOR')}\n{DIV}\n\n"
            f"{italic('Send a text file to edit:')}\n"
            f"{code('.txt .md .py .json .csv .log .html')} …",
            parse_mode=ParseMode.HTML, reply_markup=editor_kb()); return

    if text == "👁️ View File" and awaiting == "editor_actions":
        content = context.user_data.get("editor_content", "")
        lines = content.split("\n")
        show = lines[:50]
        numbered = "\n".join([f"{i+1:>3} │ {l}" for i, l in enumerate(show)])
        if len(lines) > 50: numbered += f"\n… ({len(lines) - 50} more lines)"
        if len(numbered) > MAX_PREVIEW: numbered = numbered[:MAX_PREVIEW] + "\n…"
        await update.message.reply_text(
            f"{bi('👁️  FILE CONTENT')}\n{DIV}\n\n"
            f"📏 {code(f'{len(lines)} lines')}  •  {code(f'{len(content)} chars')}\n"
            f"{DIV}\n<pre>{numbered}</pre>",
            parse_mode=ParseMode.HTML, reply_markup=editor_kb()); return

    if text == "✏️ Replace Content" and awaiting == "editor_actions":
        context.user_data["editor_pending_action"] = "replace"
        context.user_data["awaiting"] = "editor_new_content"
        await update.message.reply_text(
            f"{bi('✏️  REPLACE')}\n{DIV}\n\n"
            f"{italic('Send the new content.')}",
            parse_mode=ParseMode.HTML, reply_markup=editor_kb()); return

    if text == "➕ Append Text" and awaiting == "editor_actions":
        context.user_data["editor_pending_action"] = "append"
        context.user_data["awaiting"] = "editor_new_content"
        await update.message.reply_text(
            f"{bi('➕  APPEND')}\n{DIV}\n\n"
            f"{italic('Send the text to append.')}",
            parse_mode=ParseMode.HTML, reply_markup=editor_kb()); return

    if text == "🗑️ Delete Line" and awaiting == "editor_actions":
        content = context.user_data.get("editor_content", "")
        lines = content.split("\n")
        show = lines[:30]
        numbered = "\n".join([f"{i+1:>3} │ {l}" for i, l in enumerate(show)])
        if len(lines) > 30: numbered += f"\n… ({len(lines) - 30} more lines)"
        if len(numbered) > MAX_PREVIEW: numbered = numbered[:MAX_PREVIEW] + "\n…"
        context.user_data["awaiting"] = "editor_delete_lines"
        await update.message.reply_text(
            f"{bi('🗑️  DELETE LINE(S)')}\n{DIV}\n\n"
            f"📏  {bold('Total:')} {code(f'{len(lines)} lines')}\n\n"
            f"<pre>{numbered}</pre>\n"
            f"{DIV}\n"
            f"{italic('Send line number(s):')}\n"
            f"• {code('3')}  • {code('3-5')}  • {code('1,3-5,8')}",
            parse_mode=ParseMode.HTML, reply_markup=editor_kb()); return

    if text == "💾 Save & Send" and awaiting == "editor_actions":
        context.user_data["awaiting"] = "editor_filename"
        orig = context.user_data.get("editor_file_name", "edited.txt")
        await update.message.reply_text(
            f"{bi('📄  OUTPUT FILENAME')}\n{DIV}\n\n"
            f"{italic('Send filename for the edited file.')}\n"
            f"{bold('Tap')} {code('/keep')} {bold('to keep')} {code(orig)}",
            parse_mode=ParseMode.HTML, reply_markup=filename_kb()); return

    if text == "🛠️ Tools":
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(
            f"{bi('🛠️  TOOLS')}\n{DIV}\n\n"
            f"📦 Extract Archive  •  🔒 Lock File\n"
            f"📁 Build ZIP        •  💾 My Files\n"
            f"🖼️ Image to PDF    •  ✏️ File Editor\n"
            f"📝 Text to File",
            parse_mode=ParseMode.HTML, reply_markup=main_kb(admin)); return

    if text == "❓ Help":
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(
            f"{bi('❓  HELP')}\n{DIV}\n\n"
            f"• {bold('Extract')} — send archive, auto password\n"
            f"• {bold('Lock')} — send file → filename → password\n"
            f"• {bold('Build ZIP')} — collect + reorder + rename + create\n"
            f"• {bold('My Files')} — persistent personal storage\n"
            f"• {bold('PDF')} — images → Generate → filename → lock?\n"
            f"• {bold('Text to File')} — text → view/delete lines → save\n"
            f"• {bold('Editor')} — edit file → Delete / Append / Replace",
            parse_mode=ParseMode.HTML, reply_markup=main_kb(admin)); return

    if text == "📊 Status":
        context.user_data.pop("awaiting", None)
        users = load_users()
        await update.message.reply_text(
            f"{bi('📊  STATUS')}\n{DIV}\n\n"
            f"🟢 Online  |  👥 {code(str(len(users)))} users\n"
            f"🕒 {code(fmt_dt(now_local()))}",
            parse_mode=ParseMode.HTML, reply_markup=main_kb(admin)); return

    if text == "👑 Admin Panel" and admin:
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(
            f"{bi('👑  ADMIN PANEL')}\n{DIV}\n\n"
            f"{italic('Choose an action:')}",
            parse_mode=ParseMode.HTML, reply_markup=admin_panel_kb()); return

    # ── STATE INPUTS ──
    if awaiting == "zfb_rename_input":
        idx = context.user_data.get("zfb_selected")
        files = context.user_data.get("zip_folder_files", [])
        if idx is None or idx < 0 or idx >= len(files):
            context.user_data.pop("awaiting", None)
            await update.message.reply_text(bold("❌  File not found."),
                parse_mode=ParseMode.HTML, reply_markup=zipfolder_kb()); return
        new_name = safe_name(text)
        if not new_name:
            await update.message.reply_text(bold("❌  Invalid name."),
                parse_mode=ParseMode.HTML); return
        files[idx]["name"] = new_name
        context.user_data["awaiting"] = "zip_folder_collect"
        await update.message.reply_text(
            f"{bi('✅  RENAMED')}\n{DIV}\n\n"
            f"Now: {code(new_name)}",
            parse_mode=ParseMode.HTML,
            reply_markup=folder_file_kb(files, idx))
        return

    if awaiting == "text_delete_lines":
        lines = context.user_data.get("text_file_lines", [])
        to_del = parse_line_spec(text, len(lines))
        if not to_del:
            await update.message.reply_text(bold("❌  No valid line numbers."),
                parse_mode=ParseMode.HTML, reply_markup=textfile_kb()); return
        new_lines = [l for i, l in enumerate(lines, 1) if i not in to_del]
        context.user_data["text_file_lines"] = new_lines
        context.user_data["awaiting"] = "text_to_file_input"
        show = new_lines[:15]
        numbered = "\n".join([f"{i+1:>3} │ {l}" for i, l in enumerate(show)])
        if len(new_lines) > 15: numbered += f"\n… ({len(new_lines) - 15} more)"
        if not new_lines: numbered = italic("(no lines left)")
        await update.message.reply_text(
            f"{bi('✅  LINES DELETED')}\n{DIV}\n\n"
            f"🗑️  {bold('Removed:')} {code(str(len(to_del)) + ' line(s)')}\n"
            f"📏  {bold('Now:')} {code(str(len(new_lines)) + ' lines')}\n"
            f"{DIV}\n<pre>{numbered}</pre>\n{DIV}\n"
            f"{italic('Continue typing or tap ✅ Create File')}",
            parse_mode=ParseMode.HTML, reply_markup=textfile_kb()); return

    if awaiting == "lock_filename":
        orig = context.user_data.get("original_name", "file.bin")
        fname = orig if text.lower() == "/keep" else safe_name(text, Path(orig).suffix)
        if "." not in fname and Path(orig).suffix:
            fname += Path(orig).suffix
        context.user_data["output_filename"] = fname
        context.user_data["awaiting"] = "lock_password"
        await update.message.reply_text(
            f"{bi('🔐  SET PASSWORD')}\n{DIV}\n\n"
            f"Output: {code(fname)}\n\n"
            f"{italic('Send a password to encrypt this file.')}",
            parse_mode=ParseMode.HTML, reply_markup=filename_kb()); return

    if awaiting == "zip_filename":
        fname = "folder.zip" if text.lower() == "/keep" else safe_name(text, ".zip")
        if not fname.lower().endswith(".zip"): fname += ".zip"
        context.user_data["output_filename"] = fname
        context.user_data["lock_flow"] = "zip"
        context.user_data["awaiting"] = "zip_lock_choice"
        await update.message.reply_text(
            f"{bi('🔐  LOCK ZIP?')}\n{DIV}\n\n"
            f"📦  {code(fname)}\n\n"
            f"{italic('Do you want to protect the ZIP with a password?')}",
            parse_mode=ParseMode.HTML, reply_markup=lock_choice_kb()); return

    if awaiting == "pdf_filename":
        fname = "converted.pdf" if text.lower() == "/keep" else safe_name(text, ".pdf")
        if not fname.lower().endswith(".pdf"): fname += ".pdf"
        context.user_data["output_filename"] = fname
        context.user_data["awaiting"] = "pdf_lock_choice"
        await update.message.reply_text(
            f"{bi('🔐  LOCK PDF?')}\n{DIV}\n\n"
            f"📄  {bold('Filename:')} {code(fname)}\n\n"
            f"{italic('Do you want to lock this PDF?')}",
            parse_mode=ParseMode.HTML, reply_markup=pdf_lock_choice()); return

    if awaiting == "text_file_filename":
        fname = "note.txt" if text.lower() == "/keep" else safe_name(text, ".txt")
        if "." not in fname: fname += ".txt"
        context.user_data["output_filename"] = fname
        context.user_data["lock_flow"] = "text_file"
        context.user_data["awaiting"] = "text_file_lock_choice"
        await update.message.reply_text(
            f"{bi('🔐  LOCK FILE?')}\n{DIV}\n\n"
            f"📄  {code(fname)}\n\n"
            f"{italic('Protect this file with a password?')}",
            parse_mode=ParseMode.HTML, reply_markup=lock_choice_kb()); return

    if awaiting == "editor_filename":
        orig = context.user_data.get("editor_file_name", "edited.txt")
        fname = orig if text.lower() == "/keep" else safe_name(text, Path(orig).suffix)
        if "." not in fname and Path(orig).suffix:
            fname += Path(orig).suffix
        context.user_data["output_filename"] = fname
        context.user_data["lock_flow"] = "editor"
        context.user_data["awaiting"] = "editor_lock_choice"
        await update.message.reply_text(
            f"{bi('🔐  LOCK FILE?')}\n{DIV}\n\n"
            f"📄  {code(fname)}\n\n"
            f"{italic('Protect with a password?')}",
            parse_mode=ParseMode.HTML, reply_markup=lock_choice_kb()); return

    if awaiting == "text_to_file_input":
        context.user_data.setdefault("text_file_lines", []).append(text)
        n = len(context.user_data["text_file_lines"])
        await update.message.reply_text(
            f"📥 {italic(f'Line {n} added.')}",
            parse_mode=ParseMode.HTML, reply_markup=textfile_kb()); return

    if awaiting == "editor_new_content":
        action = context.user_data.get("editor_pending_action", "replace")
        if action == "replace":
            context.user_data["editor_content"] = text
        else:
            old = context.user_data.get("editor_content", "")
            context.user_data["editor_content"] = old + ("\n" if old and not old.endswith("\n") else "") + text
        context.user_data["awaiting"] = "editor_actions"
        content = context.user_data["editor_content"]
        preview = content[:MAX_PREVIEW] + ("\n…(truncated)" if len(content) > MAX_PREVIEW else "")
        await update.message.reply_text(
            f"{bi('✅  UPDATED')}\n{DIV}\n\n"
            f"📏 {code(str(len(content)) + ' chars')}  •  "
            f"{bold('Lines:')} {code(str(len(content.split(chr(10)))))}"
            f"\n{DIV}\n<pre>{preview}</pre>\n{DIV}\n"
            f"{italic('Next action 👇')}",
            parse_mode=ParseMode.HTML, reply_markup=editor_kb()); return

    if awaiting == "editor_delete_lines":
        content = context.user_data.get("editor_content", "")
        lines = content.split("\n")
        to_del = parse_line_spec(text, len(lines))
        if not to_del:
            await update.message.reply_text(bold("❌  No valid line numbers."),
                parse_mode=ParseMode.HTML, reply_markup=editor_kb()); return
        new_lines = [l for i, l in enumerate(lines, 1) if i not in to_del]
        context.user_data["editor_content"] = "\n".join(new_lines)
        context.user_data["awaiting"] = "editor_actions"
        preview = context.user_data["editor_content"][:MAX_PREVIEW]
        if len(context.user_data["editor_content"]) > MAX_PREVIEW:
            preview += "\n…(truncated)"
        await update.message.reply_text(
            f"{bi('✅  LINES DELETED')}\n{DIV}\n\n"
            f"🗑️  {bold('Removed:')} {code(str(len(to_del)) + ' line(s)')}\n"
            f"📏  {bold('Now:')} {code(str(len(new_lines)) + ' lines')}\n"
            f"{DIV}\n<pre>{preview}</pre>\n{DIV}\n"
            f"{italic('Next action 👇')}",
            parse_mode=ParseMode.HTML, reply_markup=editor_kb()); return

    if awaiting == "lock_password":
        fp = context.user_data.get("file_to_lock")
        fname = context.user_data.get("output_filename", os.path.basename(fp or "file"))
        if not fp or not os.path.exists(fp):
            await update.message.reply_text(bold("❌  File missing."),
                parse_mode=ParseMode.HTML, reply_markup=main_kb(admin))
            context.user_data.clear(); return
        await finalize_generic(update, context, fp, fname, text,
                               caption_ok="🔒  File locked successfully!"); return

    if awaiting == "pdf_lock_password":
        pdf = context.user_data.get("pending_pdf")
        fname = context.user_data.get("output_filename", "converted.pdf")
        imgs = context.user_data.get("pdf_images", [])
        if not pdf or not os.path.exists(pdf):
            await update.message.reply_text(bold("❌  PDF missing."),
                parse_mode=ParseMode.HTML, reply_markup=main_kb(admin))
            context.user_data.clear(); return
        await finalize_generic(update, context, pdf, fname, text,
                               caption_ok="🔒  PDF locked & sent!")
        cleanup(*imgs); return

    if awaiting == "text_file_password":
        await finalize_text_file(update, context, password=text); return

    if awaiting == "editor_password":
        await finalize_editor_file(update, context, password=text); return

    if awaiting == "zip_password":
        await finalize_zip(update, context, password=text); return

    if awaiting == "archive_password":
        ap = context.user_data.get("archive_file")
        od = context.user_data.get("out_dir")
        try:
            files = extract_archive(ap, text, od)
            await send_extracted(update, context, files)
        except Exception:
            await update.message.reply_text(bold("❌  Wrong password."),
                parse_mode=ParseMode.HTML)
            context.user_data.pop("awaiting", None)
        return

    if awaiting == "unlock_password":
        lp = context.user_data.get("locked_file")
        try:
            out = unlock_file(lp, text)
            with open(out, "rb") as fh:
                await update.message.reply_document(
                    document=fh, filename=os.path.basename(out),
                    caption=bi("🔓  Unlocked!"),
                    parse_mode=ParseMode.HTML)
            cleanup(lp, out); context.user_data.clear()
            await update.message.reply_text(italic("✅ Done! 👇"),
                parse_mode=ParseMode.HTML, reply_markup=main_kb(admin))
        except ValueError:
            await update.message.reply_text(bold("❌  Wrong password."),
                parse_mode=ParseMode.HTML)
        return

    if awaiting == "admin_add_input" and admin:
        a = load_admins()
        added = False
        if text.startswith("@") and len(text) > 1:
            uname = text[1:].strip()
            if uname.lower() not in [u.lower() for u in a["usernames"]]:
                a["usernames"].append(uname); added = True
                info = f"✅  Added admin: @{uname}"
            else:
                info = f"⚠️  @{uname} already admin."
        else:
            try:
                uid = int(text)
                if uid not in a["ids"]:
                    a["ids"].append(uid); added = True
                    info = f"✅  Added admin: {code(str(uid))}"
                else:
                    info = f"⚠️  ID {code(str(uid))} already admin."
            except ValueError:
                info = "❌  Invalid input."
        if added: save_admins(a)
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(
            f"{bi('👑  ADMIN PANEL')}\n{DIV}\n\n" + info,
            parse_mode=ParseMode.HTML, reply_markup=admin_panel_kb())
        return

    if awaiting == "admin_remove_input" and admin:
        a = load_admins()
        removed = False
        if text.startswith("@") and len(text) > 1:
            uname = text[1:].strip()
            before = len(a["usernames"])
            a["usernames"] = [u for u in a["usernames"] if u.lower() != uname.lower()]
            removed = len(a["usernames"]) < before
            info = f"✅  Removed @{uname}" if removed else f"⚠️  @{uname} not found."
        else:
            try:
                uid = int(text)
                before = len(a["ids"])
                a["ids"] = [i for i in a["ids"] if i != uid]
                removed = len(a["ids"]) < before
                info = f"✅  Removed ID {code(str(uid))}" if removed else "⚠️  ID not found."
            except ValueError:
                info = "❌  Invalid input."
        if removed: save_admins(a)
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(
            f"{bi('👑  ADMIN PANEL')}\n{DIV}\n\n" + info,
            parse_mode=ParseMode.HTML, reply_markup=admin_panel_kb())
        return

    await update.message.reply_text(
        italic("Please use the menu below 👇"),
        parse_mode=ParseMode.HTML, reply_markup=main_kb(admin))

# ══════════════════════════════════════════════════════
#  ERROR
# ══════════════════════════════════════════════════════
async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE):
    err = context.error
    if isinstance(err, Conflict):
        log.error("⚠️  CONFLICT — another bot instance is running the same token!")
        log.error("   Fix: kill other processes → pkill -f bot.py")
    elif isinstance(err, (NetworkError, TimedOut)):
        log.error(f"⚠️  NETWORK ERROR — cannot reach Telegram: {err}")
        log.error("   Fix: use PROXY_URL env var or move to a non-blocked host")
    else:
        log.exception("Unhandled exception", exc_info=err)

# ══════════════════════════════════════════════════════
#  POST-INIT
# ══════════════════════════════════════════════════════
async def post_init(app: Application):
    try:
        await app.bot.set_my_commands([
            BotCommand("start", "Open main menu"),
            BotCommand("id", "Show my user info"),
        ])
    except Exception as e:
        log.warning(f"set_my_commands failed: {e}")

# ══════════════════════════════════════════════════════
#  STARTUP VALIDATION
# ══════════════════════════════════════════════════════
def validate_config():
    if not BOT_TOKEN or "YOUR_BOT_TOKEN" in BOT_TOKEN or ":" not in BOT_TOKEN:
        print("\n" + "="*60)
        print("❌  BOT TOKEN MISSING OR INVALID")
        print("="*60)
        sys.exit(1)

    head, _, tail = BOT_TOKEN.partition(":")
    if not head.isdigit() or len(tail) < 30:
        print("\n" + "="*60)
        print("❌  BOT TOKEN FORMAT LOOKS WRONG")
        print("="*60)
        sys.exit(1)

# ══════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════
def main():
    validate_config()

    print("\n" + "="*60)
    print("🤖  FILE TOOLS BOT — STARTING")
    print("="*60)
    print(f"  Owner        : @{OWNER_USERNAME}")
    print(f"  Owner ID     : {OWNER_ID}")
    print(f"  Token prefix : {BOT_TOKEN[:10]}…")
    print(f"  Proxy        : {PROXY_URL or '(none)'}")
    print(f"  Timezone     : {LOCAL_TZ.tzname(None)} (UTC{now_local().strftime('%z')})")
    print(f"  Working dir  : {os.getcwd()}")
    print("="*60 + "\n")

    builder = Application.builder().token(BOT_TOKEN).post_init(post_init)
    if PROXY_URL:
        log.info(f"Using proxy: {PROXY_URL}")
        try:
            builder = builder.proxy(PROXY_URL).get_updates_proxy(PROXY_URL)
        except Exception as e:
            log.warning(f"Proxy setup failed, continuing without proxy: {e}")

    app = builder.build()

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("id", cmd_id))
    app.add_handler(CallbackQueryHandler(on_callback))
    app.add_handler(MessageHandler(filters.PHOTO | filters.Document.ALL, on_file))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    app.add_error_handler(on_error)

    max_retries = 5
    for attempt in range(1, max_retries + 1):
        try:
            print(f"▶️  Connecting to Telegram…  (attempt {attempt}/{max_retries})")
            app.run_polling(
                drop_pending_updates=True,
                allowed_updates=Update.ALL_TYPES,
            )
            print("🛑  Bot stopped cleanly.")
            break

        except InvalidToken:
            print("\n❌  INVALID TOKEN — @BotFather rejected this token\n")
            sys.exit(1)

        except (NetworkError, TimedOut) as e:
            print(f"\n⚠️  Network error on attempt {attempt}: {e}")
            if attempt < max_retries:
                wait = min(30, 5 * attempt)
                print(f"   Retrying in {wait}s…")
                time.sleep(wait)
            else:
                print("\n❌  CANNOT REACH TELEGRAM AFTER RETRIES\n")
                sys.exit(1)

        except Conflict:
            print("\n❌  CONFLICT — another instance is polling this token")
            print("   Fix: kill all other processes → pkill -f bot.py\n")
            sys.exit(1)

        except KeyboardInterrupt:
            print("\n👋  Stopped by user.")
            break

        except Exception as e:
            log.exception("Unexpected startup error")
            if attempt < max_retries:
                wait = min(30, 5 * attempt)
                print(f"\n⚠️  Unexpected error: {e}\n   Retrying in {wait}s…")
                time.sleep(wait)
            else:
                print(f"\n❌  Fatal error after {max_retries} attempts: {e}")
                sys.exit(1)

if __name__ == "__main__":
    main()
