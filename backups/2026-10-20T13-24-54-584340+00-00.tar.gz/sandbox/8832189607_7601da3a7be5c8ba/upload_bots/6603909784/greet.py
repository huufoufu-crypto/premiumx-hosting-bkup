import os
from datetime import datetime
from pathlib import Path

from telegram import Update, InputProfilePhotoStatic, ReactionTypeEmoji
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

BOT_TOKEN = os.getenv("BOT_TOKEN", " 7702976141:AAFo408nznzMWjLFA4GwQpj0gMP-7cQ-Ars").strip()
if not BOT_TOKEN:
    BOT_TOKEN = ""  # paste your NEW token here, or export BOT_TOKEN

custom_greetings = {}
DEFAULT_GREETING = (
    "Welcome! My name and avatar rotate automatically. "
    "How can I help you today?"
)
REACTION_EMOJI = "\U0001F440"  # eyes

NAMES = {
    "morning":   ["Morning Greeter", "Sunrise Bot"],
    "afternoon": ["Afternoon Helper", "Sunny Bot"],
    "evening":   ["Evening Greeter", "Twilight Bot"],
    "night":     ["Night Owl", "Sleepy Bot"],
}

AVATARS = {
    "morning":   ["avatar_morning_1.jpg"],
    "afternoon": ["avatar_afternoon_1.jpg"],
    "evening":   ["avatar_evening_1.jpg"],
    "night":     ["avatar_night_1.jpg"],
}


def get_time_slot():
    hour = datetime.now().hour
    if 5 <= hour < 12:
        return "morning"
    if 12 <= hour < 17:
        return "afternoon"
    if 17 <= hour < 21:
        return "evening"
    return "night"


def pick_name():
    slot = get_time_slot()
    options = NAMES[slot]
    return options[datetime.now().minute % len(options)]


def pick_avatar():
    slot = get_time_slot()
    options = AVATARS.get(slot, [])
    return options[datetime.now().minute % len(options)] if options else None


async def rotate_name(context: ContextTypes.DEFAULT_TYPE):
    new_name = pick_name()
    try:
        await context.bot.set_my_name(name=new_name)
        print(f"[NAME] -> {new_name}")
    except Exception as e:
        print(f"[NAME ERROR] {e}")


async def rotate_avatar(context: ContextTypes.DEFAULT_TYPE):
    avatar_file = pick_avatar()
    if not avatar_file:
        return
    path = Path(avatar_file)
    if not path.exists():
        print(f"[AVATAR SKIP] missing: {avatar_file}")
        return
    try:
        with open(path, "rb") as f:
            photo = InputProfilePhotoStatic(photo=f)
            await context.bot.set_my_profile_photo(photo=photo)
        print(f"[AVATAR] -> {avatar_file}")
    except Exception as e:
        print(f"[AVATAR ERROR] {e}")


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    name = update.effective_user.first_name or "friend"
    greeting = custom_greetings.get(user_id, DEFAULT_GREETING)
    await update.message.reply_text(f"Hello {name}! {greeting}")


async def set_greeting(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    args = context.args
    if not args:
        await update.message.reply_text(
            "Usage: /setgreeting Your custom welcome message here"
        )
        return
    text = " ".join(args)
    custom_greetings[user_id] = text
    await update.message.reply_text(f"Saved greeting: {text}")


async def reset_greeting(update: Update, context: ContextTypes.DEFAULT_TYPE):
    custom_greetings.pop(update.effective_user.id, None)
    await update.message.reply_text("Greeting reset to default.")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    user_id = update.effective_user.id
    try:
        await update.message.set_reaction(
            reaction=[ReactionTypeEmoji(emoji=REACTION_EMOJI)]
        )
    except Exception as e:
        print(f"[REACTION ERROR] {e}")
    greeting = custom_greetings.get(user_id, DEFAULT_GREETING)
    name = update.effective_user.first_name or "friend"
    await update.message.reply_text(f"Hello {name}! {greeting}")


def main():
    if not BOT_TOKEN:
        print("BOT_TOKEN is empty. Set env var or paste token in the file.")
        return

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("setgreeting", set_greeting))
    app.add_handler(CommandHandler("resetgreeting", reset_greeting))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    app.job_queue.run_repeating(rotate_name, interval=60, first=1)
    app.job_queue.run_repeating(rotate_avatar, interval=3600, first=5)

    print("Bot running.")
    app.run_polling()


if __name__ == "__main__":
    main()