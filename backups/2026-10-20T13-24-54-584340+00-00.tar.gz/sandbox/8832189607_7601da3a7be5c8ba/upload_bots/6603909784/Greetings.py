import os
import asyncio
from datetime import datetime
from pathlib import Path

from telegram import Update, InputProfilePhotoStatic, ReactionTypeEmoji
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    filters, ContextTypes,
)

# ============================================================
# 🔑 CONFIGURATION
# ============================================================
# Never paste your token here if you plan to share this file.
# Use a .env file or set an environment variable:
# BOT_TOKEN = os.getenv("BOT_TOKEN")
BOT_TOKEN = " 7702976141:AAFo408nznzMWjLFA4GwQpj0gMP-7cQ-Ars"
# --- Default Greetings (can be changed at runtime via /setgreeting) ---
# The bot will store the custom greeting in memory for this session.
# For persistence across restarts, you would need a database (e.g., SQLite).
custom_greetings = {}  # Format: {user_id: "custom text"}

DEFAULT_GREETING = "🎉 Welcome! My name and avatar rotate automatically. How can I help you today?"

# --- Emoji Reaction Configuration ---
# The bot will react to every text message with this emoji.
# Note: Telegram only allows a specific set of emojis for reactions.
# Valid examples: 👍, 👀, ❤️, 🔥, 🎉, 🤔, 👏
REACTION_EMOJI = "👀" 

# ============================================================
# Unicode Bold-Italic Mapping & Name Pools
# ============================================================
BOLD_ITALIC = {
    'a':'𝙖','b':'𝙗','c':'𝙘','d':'𝙙','e':'𝙚','f':'𝙛','g':'𝙜','h':'𝙝','i':'𝙞',
    'j':'𝙟','k':'𝙠','l':'𝙡','m':'𝙢','n':'𝙣','o':'𝙤','p':'𝙥','q':'𝙦','r':'𝙧',
    's':'𝙨','t':'𝙩','u':'𝙪','v':'𝙫','w':'𝙬','x':'𝙭','y':'𝙮','z':'𝙯',
    'A':'𝘼','B':'𝘽','C':'𝘾','D':'𝘿','E':'𝙀','F':'𝙁','G':'𝙂','H':'𝙃','I':'𝙄',
    'J':'𝙅','K':'𝙆','L':'𝙇','M':'𝙈','N':'𝙉','O':'𝙊','P':'𝙋','Q':'𝙌','R':'𝙍',
    'S':'𝙎','T':'𝙏','U':'𝙐','V':'𝙑','W':'𝙒','X':'𝙓','Y':'𝙔','Z':'𝙕',
    '0':'𝟬','1':'𝟭','2':'𝟮','3':'𝟯','4':'𝟰','5':'𝟱','6':'𝟲','7':'𝟳','8':'𝟴','9':'𝟵'
}

NAMES = {
    "morning":   ["𝐌𝐨𝐫𝐧𝐢𝐧𝐠 𝐆𝐫𝐞𝐞𝐭𝐞𝐫", "𝐒𝐮𝐧𝐫𝐢𝐬𝐞 𝐁𝐨𝐭"],
    "afternoon": ["𝐀𝐟𝐭𝐞𝐫𝐧𝐨𝐨𝐧 𝐇𝐞𝐥𝐩𝐞𝐫", "𝐒𝐮𝐧𝐧𝐲 𝐁𝐨𝐭"],
    "evening":   ["𝐄𝐯𝐞𝐧𝐢𝐧𝐠 𝐆𝐫𝐞𝐞𝐭𝐞𝐫", "𝐓𝐰𝐢𝐥𝐢𝐠𝐡𝐭 𝐁𝐨𝐭"],
    "night":     ["𝐍𝐢𝐠𝐡𝐭 𝐎𝐰𝐥", "𝐒𝐥𝐞𝐞𝐩𝐲 𝐁𝐨𝐭"],
}

AVATARS = {
    "morning":   ["avatar_morning_1.jpg"],
    "afternoon": ["avatar_afternoon_1.jpg"],
    "evening":   ["avatar_evening_1.jpg"],
    "night":     ["avatar_night_1.jpg"],
}

# ============================================================
# Helper Functions
# ============================================================
def get_time_slot():
    hour = datetime.now().hour
    if 5 <= hour < 12:    return "morning"
    if 12 <= hour < 17:   return "afternoon"
    if 17 <= hour < 21:   return "evening"
    return "night"

def pick_name():
    slot = get_time_slot()
    options = NAMES[slot]
    return options[datetime.now().minute % len(options)]

def pick_avatar():
    slot = get_time_slot()
    options = AVATARS.get(slot, [])
    return options[datetime.now().minute % len(options)] if options else None

# ============================================================
# Background Jobs (Name & Avatar Rotation)
# ============================================================
async def rotate_name(context: ContextTypes.DEFAULT_TYPE):
    new_name = pick_name()
    try:
        await context.bot.set_my_name(name=new_name)
        print(f"[NAME] → {new_name}")
    except Exception as e:
        print(f"[NAME ERROR] {e}")

async def rotate_avatar(context: ContextTypes.DEFAULT_TYPE):
    avatar_file = pick_avatar()
    if not avatar_file:
        return
    path = Path(avatar_file)
    if not path.exists():
        return
    try:
        with open(path, "rb") as f:
            photo = InputProfilePhotoStatic(photo=f)
            await context.bot.set_my_profile_photo(photo=photo)
        print(f"[AVATAR] → {avatar_file}")
    except Exception as e:
        print(f"[AVATAR ERROR] {e}")
# ============================================================
# Command: Set Custom Greeting
# ============================================================
async def set_greeting(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Usage: /setgreeting Your custom welcome message here"""
    user_id = update.effective_user.id
    args = context.args
    
    if not args:
        await update.message.reply_text(
            "❌ Please provide a greeting.\n"
            "Usage: /setgreeting Hello and welcome!",
            parse_mode="Markdown"
        )
        return
    
    greeting_text = " ".join(args)
    custom_greetings[user_id] = greeting_text
    
    await update.message.reply_text(
        f"✅ Custom greeting saved for this session:\n\n_{greeting_text}_",
        parse_mode="Markdown"
    )

# ============================================================
# Message Handler: Greeting + Emoji Reaction
# ============================================================
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return

    user_id = update.effective_user.id
    
    # 1. Send the Emoji Reaction first (fire-and-forget style)
    #    In PTB v22+, the reaction must be a list of ReactionType objects [citation:6].
    try:
        await update.message.set_reaction(
            reaction=[ReactionTypeEmoji(emoji=REACTION_EMOJI)]
        )
    except Exception as e:
        # Reactions can fail if the emoji is invalid or the chat doesn't allow it.
        # We log it but don't block the greeting.
        print(f"[REACTION ERROR] {e}")

    # 2. Send the Greeting (Custom or Default)
    greeting_to_send = custom_greetings.get(user_id, DEFAULT_GREETING)
    
    # Optional: Add the user's name to make it more personal
    user_name = update.effective_user.first_name or "friend"
    final_message = f"Hello {user_name}! {greeting_to_send}"
    
    await update.message.reply_text(final_message)

# ============================================================
# Main
# ============================================================
def main():
    if BOT_TOKEN == "PASTE_YOUR_NEW_TOKEN_HERE":
        print("❌ Set BOT_TOKEN first.")
        return

    app = Application.builder().token(BOT_TOKEN).build()

    # Commands
    app.add_handler(CommandHandler("setgreeting", set_greeting))
    
    # Message Handler (only for text, ignore commands)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Background jobs
    app.job_queue.run_repeating(rotate_name, interval=60, first=1)
    app.job_queue.run_repeating(rotate_avatar, interval=3600, first=5)

    print("🤖 Bot running. Use /setgreeting to customize, or just send a message.")
    app.run_polling()

if name == "main":
    main()