// ==================== KANHA MATRIX v5 — PURE RANDOM DELAY EDITION ====================

import makeWASocket, {
    useMultiFileAuthState,
    DisconnectReason,
    delay,
    Browsers,
    downloadMediaMessage,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    getAggregateVotesInPollMessage,
    proto,
    isJidGroup,
    jidNormalizedUser
} from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import pino from 'pino';
import fs from 'fs';
import path from 'path';
import readline from 'readline';
import gTTS from 'node-gtts';
import PQueue from 'p-queue';
import NodeCache from 'node-cache';
import ytsr from 'ytsr';
import ytdl from 'ytdl-core';
import ffmpeg from 'fluent-ffmpeg';
import { PassThrough } from 'stream';
import { execFile } from 'child_process';

// ==================== ULTRA ANTI-CRASH SYSTEM ====================
process.on('uncaughtException', (err) => {
    const ignore = [
        'ETIMEDOUT', 'ECONNRESET', 'ECONNREFUSED',
        'ENOTFOUND', 'EPIPE', 'EHOSTUNREACH',
        'EAI_AGAIN', 'ECONNABORTED', 'ERR_BAD_REQUEST',
        'ERR_BAD_RESPONSE', 'Timed Out', 'Connection Closed',
        'Require cycle', 'rate-overlimit', 'Connection lost',
        'Stream Errored', 'Unexpected server response',
        'ENOENT', 'EEXIST', 'ENOMEM',
        'ERR_SOCKET_CONNECTION_TIMEOUT',
        'ERR_HTTP2_STREAM_CANCEL',
        'CERT_HAS_EXPIRED',
        'ERR_TLS_CERT_ALTNAME_INVALID',
        'ERR_SSL_WRONG_VERSION_NUMBER',
        'Cannot read properties of undefined',
        'Cannot read properties of null',
        'is not a function',
        'is not defined',
        'PROTOCOL_CONNECTION_LOST',
        'Unexpected end of JSON input',
        'invalid json response',
        'getaddrinfo',
        'socket hang up',
        'write EPROTO',
        'read ECONNRESET',
        'miniget', 'Status code', 'ESOCKETTIMEDOUT',
        'ERR_STREAM_PREMATURE_CLOSE',
        'ERR_HTTP2_GOAWAY_SESSION',
        'ABORT_ERR'
    ];
    const errMsg = err.message || '';
    const errStr = err.toString() || '';
    for (const i of ignore) {
        if (errMsg.includes(i) || errStr.includes(i)) {
            console.log(`[ANTI-CRASH] Ignored: ${i}`);
            return;
        }
    }
    console.error('[ANTI-CRASH] Exception:', errMsg);
    console.error('[ANTI-CRASH] Stack:', err.stack);
});

process.on('unhandledRejection', (reason) => {
    const msg = reason?.message || reason?.toString() || '';
    const ignore = [
        'ETIMEDOUT', 'ECONNRESET', 'ECONNREFUSED',
        'ENOTFOUND', 'rate-overlimit', 'Connection Closed',
        'Timed Out', 'Stream Errored', 'socket hang up',
        'getaddrinfo', 'EHOSTUNREACH', 'EPIPE',
        'status code 403', 'status code 404',
        'status code 408', 'status code 429',
        'status code 500', 'status code 502',
        'status code 503', 'status code 515',
        'Cannot read properties of undefined',
        'Cannot read properties of null',
        'is not a function',
        'invalid json response',
        'Unexpected end of JSON input',
        'ECONNABORTED', 'EAI_AGAIN',
        'ERR_BAD_REQUEST', 'ERR_BAD_RESPONSE',
        'miniget', 'ESOCKETTIMEDOUT', 'Status code',
        'ERR_STREAM_PREMATURE_CLOSE',
        'ERR_HTTP2_GOAWAY_SESSION',
        'ABORT_ERR'
    ];
    for (const i of ignore) {
        if (msg.includes(i)) {
            console.log(`[ANTI-CRASH] Ignored Rejection: ${i}`);
            return;
        }
    }
    console.error('[ANTI-CRASH] Rejection:', msg);
    console.error('[ANTI-CRASH] Stack:', reason?.stack || 'No stack');
});

process.on('warning', (warning) => {
    console.warn('[WARNING]', warning.name, ':', warning.message);
});

process.on('SIGTERM', () => {
    console.log('[SYSTEM] SIGTERM received — Bot safely closing...');
});

process.on('SIGINT', () => {
    console.log('[SYSTEM] SIGINT received — Bot safely closing...');
});

process.on('exit', (code) => {
    console.log(`[SYSTEM] Process exiting with code: ${code}`);
});

process.setMaxListeners(0);

// ==================== BAILEYS 7 LOGGER ====================
const baileysLogger = pino({ level: 'silent' });

// ==================== BAILEYS 7 MESSAGE STORE ====================
const msgRetryCounterCache = new NodeCache({ stdTTL: 600, checkperiod: 120 });

// ==================== HYPERSCALE EXECUTION ENGINE (HSEE) ====================
const HSEE = {
    commandQueue: new PQueue({ concurrency: 1, interval: 0 }),
    attackQueue: new PQueue({ concurrency: 80, interval: 50, intervalCap: 80 }),
    normalQueue: new PQueue({ concurrency: 40, interval: 50, intervalCap: 40 }),
    groupCache: new NodeCache({ stdTTL: 300, checkperiod: 60 }),

    async runCommand(task) {
        try {
            return await this.commandQueue.add(task, { priority: 0 });
        } catch (e) {
            console.error('[HSEE] Command task error:', e.message);
            return null;
        }
    },

    async runAttack(task) {
        try {
            return await this.attackQueue.add(task);
        } catch (e) {
            console.error('[HSEE] Attack task error:', e.message);
            return null;
        }
    },

    async runNormal(task) {
        try {
            return await this.normalQueue.add(task);
        } catch (e) {
            console.error('[HSEE] Normal task error:', e.message);
            return null;
        }
    },

    async getGroupMeta(sock, jid, forceRefresh = false) {
        try {
            if (forceRefresh) this.groupCache.del(jid);
            let meta = this.groupCache.get(jid);
            if (meta) return meta;
            meta = await sock.groupMetadata(jid);
            this.groupCache.set(jid, meta);
            return meta;
        } catch (e) {
            console.error('[HSEE] getGroupMeta error:', e.message);
            return null;
        }
    },

    getStats() {
        return {
            commandQueue: { size: this.commandQueue.size, pending: this.commandQueue.pending },
            attackQueue: { size: this.attackQueue.size, pending: this.attackQueue.pending },
            normalQueue: { size: this.normalQueue.size, pending: this.normalQueue.pending },
            cacheStats: this.groupCache.getStats()
        };
    },

    clearAllCaches() {
        try {
            this.groupCache.flushAll();
            msgRetryCounterCache.flushAll();
            if (global.gc) global.gc();
        } catch (e) {
            console.error('[HSEE] clearAllCaches error:', e.message);
        }
    },

    clearCache(jid = null) {
        try {
            if (jid) this.groupCache.del(jid);
            else this.groupCache.flushAll();
        } catch (e) {
            console.error('[HSEE] clearCache error:', e.message);
        }
    }
};

// ==================== FILE PATHS ====================
const ROLES_FILE = './data/roles.json';
const BOTS_FILE = './data/bots.json';
const DELAYS_FILE = './data/ncDelays.json';
const PREFIX_FILE = './data/prefix.json';
const STATS_FILE = './data/stats.json';
const GCPFP_FILE = './data/gcpfp.json';
const SUPPRESS_FILE = './data/suppress.json';
const AUTOREPLY_DELAYS_FILE = './data/autoReplyDelays.json';
const ARISE_FILE = './data/arise.json';
const WORDS_FILE = './data/words.json';

// ==================== GROUP EVENT IMAGE FOLDERS ====================
const WELCOME_FOLDER = './welcome';
const LEFT_FOLDER = './left';
const KICK_FOLDER = './kick';

[WELCOME_FOLDER, LEFT_FOLDER, KICK_FOLDER].forEach(folder => {
    if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
});

// ==================== DEFAULT CONFIGURATIONS ====================
const defaultRoles = { 
    owner: null,
    admins: [],
    subAdmins: {}
};
const DEFAULT_PREFIX = '.';

const defaultDelays = {
    nc1: 5000, nc2: 5000, nc3: 5000, nc4: 5000, nc5: 5000,
    nc6: 5000, nc7: 5000, nc8: 5000, nc9: 5000, nc10: 5000,
    nc11: 5000, nc12: 5000, nc13: 5000, nc14: 5000, nc15: 5000,
    nc16: 5000, nc17: 5000, nc18: 5000, nc19: 5000, nc20: 5000,
    nc21: 5000, nc22: 5000, nc23: 5000, nc24: 5000, nc25: 5000,
    nc26: 5000, nc27: 5000, nc28: 5000, nc29: 5000, nc30: 5000,
    nc31: 5000, nc32: 5000, nc33: 5000, nc34: 5000, nc35: 5000,
    nc36: 5000, nc37: 5000, nc38: 5000, nc39: 5000, nc40: 5000,
    nc41: 5000, nc42: 5000, nc43: 5000, nc44: 5000, nc45: 5000,
    nc46: 5000, nc47: 5000, nc48: 5000, nc49: 5000, nc50: 5000,
    nc51: 5000, nc52: 5000, nc53: 5000, nc54: 5000, nc55: 5000,
    nc56: 5000, nc57: 5000, nc58: 5000, nc59: 5000, nc60: 5000,
    nc61: 5000, nc62: 5000, nc63: 5000, nc64: 5000, nc65: 5000,
    nc66: 5000, nc67: 5000, nc68: 5000, nc69: 5000, nc70: 5000,
    nc71: 5000, nc72: 5000, nc73: 5000, nc74: 5000, nc75: 5000,
    nc76: 5000, nc77: 5000, nc78: 5000, nc79: 5000, nc80: 5000,
    nc81: 5000, nc82: 5000, nc83: 5000, nc84: 5000, nc85: 5000,
    nc86: 5000, nc87: 5000, nc88: 5000, nc89: 5000, nc90: 5000,
    nc91: 5000, nc92: 5000, nc93: 5000, nc94: 5000, nc95: 5000,
    nc96: 5000, nc97: 5000, nc98: 5000, nc99: 5000, nc100: 5000,
    
    triple1: 5000, triple2: 5000, triple3: 5000, triple4: 5000, triple5: 5000,
    triple6: 5000, triple7: 5000, triple8: 5000, triple9: 5000, triple10: 5000,
    triple11: 5000, triple12: 5000, triple13: 5000, triple14: 5000, triple15: 5000,
    triple16: 5000, triple17: 5000, triple18: 5000, triple19: 5000, triple20: 5000,
    triple21: 5000, triple22: 5000, triple23: 5000, triple24: 5000, triple25: 5000,
    triple26: 5000, triple27: 5000, triple28: 5000, triple29: 5000, triple30: 5000,
    triple31: 5000, triple32: 5000, triple33: 5000, triple34: 5000, triple35: 5000,
    
    grpfp: 5000
};

const defaultAutoReplyDelays = {};

const defaultStats = {
    nc: {}, triple: {},
    slide: { running: 0, executed: 0 },
    txt: { running: 0, executed: 0 },
    tts: { running: 0, executed: 0 },
    ttsatk: { running: 0, executed: 0 },
    audio: { running: 0, executed: 0 },
    saudio: { running: 0, executed: 0 },
    video: { running: 0, executed: 0 },
    svideo: { running: 0, executed: 0 },
    pic: { running: 0, executed: 0 },
    sticker: { running: 0, executed: 0 },
    gcpfp: { running: 0, executed: 0 },
    reaction: { running: 0, executed: 0 },
    tagall: { running: 0, executed: 0 },
    kick: { running: 0, executed: 0 },
    promote: { running: 0, executed: 0 },
    demote: { running: 0, executed: 0 },
    leave: { running: 0, executed: 0 },
    attack: { running: 0, executed: 0 },
    autoreply: { running: 0, executed: 0 },
    summon: { running: 0, executed: 0 },
    arise: { running: 0, executed: 0 },
    yts: { running: 0, executed: 0 },
    fuck: { running: 0, executed: 0 },
    bully: { running: 0, executed: 0 },
    arc: { running: 0, executed: 0 },
    gcstatus: { running: 0, executed: 0 },
    rage: { running: 0, executed: 0 },
    ultimate: { running: 0, executed: 0 },
    covergc: { running: 0, executed: 0 },
    timenc: { running: 0, executed: 0 },
    ncloop: { running: 0, executed: 0 },
    heartloop: { running: 0, executed: 0 },
    usewords: { running: 0, executed: 0 },
    gifspam: { running: 0, executed: 0 },
    stickerspam: { running: 0, executed: 0 },
    vnspam: { running: 0, executed: 0 },
    target: { running: 0, executed: 0 }
};

for (let i = 1; i <= 100; i++) defaultStats.nc[`nc${i}`] = { running: 0, executed: 0 };
for (let i = 1; i <= 35; i++) defaultStats.triple[`triple${i}`] = { running: 0, executed: 0 };

// ==================== PURE RANDOM DELAY SYSTEM (NO MANUAL OVERRIDE) ====================
const RANDOM_DELAY_CONFIG = {
    nc: { min: 1000, max: 1500 },
    triple: { min: 950, max: 950 },
    txt: { min: 12000, max: 25000 },
    custxt: { min: 12000, max: 25000 },
    pcspm: { min: 1500, max: 2500 },
    stspm: { min: 1500, max: 2000 },
    desc: { min: 1500, max: 3000 },
    fstdesc: { min: 800, max: 1200 },
    gcpfp: { min: 5000, max: 9000 },
    grpfp: { min: 4000, max: 7000 },
    sync: { min: 700, max: 800 },
    fstn: { min: 700, max: 800 },
    spmgod: { min: 600, max: 950 },
    autoreact: { min: 1500, max: 4000 },
    attack: { min: 300, max: 15000 },
    covergc: { min: 5, max: 20 },
    rage: { min: 5, max: 10 },
    gifspam: { min: 300, max: 800 },
    vnspam: { min: 500, max: 1500 },
    video: { min: 800, max: 2000 },
    audio: { min: 600, max: 1800 },
    slide: { min: 500, max: 1500 },
    ttsatk: { min: 1000, max: 3000 },
    target: { min: 1000, max: 5000 },
    ncloop: { min: 50, max: 200 },
    heartloop: { min: 20, max: 100 },
    usewords: { min: 100, max: 300 },
    arc: { min: 500, max: 2000 }
};

function getRandomDelay(attackType, customRange = null) {
    if (customRange && customRange.min && customRange.max) {
        return Math.floor(Math.random() * (customRange.max - customRange.min + 1)) + customRange.min;
    }
    const config = RANDOM_DELAY_CONFIG[attackType];
    if (!config) return 5000;
    if (config.min === config.max) return config.min;
    return Math.floor(Math.random() * (config.max - config.min + 1)) + config.min;
}

// ==================== JID NORMALIZATION ====================
function normalizeJid(jid) {
    if (!jid) return '';
    try {
        if (jid.includes('@s.whatsapp.net') || jid.includes('@g.us')) {
            if (jid.includes(':')) {
                return jid.split(':')[0] + '@s.whatsapp.net';
            }
            return jid;
        }
        if (jid.includes(':')) {
            return jid.split(':')[0] + '@s.whatsapp.net';
        }
        if (!jid.includes('@')) {
            return jid + '@s.whatsapp.net';
        }
        return jid;
    } catch (e) {
        return jid;
    }
}

function jidsMatch(jid1, jid2) {
    if (!jid1 || !jid2) return false;
    return normalizeJid(jid1) === normalizeJid(jid2);
}

function extractJid(participant) {
    if (!participant) return '';
    if (typeof participant === 'string') return participant;
    if (typeof participant === 'object') {
        if (participant.id) return participant.id;
        if (participant.jid) return participant.jid;
        if (participant.userJid) return participant.userJid;
    }
    return String(participant);
}

// ==================== FONT STYLES ====================
const fontStyles = {
    double: {
        name: '𝔻𝕠𝕦𝕓𝕝𝕖 𝕊𝕥𝕣𝕚𝕜𝕖',
        map: {
            'A': '𝔸', 'B': '𝔹', 'C': 'ℂ', 'D': '𝔻', 'E': '𝔼', 'F': '𝔽', 'G': '𝔾',
            'H': 'ℍ', 'I': '𝕀', 'J': '𝕁', 'K': '𝕂', 'L': '𝕃', 'M': '𝕄', 'N': 'ℕ',
            'O': '𝕆', 'P': 'ℙ', 'Q': 'ℚ', 'R': 'ℝ', 'S': '𝕊', 'T': '𝕋', 'U': '𝕌',
            'V': '𝕍', 'W': '𝕎', 'X': '𝕏', 'Y': '𝕐', 'Z': 'ℤ',
            'a': '𝕒', 'b': '𝕓', 'c': '𝕔', 'd': '𝕕', 'e': '𝕖', 'f': '𝕗', 'g': '𝕘',
            'h': '𝕙', 'i': '𝕚', 'j': '𝕛', 'k': '𝕜', 'l': '𝕝', 'm': '𝕞', 'n': '𝕟',
            'o': '𝕠', 'p': '𝕡', 'q': '𝕢', 'r': '𝕣', 's': '𝕤', 't': '𝕥', 'u': '𝕦',
            'v': '𝕧', 'w': '𝕨', 'x': '𝕩', 'y': '𝕪', 'z': '𝕫'
        }
    },
    mono: {
        name: '𝙼𝚘𝚗𝚘𝚜𝚙𝚊𝚌𝚎',
        map: {
            'A': '𝙰', 'B': '𝙱', 'C': '𝙲', 'D': '𝙳', 'E': '𝙴', 'F': '𝙵', 'G': '𝙶',
            'H': '𝙷', 'I': '𝙸', 'J': '𝙹', 'K': '𝙺', 'L': '𝙻', 'M': '𝙼', 'N': '𝙽',
            'O': '𝙾', 'P': '𝙿', 'Q': '𝚀', 'R': '𝚁', 'S': '𝚂', 'T': '𝚃', 'U': '𝚄',
            'V': '𝚅', 'W': '𝚆', 'X': '𝚇', 'Y': '𝚈', 'Z': '𝚉',
            'a': '𝚊', 'b': '𝚋', 'c': '𝚌', 'd': '𝚍', 'e': '𝚎', 'f': '𝚏', 'g': '𝚐',
            'h': '𝚑', 'i': '𝚒', 'j': '𝚓', 'k': '𝚔', 'l': '𝚕', 'm': '𝚖', 'n': '𝚗',
            'o': '𝚘', 'p': '𝚙', 'q': '𝚚', 'r': '𝚛', 's': '𝚜', 't': '𝚝', 'u': '𝚞',
            'v': '𝚟', 'w': '𝚠', 'x': '𝚡', 'y': '𝚢', 'z': '𝚣'
        }
    },
    script: {
        name: '𝒮𝒸𝓇𝒾𝓅𝓉',
        map: {
            'A': '𝒜', 'B': 'ℬ', 'C': '𝒞', 'D': '𝒟', 'E': 'ℰ', 'F': 'ℱ', 'G': '𝒢',
            'H': 'ℋ', 'I': 'ℐ', 'J': '𝒥', 'K': '𝒦', 'L': 'ℒ', 'M': 'ℳ', 'N': '𝒩',
            'O': '𝒪', 'P': '𝒫', 'Q': '𝒬', 'R': 'ℛ', 'S': '𝒮', 'T': '𝒯', 'U': '𝒰',
            'V': '𝒱', 'W': '𝒲', 'X': '𝒳', 'Y': '𝒴', 'Z': '𝒵',
            'a': '𝒶', 'b': '𝒷', 'c': '𝒸', 'd': '𝒹', 'e': 'ℯ', 'f': '𝒻', 'g': 'ℊ',
            'h': '𝒽', 'i': '𝒾', 'j': '𝒿', 'k': '𝓀', 'l': '𝓁', 'm': '𝓂', 'n': '𝓃',
            'o': 'ℴ', 'p': '𝓅', 'q': '𝓆', 'r': '??', 's': '𝓈', 't': '𝓉', 'u': '𝓊',
            'v': '𝓋', 'w': '𝓌', 'x': '𝓍', 'y': '𝓎', 'z': '𝓏'
        }
    },
    boldscript: {
        name: '𝓑𝓸𝓵𝓭 𝓢𝓬𝓻𝓲𝓹𝓽',
        map: {
            'A': '𝓐', 'B': '𝓑', 'C': '𝓒', 'D': '𝓓', 'E': '𝓔', 'F': '𝓕', 'G': '𝓖',
            'H': '𝓗', 'I': '𝓘', 'J': '𝓙', 'K': '𝓚', 'L': '𝓛', 'M': '𝓜', 'N': '𝓝',
            'O': '𝓞', 'P': '𝓟', 'Q': '𝓠', 'R': '𝓡', 'S': '𝓢', 'T': '𝓣', 'U': '𝓤',
            'V': '𝓥', 'W': '𝓦', 'X': '𝓧', 'Y': '𝓨', 'Z': '𝓩',
            'a': '𝓪', 'b': '𝓫', 'c': '𝓬', 'd': '𝓭', 'e': '𝓮', 'f': '𝓯', 'g': '𝓰',
            'h': '𝓱', 'i': '𝓲', 'j': '𝓳', 'k': '𝓴', 'l': '𝓵', 'm': '𝓶', 'n': '𝓷',
            'o': '𝓸', 'p': '𝓹', 'q': '𝓺', 'r': '𝓻', 's': '𝓼', 't': '𝓽', 'u': '𝓾',
            'v': '𝓿', 'w': '𝔀', 'x': '𝔁', 'y': '𝔂', 'z': '𝔃'
        }
    },
    gothic: {
        name: '𝔊𝔬𝔱𝔥𝔦𝔠',
        map: {
            'A': '𝔄', 'B': '𝔅', 'C': 'ℭ', 'D': '𝔇', 'E': '𝔈', 'F': '𝔉', 'G': '𝔊',
            'H': 'ℌ', 'I': 'ℑ', 'J': '𝔍', 'K': '𝔎', 'L': '𝔏', 'M': '𝔐', 'N': '𝔑',
            'O': '𝔒', 'P': '𝔓', 'Q': '𝔔', 'R': 'ℜ', 'S': '𝔖', 'T': '𝔗', 'U': '𝔘',
            'V': '𝔙', 'W': '𝔚', 'X': '𝔛', 'Y': '𝔜', 'Z': 'ℨ',
            'a': '𝔞', 'b': '𝔟', 'c': '𝔠', 'd': '𝔡', 'e': '𝔢', 'f': '𝔣', 'g': '𝔤',
            'h': '𝔥', 'i': '𝔦', 'j': '𝔧', 'k': '𝔨', 'l': '𝔩', 'm': '𝔪', 'n': '𝔫',
            'o': '𝔬', 'p': '𝔭', 'q': '𝔮', 'r': '𝔯', 's': '𝔰', 't': '𝔱', 'u': '𝔲',
            'v': '𝔳', 'w': '𝔴', 'x': '𝔵', 'y': '𝔶', 'z': '𝔷'
        }
    },
    boldgothic: {
        name: '𝕭𝖔𝖑𝖉 𝕲𝖔𝖙𝖍𝖎𝖈',
        map: {
            'A': '𝕬', 'B': '𝕭', 'C': '𝕮', 'D': '𝕯', 'E': '𝕰', 'F': '𝕱', 'G': '𝕲',
            'H': '𝕳', 'I': '𝕴', 'J': '𝕵', 'K': '𝕶', 'L': '𝕷', 'M': '𝕸', 'N': '𝕹',
            'O': '𝕺', 'P': '𝕻', 'Q': '𝕼', 'R': '𝕽', 'S': '𝕾', 'T': '𝕿', 'U': '𝖀',
            'V': '𝖁', 'W': '𝖂', 'X': '𝖃', 'Y': '𝖄', 'Z': '𝖅',
            'a': '𝖆', 'b': '𝖇', 'c': '𝖈', 'd': '𝖉', 'e': '𝖊', 'f': '𝖋', 'g': '𝖌',
            'h': '𝖍', 'i': '𝖎', 'j': '𝖏', 'k': '𝖐', 'l': '𝖑', 'm': '𝖒', 'n': '𝖓',
            'o': '𝖔', 'p': '𝖕', 'q': '𝖖', 'r': '𝖗', 's': '𝖘', 't': '𝖙', 'u': '𝖚',
            'v': '𝖛', 'w': '𝖜', 'x': '𝖝', 'y': '𝖞', 'z': '𝖟'
        }
    },
    square: {
        name: 'Ｓｑｕａｒｅ',
        map: {
            'A': 'Ａ', 'B': 'Ｂ', 'C': 'Ｃ', 'D': 'Ｄ', 'E': 'Ｅ', 'F': 'Ｆ', 'G': 'Ｇ',
            'H': 'Ｈ', 'I': 'Ｉ', 'J': 'Ｊ', 'K': 'Ｋ', 'L': 'Ｌ', 'M': 'Ｍ', 'N': 'Ｎ',
            'O': 'Ｏ', 'P': 'Ｐ', 'Q': 'Ｑ', 'R': 'Ｒ', 'S': 'Ｓ', 'T': 'Ｔ', 'U': 'Ｕ',
            'V': 'Ｖ', 'W': 'Ｗ', 'X': 'Ｘ', 'Y': 'Ｙ', 'Z': 'Ｚ',
            'a': 'ａ', 'b': 'ｂ', 'c': 'ｃ', 'd': 'ｄ', 'e': 'ｅ', 'f': 'ｆ', 'g': 'ｇ',
            'h': 'ｈ', 'i': 'ｉ', 'j': 'ｊ', 'k': 'ｋ', 'l': 'ｌ', 'm': 'ｍ', 'n': 'ｎ',
            'o': 'ｏ', 'p': 'ｐ', 'q': 'ｑ', 'r': 'ｒ', 's': 'ｓ', 't': 'ｔ', 'u': 'ｕ',
            'v': 'ｖ', 'w': 'ｗ', 'x': 'ｘ', 'y': 'ｙ', 'z': 'ｚ'
        }
    },
    circled: {
        name: 'Ⓒⓘⓡⓒⓛⓔⓓ',
        map: {
            'A': 'Ⓐ', 'B': 'Ⓑ', 'C': 'Ⓒ', 'D': 'Ⓓ', 'E': 'Ⓔ', 'F': 'Ⓕ', 'G': 'Ⓖ',
            'H': 'Ⓗ', 'I': 'Ⓘ', 'J': 'Ⓙ', 'K': 'Ⓚ', 'L': 'Ⓛ', 'M': 'Ⓜ', 'N': 'Ⓝ',
            'O': 'Ⓞ', 'P': 'Ⓟ', 'Q': 'Ⓠ', 'R': 'Ⓡ', 'S': 'Ⓢ', 'T': 'Ⓣ', 'U': 'Ⓤ',
            'V': 'Ⓥ', 'W': 'Ⓦ', 'X': 'Ⓧ', 'Y': 'Ⓨ', 'Z': 'Ⓩ',
            'a': 'ⓐ', 'b': 'ⓑ', 'c': 'ⓒ', 'd': 'ⓓ', 'e': 'ⓔ', 'f': 'ⓕ', 'g': 'ⓖ',
            'h': 'ⓗ', 'i': 'ⓘ', 'j': 'ⓙ', 'k': 'ⓚ', 'l': 'ⓛ', 'm': 'ⓜ', 'n': 'ⓝ',
            'o': 'ⓞ', 'p': 'ⓟ', 'q': 'ⓠ', 'r': 'ⓡ', 's': 'ⓢ', 't': 'ⓣ', 'u': 'ⓤ',
            'v': 'ⓥ', 'w': 'ⓦ', 'x': 'ⓧ', 'y': 'ⓨ', 'z': 'ⓩ'
        }
    }
};

function applyFont(text, fontName) {
    const font = fontStyles[fontName];
    if (!font) return text;
    
    return text.split('').map(char => {
        if (font.map[char]) return font.map[char];
        if (font.map[char.toUpperCase()]) {
            return font.map[char.toUpperCase()];
        }
        return char;
    }).join('');
}

// ==================== 100 EMOJI ARRAYS ====================
const emojiArrays = {
    nc1: ['🤢','😩','😣','😖','😫','🥶','🫩','🤥','🤓','😇','😎','🤯'],
    nc2: ['💖','💘','💕','🩶','💞','💙','💗','🩷','❤️‍🩹','🤍','💜','💚'],
    nc3: ['🌙','🌑','🌘','🌗','🌖','🌕','🌔','🌓','🌒','🌑','🌚','🌛'],
    nc4: ['🌷','🌺','🥀','🍂','🪷','🪻','🌻','🏵️','💐','🌼','🌸','🌹'],
    nc5: ['🌩️','⭐','✨','⚜️','🌟','🪔','💫','⚡','💡','🏮','🔦','🕯️'],
    nc6: ['🏞️','🪺','❄️','🌋','💧','🪵','🪹','🪨','🌬️','🫧','🌀','🌊'],
    nc7: ['🇦🇪','🇦🇩','🇦🇪','🇦🇫','🇦🇬','🇦🇮','🇦🇱','🇦🇲','🇦🇴','🇦🇶','🇦🇷','🇦🇸'],
    nc8: ['🖋️','🖊️','🖍️','🖌️','📐','📏','✂️','🖇️','✏️','✒️','🔏','📝'],
    nc9: ['🪽','🐼','🦎','🦇','🦭','🐦‍🔥','🦘','🦆','🦑','🐚','🦜','🦢'],
    nc10: ['🟥','🟧','🟨','🟩','♂️','🟦','🟪','🟫','⬛','⬜','🔴','🟢'],
    nc11: ['💠','🔷','🔹','💠','🔷','🔹','💠','🔷','🔹','💠','🔶','🔸'],
    nc12: ['🦚','🪱','🦠','🦋','🐣','🦔','🦨','🦒','🫏','🐍','🐸','🦥'],
    nc13: ['🌀','🫧','💧','🌀','🫧','💧','🌀','🫧','💧','🌀','🌪️','💨'],
    nc14: ['🍎','🍐','🍊','🍋','🍌','🍉','🍇','🍓','🫐','🍈','🍒','🍑'],
    nc15: ['🥕','🌽','🌶️','🫑','🥒','🥦','🥬','🧄','🧅','🍄','🥜','🫘'],
    nc16: ['🍔','🍟','🍕','🌭','🥪','🌮','🌯','🥗','🥘','🍝','🍜','🍲'],
    nc17: ['☕','🍵','🧃','🥤','🧋','🍶','🍺','🍻','🥂','🍷','🥃','🍸'],
    nc18: ['⚽','🏀','🏈','⚾','🥎','🎾','🏐','🏉','🥏','🎱','🏓','🏸'],
    nc19: ['🚗','🚕','🚙','🚌','🚎','🏎️','🚓','🚑','🚒','🚐','🛻','🚚'],
    nc20: ['⌚','📱','💻','🖥️','🖨️','📷','📹','🎥','📺','📻','🎙️','🎚️'],
    nc21: ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐸','🐧','🐦'],
    nc22: ['🐔','🐤','🐣','🐥','🦆','🦅','🦉','🦇','🐺','🐗','🐴','🦄'],
    nc23: ['🐝','🐛','🦋','🐌','🐞','🐜','🦟','🦗','🕷️','🕸️','🦂','🦠'],
    nc24: ['🐟','🐠','🐡','🦈','🐙','🦑','🦐','🦞','🦀','🐳','🐋','🐬'],
    nc25: ['🐪','🐫','🦙','🦒','🐘','🦏','🦛','🐭','🐁','🐀','🐹','🐰'],
    nc26: ['🦔','🦝','🐿️','🦫','🦡','🐾','🦨','🦦','🦥','🐨','🦘','🦃'],
    nc27: ['🦜','🕊️','🦩','🦢','🦚','🦤','🦃','🐓','🐈','🐕','🦮','🐕‍🦺'],
    nc28: ['🐩','🐕','🐈‍⬛','🐈','🐆','🦌','🦬','🐃','🐂','🐄','🐎','🦓'],
    nc29: ['🦍','🦧','🐒','🦣','🐘','🦛','🦏','🐪','🐫','🦙','🦒','🐅'],
    nc30: ['🐊','🐍','🦎','🐢','🐉','🦕','🦖','🐋','🐬','🐟','🐠','🐡'],
    nc31: ['🏁','🚩','🎌','🏴','🏳️','🏳️‍🌈','🏴‍☠️','🇦🇫','🇦🇽','🇦🇱','🇩🇿','🇦🇸'],
    nc32: ['🇦🇩','🇦🇴','🇦🇮','🇦🇶','🇦🇬','🇦🇷','🇦🇲','🇦🇼','🇦🇺','🇦🇹','🇦🇿','🇧🇸'],
    nc33: ['🇧🇭','🇧🇩','🇧🇧','🇧🇾','🇧🇪','🇧🇿','🇧🇯','🇧🇲','🇧🇹','🇧🇴','🇧🇦','🇧🇼'],
    nc34: ['🇧🇷','🇻🇬','🇧🇳','🇧🇬','🇧🇫','🇧🇮','🇰🇭','🇨🇲','🇨🇦','🇮🇨','🇨🇻','🇧🇶'],
    nc35: ['🇰🇾','🇨🇫','🇹🇩','🇨🇱','🇨🇳','🇨🇽','🇨🇨','🇨🇴','🇰🇲','🇨🇬','🇨🇩','🇨🇰'],
    nc36: ['🇨🇷','🇨🇮','🇭🇷','🇨🇺','🇨🇼','🇨🇾','🇨🇿','🇩🇰','🇩🇯','🇩🇲','🇩🇴','🇪🇨'],
    nc37: ['🇪🇬','🇸🇻','🇬🇶','🇪🇷','🇪🇪','🇪🇹','🇪🇺','🇫🇰','🇫🇴','🇫🇯','🇫🇮','🇫🇷'],
    nc38: ['🇬🇫','🇵🇫','🇹🇫','🇬🇦','🇬🇲','🇬🇪','🇩🇪','🇬🇭','🇬🇮','🇬🇷','🇬🇱','🇬🇩'],
    nc39: ['🇬🇵','🇬🇺','🇬🇹','🇬🇬','🇬🇳','🇬🇼','🇬🇾','🇭🇹','🇭🇳','🇭🇰','🇭🇺','🇮🇸'],
    nc40: ['🇮🇳','🇮🇩','🇮🇷','🇮🇶','🇮🇪','🇮🇲','🇮🇱','🇮🇹','🇯🇲','🇯🇵','🇯🇪','🇯🇴'],
    nc41: ['⚽','🏀','🏈','⚾','🥎','🎾','🏐','🏉','🥏','🎱','🏓','🏸'],
    nc42: ['🏒','🏑','🏏','🥍','🏹','🎣','🥊','🥋','⛸️','🛷','⛷️','🏂'],
    nc43: ['🏋️','🤸','🤼','🤽','🤾','🤺','🏌️','🏇','🧘','🏄','🚣','🏊'],
    nc44: ['🚴','🚵','🎯','🎳','🎰','🎲','♠️','♥️','♦️','♣️','🃏','🀄'],
    nc45: ['🎴','🎭','🎨','🎪','🎤','🎧','🎼','🎹','🥁','🎷','🎺','🎸'],
    nc46: ['🎻','🪕','🎬','🎮','👾','🎯','🎲','🧩','♟️','🎖️','🏆','🏅'],
    nc47: ['🥇','🥈','🥉','⚽','🏀','🏈','⚾','🎾','🏐','🏉','🎱','🏓'],
    nc48: ['🏸','🥍','🏑','🏒','🏏','⛳','🥌','🎣','🤿','🥊','🥋','🎽'],
    nc49: ['🛹','🛼','🛸','🤹','🧗','🧭','🧱','🪢','🧶','🧵','🪡','🪤'],
    nc50: ['🪣','🪥','🪦','🪫','🔋','💡','🔦','🪔','🕯️','🪩','🪆','🎎'],
    nc51: ['🍏','🍎','🍐','🍊','🍋','🍌','🍉','🍇','🍓','🫐','🍈','🍒'],
    nc52: ['🍑','🥭','🍍','🥥','🥝','🍅','🍆','🥑','🥦','🥬','🥒','🌶️'],
    nc53: ['🫑','🌽','🥕','🧄','🧅','🥔','🍠','🥐','🥯','🍞','🥖','🥨'],
    nc54: ['🧀','🥚','🍳','🧈','🥞','🧇','🥓','🥩','🍗','🍖','🦴','🌭'],
    nc55: ['🍔','🍟','🍕','🥪','🥙','🧆','🌮','🌯','🥗','🥘','🫔','🍝'],
    nc56: ['🍜','🍲','🍛','🍣','🍱','🥟','🦪','🍤','🍙','🍚','🍘','🍥'],
    nc57: ['🥠','🥮','🍡','🍢','🍧','🍨','🍦','🥧','🧁','🍰','🎂','🍮'],
    nc58: ['🍭','🍬','🍫','🍿','🍩','🍪','🌰','🥜','🫘','🍯','🥛','🧃'],
    nc59: ['🧋','🧉','🍵','🍶','🍾','🍷','🍸','🍹','🍺','🍻','🥂','🥃'],
    nc60: ['🧊','🥤','🧂','🥄','🍴','🥢','🍽️','🔪','🏺','🎀','🎁','💝'],
    nc61: ['🌲','🌳','🌴','🌵','🌾','🌿','☘️','🍀','🍁','🍂','🍃','🪹'],
    nc62: ['🪺','🍄','🌰','🦀','🦞','🦐','🦑','🐚','🪸','🐠','🐟','🐡'],
    nc63: ['🐬','🐳','🐋','🦈','🐊','🐅','🐆','🦓','🦍','🦧','🦣','🐘'],
    nc64: ['🦛','🦏','🐪','🐫','🦒','🦘','🦬','🐃','🐂','🐄','🐎','🐖'],
    nc65: ['🐏','🐑','🦙','🐐','🦌','🐕','🐩','🐈','🐓','🦃','🦤','🦚'],
    nc66: ['🦜','🦢','🦩','🕊️','🐇','🦝','🦨','🦡','🦫','🦦','🦥','🐿️'],
    nc67: ['🐀','🐁','🐭','🐹','🐰','🦊','🐻','🐻‍❄️','🐨','🐼','🐸','🐒'],
    nc68: ['🦎','🐍','🐢','🐉','🦕','🦖','🐙','🦑','🦐','🦞','🦀','🐡'],
    nc69: ['🐠','🐟','🐬','🐳','🐋','🦈','🐊','🐅','🐆','🦓','🦍','🦧'],
    nc70: ['🌋','🗻','🏔️','⛰️','🏕️','🏖️','🏜️','🏝️','🏞️','🏟️','🏛️','🏗️'],
    nc71: ['⌚','📱','💻','🖥️','🖨️','📷','📹','🎥','📺','📻','🎙️','🎚️'],
    nc72: ['🎛️','🧭','⏱️','⏲️','⏰','🕰️','⌛','⏳','📡','🔋','🪫','💡'],
    nc73: ['🔦','🪔','🕯️','🪩','🪆','🎎','🎐','🎑','🧧','🎀','🎁','🎗️'],
    nc74: ['🎟️','🎫','🎖️','🏆','🏅','🥇','🥈','🥉','⚽','🏀','🏈','⚾'],
    nc75: ['🥎','🎾','🏐','🏉','🥏','🎱','🏓','🏸','🏒','🏑','🏏','🥍'],
    nc76: ['🏹','🎣','🤿','🥊','🥋','🎽','🛹','🛼','🛷','⛸️','🥌','🎿'],
    nc77: ['⛷️','🏂','🏋️','🤸','🤼','🤽','🤾','🤺','🏌️','🏇','🧘','🏄'],
    nc78: ['🚣','🏊','⛹️','🏋️','🚴','🚵','🏎️','🏍️','🛵','🛺','🚲','🛴'],
    nc79: ['🚀','🛸','🛰️','🪐','🌠','🌌','🌃','🏙️','🌇','🌅','🌄','🌈'],
    nc80: ['☁️','⛅','⛈️','🌤️','🌥️','🌦️','🌧️','🌨️','🌩️','🌪️','🌫️','🌬️'],
    nc81: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❤️‍🔥','❤️‍🩹'],
    nc82: ['💕','💞','💓','💗','💖','💘','💝','💟','☮️','✝️','☪️','🕉️'],
    nc83: ['☸️','✡️','🔯','🕎','☯️','☦️','🛐','⛎','♈','♉','♊','♋'],
    nc84: ['♌','♍','♎','♏','♐','♑','♒','♓','🆔','⚛️','🉑','☢️'],
    nc85: ['☣️','📴','📳','🈶','🈚','🈸','🈺','🈷️','✴️','🆚','💮','🉐'],
    nc86: ['㊙️','㊗️','🈴','🈵','🈹','🈲','🅰️','🅱️','🆎','🆑','🅾️','🆘'],
    nc87: ['🆚','🈁','🈂️','🚻','🚹','🚺','🚼','🚾','⚠️','🚸','⛔','🚫'],
    nc88: ['🚳','🚭','🚯','🚱','🚷','📵','🔞','☢️','☣️','⬆️','↗️','➡️'],
    nc89: ['↘️','⬇️','↙️','⬅️','↖️','↕️','↔️','↩️','↪️','⤴️','⤵️','🔃'],
    nc90: ['🔄','🔙','🔚','🔛','🔜','🔝','🛐','⚛️','🕉️','✡️','☸️','☯️'],
    nc91: ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','🙃','🫠','😉'],
    nc92: ['😊','😇','🥰','😍','🤩','😘','😗','☺️','😚','😙','🥲','😋'],
    nc93: ['😛','😜','🤪','😝','🤑','🤗','🤭','🫢','🫣','🤫','🤔','🪄'],
    nc94: ['😐','😑','😶','🫥','😏','😒','🙄','😬','🤥','😌','😔','😪'],
    nc95: ['🤤','😴','💤','😷','🤒','🤕','🤢','🤮','🤧','🥵','🥶','🥴'],
    nc96: ['😵','🤯','🤠','🥳','🥸','😎','🤓','🧐','😕','🫤','😟','🙁'],
    nc97: ['☹️','😮','😯','😲','😳','🥺','🥹','😦','😧','😨','😰','😥'],
    nc98: ['😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡'],
    nc99: ['😠','🤬','😈','👿','💀','☠️','💩','🤡','👹','👺','👻','👽'],
    nc100: ['👾','🤖','🎃','😺','😸','😹','😻','😼','😽','🙀','😿','😾']
};

// ==================== TRIPLE NC COMBOS ====================
const tripleNcCombos = {
    triple1: ['nc1', 'nc2', 'nc3'],
    triple2: ['nc4', 'nc5', 'nc6'],
    triple3: ['nc7', 'nc8', 'nc9'],
    triple4: ['nc10', 'nc11', 'nc12'],
    triple5: ['nc13', 'nc14', 'nc15'],
    triple6: ['nc16', 'nc17', 'nc18'],
    triple7: ['nc19', 'nc20', 'nc21'],
    triple8: ['nc22', 'nc23', 'nc24'],
    triple9: ['nc25', 'nc26', 'nc27'],
    triple10: ['nc28', 'nc29', 'nc30'],
    triple11: ['nc31', 'nc32', 'nc33'],
    triple12: ['nc34', 'nc35', 'nc36'],
    triple13: ['nc37', 'nc38', 'nc39'],
    triple14: ['nc40', 'nc41', 'nc42'],
    triple15: ['nc43', 'nc44', 'nc45'],
    triple16: ['nc46', 'nc47', 'nc48'],
    triple17: ['nc49', 'nc50', 'nc51'],
    triple18: ['nc52', 'nc53', 'nc54'],
    triple19: ['nc55', 'nc56', 'nc57'],
    triple20: ['nc58', 'nc59', 'nc60'],
    triple21: ['nc61', 'nc62', 'nc63'],
    triple22: ['nc64', 'nc65', 'nc66'],
    triple23: ['nc67', 'nc68', 'nc69'],
    triple24: ['nc70', 'nc71', 'nc72'],
    triple25: ['nc73', 'nc74', 'nc75'],
    triple26: ['nc76', 'nc77', 'nc78'],
    triple27: ['nc79', 'nc80', 'nc81'],
    triple28: ['nc82', 'nc83', 'nc84'],
    triple29: ['nc85', 'nc86', 'nc87'],
    triple30: ['nc88', 'nc89', 'nc90'],
    triple31: ['nc91', 'nc92', 'nc93'],
    triple32: ['nc94', 'nc95', 'nc96'],
    triple33: ['nc97', 'nc98', 'nc99'],
    triple34: ['nc100', 'nc1', 'nc2'],
    triple35: ['nc3', 'nc4', 'nc5']
};

// ==================== ARC TEMPLATES ====================
const ARC_TEMPLATE_1 = `KANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤯༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤯༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤯༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤯༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤯༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤯༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤯༻𓆪 ⎠꧂

KANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤤༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤤༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤤༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤤༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤤༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤤༻𓆪 ⎠꧂ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤKANHA ᴛᴇʀɪ ᴍᴀᴀ ᴄʜᴜᴅɴᴇ ᴋᴇ ʙᴀᴀᴅ ᴛᴇʀɪ ᴍᴀᴀ ᴋᴀ ʀᴇᴀᴄᴛɪᴏɴ ꧁⎝ 𓆩༺🤤༻𓆪 ⎠꧂`;

const ARC_TEMPLATE_2 = `KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (💎)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🎗️)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🎐)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (💗)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🔥)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (⛓️‍💥)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🕷️)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🌬️)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🎯)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (💫)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🤣)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🛑)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🃏)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (💋)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (♦️)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🔱)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🎀)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🫧)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🌈)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (💎)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🪐)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (👑)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🌐)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (😈)
KANHA Cʜɪꪀꫝʟ Pⁱꪶꪶꫝ -/- ¿ (🥶)`;

const ARC_TEMPLATE_3 = `⚚𓂃 𓈒𓏸  🩸⃟⃝ <KANHA>  > 🌘> > 𝙃𝙀𝙇𝙋𝙀𝙍𝙎 TATTO 𝘒𝘐 𝘔𝘈𝘈 𝘏𝘈𝘔𝘌𝘚𝘏𝘈 𓆩𝐄ɴ𝐈ɢ𝐌ᴀ𓆩⃟🔱𓆪🇦🇱(👑) 𝑆𝐸 𝐻𝐼 चूदती है𓆩♡𓆪୧⍤⃝⚡ ㅤㅤㅤㅤㅤㅤㅤㅤ

⚚𓂃 𓈒𓏸  🩸⃟⃝ KANHA 🌘> > 𝙃𝙀𝙇𝙋𝙀𝙋𝙀𝙍𝙎 TATTO 𝐾𝐼 𝑀𝐴 𝐾𝐼 𝐶𝐻𝑈𝑇 𝑀𝐸 𓆩𝐄ɴ𝐈ɢ𝐌ᴀ𓆩⃟🔱𓆪🇦🇱(👑) 𝑃𝐴𝑃𝐴 𝐾𝐴 𝐿𝑈𝑁𝐷 𝐸𝑊𝑊 𓆩♡𓆪୧⍤⃝⚡ ▄︻デ۪۞━一💥⌖🩸`;

// ==================== CONSTANT WORDS ====================
const CONSTANT_WORDS = [
    '(𓀐𓂸)- ​🇸​​🇵​​🇮​​🇩​​🇾​',
    '🚀 sᴘɪᴅʏ ᴄʜᴜᴛ🚀', 
    '𝗦𝗣𝗜𝗗𝗬 𝗪𝗔𝗟𝗘🥀',
    'ɱ~ų~ɬ~ɦ sᴘɪᴅʏ 𝐊i🦐',
    '◤KANHA OP◥✕🚬🍸',
    '(🜏)- ​🇸​​🇵​​🇮​​🇩​​🇾',
    '🍌 sᴘɪᴅʏ ᴄʜᴜᴛ🍌',
    '𝗦𝗣𝗜𝗗𝗬 𝗞𝗢 𝗕𝗛𝗨𝗟 𝗠𝗔𝗧 🥀',
    '◤KANHA POWER◥✕🚬🍸',
    'KANHA BOT 🥶',
    '(𖤐)- ​🇸​​🇵​​🇮​​🇩​​🇾​',
    '♨️ sᴘɪᴅʏ ᴄʜᴜᴛ♨️',
    '𝗦𝗣𝗜𝗗𝗬 𝗟𝗔 🤙🏿',
    '🕷️ KANHA KING 👑',
    '🔥 KANHA ATTACK 🔥',
    '💀 KANHA MODE 💀',
    '⚡ KANHA SPEED ⚡',
    '💫 KANHA POWER 💫',
    '👑 KANHA OWNER 👑',
    '🤖 KANHA BOT 🤖',
    '🎯 KANHA TARGET 🎯',
    '💥 KANHA ULTIMATE 💥'
];

// ==================== SAFE FILE OPERATIONS ====================
function safeReadJSON(filePath, defaultValue) {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
    } catch (err) {
        console.error(`[FILE] Error reading ${filePath}:`, err.message);
    }
    return defaultValue;
}

function safeWriteJSON(filePath, data) {
    try {
        if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        return true;
    } catch (err) {
        console.error(`[FILE] Error writing ${filePath}:`, err.message);
        return false;
    }
}

// ==================== LOAD/SAVE HELPERS ====================
function loadRoles() { return { ...defaultRoles, ...safeReadJSON(ROLES_FILE, defaultRoles) }; }
function saveRoles(r) { safeWriteJSON(ROLES_FILE, r); }
function loadDelays() { return { ...defaultDelays, ...safeReadJSON(DELAYS_FILE, defaultDelays) }; }
function saveDelays(d) { safeWriteJSON(DELAYS_FILE, d); }
function loadPrefix() {
    const d = safeReadJSON(PREFIX_FILE, { prefix: DEFAULT_PREFIX });
    return d.prefix || DEFAULT_PREFIX;
}
function savePrefix(p) { safeWriteJSON(PREFIX_FILE, { prefix: p }); }
function loadStats() {
    const loaded = safeReadJSON(STATS_FILE, defaultStats);
    return { ...JSON.parse(JSON.stringify(defaultStats)), ...loaded };
}
function saveStats(s) { safeWriteJSON(STATS_FILE, s); }
function loadGcPfpData() { return safeReadJSON(GCPFP_FILE, {}); }
function saveGcPfpData(d) { safeWriteJSON(GCPFP_FILE, d); }
function loadSuppressedBots() { return new Set(safeReadJSON(SUPPRESS_FILE, [])); }
function saveSuppressedBots(s) { safeWriteJSON(SUPPRESS_FILE, [...s]); }
function loadAutoReplyDelays() { return safeReadJSON(AUTOREPLY_DELAYS_FILE, defaultAutoReplyDelays); }
function saveAutoReplyDelays(d) { safeWriteJSON(AUTOREPLY_DELAYS_FILE, d); }
function loadAriseData() { return safeReadJSON(ARISE_FILE, {}); }
function saveAriseData(d) { safeWriteJSON(ARISE_FILE, d); }
function loadWords() { return safeReadJSON(WORDS_FILE, []); }
function saveWords(w) { safeWriteJSON(WORDS_FILE, w); }

// ==================== GLOBAL DATA ====================
let roles = loadRoles();
let ncDelays = loadDelays();
let currentPrefix = loadPrefix();
let attackStats = loadStats();
let gcPfpCollections = loadGcPfpData();
let suppressedBots = loadSuppressedBots();
let autoReplyDelays = loadAutoReplyDelays();
let ariseData = loadAriseData();
let savedWords = loadWords();
let botNumber = '';

// ==================== ACTIVE FUCK TASKS ====================
const activeFuckTasks = new Map();

// ==================== BULLY TARGETS ====================
const activeBullyTargets = new Map();

// ==================== ARC STATE ====================
const arcState = new Map();

// ==================== PERMISSION SYSTEM (STRICT) ====================
function isOwner(jid) {
    if (!jid) return false;
    const normalized = normalizeJid(jid);
    return roles.owner === normalized;
}

function isAdmin(jid) {
    if (!jid) return false;
    const normalized = normalizeJid(jid);
    if (normalized === normalizeJid(botNumber)) return true;
    return roles.admins.some(a => normalizeJid(a) === normalized);
}

function isSubAdmin(jid, groupJid) {
    if (!jid || !groupJid) return false;
    const normalized = normalizeJid(jid);
    const normalizedGroup = normalizeJid(groupJid);
    return roles.subAdmins[normalizedGroup]?.some(s => normalizeJid(s) === normalized) || false;
}

function hasPermission(jid, groupJid = null) {
    if (!jid) return false;
    if (isOwner(jid)) return true;
    if (isAdmin(jid)) return true;
    if (groupJid && isSubAdmin(jid, groupJid)) return true;
    if (normalizeJid(jid) === normalizeJid(botNumber)) return true;
    return false;
}

function setOwner(jid) {
    const normalized = normalizeJid(jid);
    if (!roles.owner) {
        roles.owner = normalized;
        saveRoles(roles);
        console.log(`[OWNER] Set owner: ${normalized}`);
        return true;
    }
    return false;
}

function removeOwner() {
    roles.owner = null;
    saveRoles(roles);
    console.log(`[OWNER] Removed owner`);
    return true;
}

function addAdmin(jid) {
    const normalized = normalizeJid(jid);
    if (roles.admins.some(a => normalizeJid(a) === normalized)) return false;
    if (roles.admins.length >= 2) return false;
    roles.admins.push(normalized);
    saveRoles(roles);
    console.log(`[ADMIN] Added: ${normalized}`);
    return true;
}

function removeAdmin(jid) {
    const normalized = normalizeJid(jid);
    const idx = roles.admins.findIndex(a => normalizeJid(a) === normalized);
    if (idx > -1) {
        roles.admins.splice(idx, 1);
        if (ariseData[normalized]) {
            delete ariseData[normalized];
            saveAriseData(ariseData);
        }
        saveRoles(roles);
        return true;
    }
    return false;
}

function addSubAdmin(jid, groupJid) {
    const normalized = normalizeJid(jid);
    const normalizedGroup = normalizeJid(groupJid);
    if (!roles.subAdmins[normalizedGroup]) {
        roles.subAdmins[normalizedGroup] = [];
    }
    if (!roles.subAdmins[normalizedGroup].some(s => normalizeJid(s) === normalized)) {
        roles.subAdmins[normalizedGroup].push(normalized);
        saveRoles(roles);
        return true;
    }
    return false;
}

function removeSubAdmin(jid, groupJid) {
    const normalized = normalizeJid(jid);
    const normalizedGroup = normalizeJid(groupJid);
    if (roles.subAdmins[normalizedGroup]) {
        const idx = roles.subAdmins[normalizedGroup].findIndex(s => normalizeJid(s) === normalized);
        if (idx > -1) {
            roles.subAdmins[normalizedGroup].splice(idx, 1);
            saveRoles(roles);
            return true;
        }
    }
    return false;
}

// ==================== STATS UPDATE ====================
let statsDebounce = null;
function updateStats(type, subType = null, action = 'execute') {
    try {
        if (subType) {
            if (!attackStats[type]) attackStats[type] = {};
            if (!attackStats[type][subType]) attackStats[type][subType] = { running: 0, executed: 0 };
            if (action === 'start') attackStats[type][subType].running++;
            else if (action === 'stop') attackStats[type][subType].running = Math.max(0, attackStats[type][subType].running - 1);
            else if (action === 'execute') attackStats[type][subType].executed++;
        } else {
            if (!attackStats[type]) attackStats[type] = { running: 0, executed: 0 };
            if (action === 'start') attackStats[type].running++;
            else if (action === 'stop') attackStats[type].running = Math.max(0, attackStats[type].running - 1);
            else if (action === 'execute') attackStats[type].executed++;
        }
        if (statsDebounce) clearTimeout(statsDebounce);
        statsDebounce = setTimeout(() => saveStats(attackStats), 5000);
    } catch (e) {
        console.error('[STATS] Update error:', e.message);
    }
}

// ==================== TTS FUNCTION ====================
async function generateTTS(text, lang = 'en-uk') {
    return new Promise((resolve, reject) => {
        try {
            const tts = gTTS(lang);
            const chunks = [];
            const stream = tts.stream(text);
            stream.on('data', chunk => chunks.push(chunk));
            stream.on('end', () => resolve(Buffer.concat(chunks)));
            stream.on('error', () => {
                try {
                    const tts2 = gTTS('en-au');
                    const chunks2 = [];
                    const stream2 = tts2.stream(text);
                    stream2.on('data', chunk => chunks2.push(chunk));
                    stream2.on('end', () => resolve(Buffer.concat(chunks2)));
                    stream2.on('error', () => {
                        const tts3 = gTTS('en');
                        const chunks3 = [];
                        const stream3 = tts3.stream(text);
                        stream3.on('data', chunk => chunks3.push(chunk));
                        stream3.on('end', () => resolve(Buffer.concat(chunks3)));
                        stream3.on('error', reject);
                    });
                } catch (e2) {
                    reject(e2);
                }
            });
        } catch (err) {
            reject(err);
        }
    });
}

// ==================== WEBP TO MP4 CONVERSION ====================
async function webpToMp4(webpBuffer) {
    const tempDir = './temp';
    const id = `${process.pid}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const inputPath = path.join(tempDir, `sticker_${id}.webp`);
    const outputPath = path.join(tempDir, `sticker_${id}.mp4`);

    await fs.promises.mkdir(tempDir, { recursive: true });
    await fs.promises.writeFile(inputPath, webpBuffer);

    try {
        await new Promise((resolve, reject) => {
            execFile(
                'ffmpeg',
                [
                    '-i', inputPath,
                    '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
                    '-c:v', 'libx264',
                    '-preset', 'ultrafast',
                    '-t', '1',
                    '-y', outputPath
                ],
                (error) => error ? reject(error) : resolve()
            );
        });

        return await fs.promises.readFile(outputPath);
    } finally {
        await Promise.all(
            [inputPath, outputPath].map(file =>
                fs.promises.unlink(file).catch(() => {})
            )
        );
    }
}

// ==================== YOUTUBE DOWNLOAD FUNCTIONS ====================
async function searchYouTube(query) {
    try {
        try {
            const results = await ytsr(query, { limit: 10 });
            const videos = results.items.filter(i => i.type === 'video').slice(0, 5);
            if (videos.length > 0) return videos;
        } catch (e1) {
            console.error('[YTS] Direct search failed:', e1.message);
        }

        try {
            const filters = await ytsr.getFilters(query);
            const videoFilter = filters.get('Type');
            if (videoFilter) {
                const videoType = videoFilter.get('Video');
                if (videoType && videoType.url) {
                    const results = await ytsr(videoType.url, { limit: 5 });
                    const videos = results.items.filter(i => i.type === 'video').slice(0, 5);
                    if (videos.length > 0) return videos;
                }
            }
        } catch (e2) {
            console.error('[YTS] Filter search failed:', e2.message);
        }

        try {
            const searchQuery = query.replace(/[^a-zA-Z0-9\s]/g, '').trim();
            if (searchQuery) {
                const results = await ytsr(searchQuery + ' music video', { limit: 10 });
                const videos = results.items.filter(i => i.type === 'video').slice(0, 5);
                if (videos.length > 0) return videos;
            }
        } catch (e3) {
            console.error('[YTS] Simplified search failed:', e3.message);
        }

        return [];
    } catch (e) {
        console.error('[YTS] Search error:', e.message);
        return [];
    }
}

async function downloadYTAudio(url) {
    return new Promise((resolve, reject) => {
        try {
            const chunks = [];
            const stream = ytdl(url, {
                filter: 'audioonly',
                quality: 'highestaudio',
                requestOptions: {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    }
                }
            });
            const passThrough = new PassThrough();
            ffmpeg(stream)
                .audioBitrate(128)
                .format('mp3')
                .on('error', (err) => reject(err))
                .pipe(passThrough);
            passThrough.on('data', chunk => chunks.push(chunk));
            passThrough.on('end', () => resolve(Buffer.concat(chunks)));
            passThrough.on('error', reject);
        } catch (e) {
            reject(e);
        }
    });
}

async function downloadYTVideo(url, quality = '480p') {
    return new Promise((resolve, reject) => {
        try {
            const chunks = [];
            const reqOptions = {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                }
            };
            const videoStream = ytdl(url, {
                quality: quality === 'highest' ? 'highestvideo' : '18',
                filter: quality === 'highest' ? undefined : 'audioandvideo',
                requestOptions: reqOptions
            });
            if (quality === 'highest') {
                const audioStream = ytdl(url, { quality: 'highestaudio', requestOptions: reqOptions });
                const passThrough = new PassThrough();
                ffmpeg()
                    .input(videoStream)
                    .input(audioStream)
                    .outputOptions(['-c:v copy', '-c:a aac', '-movflags +faststart'])
                    .format('mp4')
                    .on('error', reject)
                    .pipe(passThrough);
                passThrough.on('data', chunk => chunks.push(chunk));
                passThrough.on('end', () => resolve(Buffer.concat(chunks)));
                passThrough.on('error', reject);
            } else {
                videoStream.on('data', chunk => chunks.push(chunk));
                videoStream.on('end', () => resolve(Buffer.concat(chunks)));
                videoStream.on('error', reject);
            }
        } catch (e) {
            reject(e);
        }
    });
}

// ==================== UTILITY FUNCTIONS ====================
function parseAttackChoices(input) {
    const cleaned = input.replace(/[&,]+/g, ' ').trim();
    const parts = cleaned.split(/\s+/);
    const choices = [];
    let randomMode = false;
    for (const part of parts) {
        if (part.toLowerCase() === 'random') {
            randomMode = true;
            continue;
        }
        const num = parseInt(part);
        if (!isNaN(num) && num >= 1 && num <= 5 && !choices.includes(num)) {
            choices.push(num);
        }
    }
    return { choices: choices.sort((a, b) => a - b), randomMode };
}

function parseCommaSeparatedNumbers(input) {
    const numbers = [];
    const parts = input.split(',');
    for (const part of parts) {
        const num = parseInt(part.trim());
        if (!isNaN(num) && num > 0) numbers.push(num);
    }
    return numbers;
}

function getMentionedUsers(msg) {
    try {
        const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
        if (contextInfo?.mentionedJid) return contextInfo.mentionedJid;
        return [];
    } catch (e) {
        return [];
    }
}

function getUptime() {
    const uptime = process.uptime();
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    let result = '';
    if (days > 0) result += `${days}d `;
    if (hours > 0) result += `${hours}h `;
    if (minutes > 0) result += `${minutes}m `;
    result += `${seconds}s`;
    return result.trim();
}

function getMemoryUsage() {
    const mem = process.memoryUsage();
    return {
        rss: (mem.rss / 1024 / 1024).toFixed(1),
        heapUsed: (mem.heapUsed / 1024 / 1024).toFixed(1),
        heapTotal: (mem.heapTotal / 1024 / 1024).toFixed(1),
        external: (mem.external / 1024 / 1024).toFixed(1)
    };
}

function getHealthBar(percentage) {
    const filled = Math.round(percentage / 10);
    const empty = 10 - filled;
    return '█'.repeat(filled) + '░'.repeat(empty);
}

function getBotHealthStatus(connected, suppressed) {
    if (!connected) return { emoji: '💀', text: 'OFFLINE', color: '🔴' };
    if (suppressed) return { emoji: '😴', text: 'SUPPRESSED', color: '🟡' };
    return { emoji: '💚', text: 'ONLINE', color: '🟢' };
}

function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return String(num);
}

function getTimeSince(timestamp) {
    if (!timestamp) return 'Never';
    const diff = Date.now() - timestamp;
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (mins > 0) return `${mins}m ago`;
    return 'Just now';
}

// ==================== RANDOM EMOJI ====================
function getRandomNcEmoji() {
    const allEmojis = [];
    for (const key of Object.keys(emojiArrays)) {
        allEmojis.push(...emojiArrays[key]);
    }
    return allEmojis[Math.floor(Math.random() * allEmojis.length)];
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise(resolve => rl.question(text, resolve));

// ==================== SESSION CLEANUP ====================
function setupSessionCleanup(bot) {
    setInterval(() => {
        const now = Date.now();
        const maxAge = 300000;
        const maps = [
            bot.prefixChangeSessions,
            bot.attackButtonSessions,
            bot.autoReplyTargetSessions,
            bot.ariseSessions,
            bot.ytsSessions
        ];
        maps.forEach(m => {
            m.forEach((val, key) => {
                if (val.timestamp && (now - val.timestamp > maxAge)) {
                    m.delete(key);
                }
            });
        });
    }, 60000);
}

// ==================== MEDIA DOWNLOAD HELPER ====================
async function downloadMedia(msg) {
    try {
        const buffer = await downloadMediaMessage(
            msg,
            'buffer',
            {},
            {
                logger: baileysLogger,
                reuploadRequest: undefined
            }
        );
        return buffer;
    } catch (e) {
        console.error('[MEDIA] Download error:', e.message);
        try {
            const buffer = await downloadMediaMessage(msg, 'buffer', {});
            return buffer;
        } catch (e2) {
            console.error('[MEDIA] Fallback download error:', e2.message);
            return null;
        }
    }
}

// ==================== DYNAMIC MENU ====================
function generateMenu(prefix) {
    const p = prefix;
    return `╔═══❖•ೋ° °ೋ•❖═══╗
      🔱 KANHA x KRISHNA 🔱
        v6.2.0 ADAPTATION
╚═══❖•ೋ° °ೋ•❖═══╝
◎ ══════ ❈ ══════ ◎
⚙️ KRISHNA ADAPTATION ⚙️
◎ ══════ ❈ ══════ ◎
${prefix}fdesc [text] - Fastest Desc Sync (Random Emoji)
${prefix}stopfdesc - Stop Desc
${prefix}triplem [text] - KRISHNA Multi-Node Sync
${prefix}stoptriplem - Stop TripleM
${prefix}dtext [text] - Custom Emoji Text Loop
${prefix}stopdtext - Stop DText
${p}owner - Claim Bot Ownership (DM Only)
${p}removeowner - Remove Yourself As Owner (DM Only)
${p}addadmin @user - Add Admin (max 2)
${p}removeadmin @user - Remove Admin

◎ ══════ ❈ ══════ ◎
👥 ADMIN & SUB-ADMIN COMMANDS 👥
◎ ══════ ❈ ══════ ◎
${p}sub @user - Add Sub-Admin (Group)
${p}removesub @user - Remove Sub-Admin (Group)

◎ ══════ ❈ ══════ ◎
🤖 BOT MANAGEMENT 🤖
◎ ══════ ❈ ══════ ◎
${p}add [number] - Add New Bot
${p}bots - Show All Bots
${p}ping - Bot Latency
${p}suppress BOT# - Suppress Bot
${p}active BOT# - Activate Bot

◎ ══════ ❈ ══════ ◎
🎨 FONT NC ATTACK 🎨
◎ ══════ ❈ ══════ ◎
${p}font [font] [nc#] [text] - Font NC Attack (Random Delay)
${p}fonts - Show All Font Styles

◎ ══════ ❈ ══════ ◎
☠️ NC/TRIPLE ATTACK ☠️
◎ ══════ ❈ ══════ ◎
${p}nc1 to ${p}nc100 [text] - Simple NC Attack
${p}ncloop [nc#] [text] [rounds] - Looping NC
${p}stopncloop - Stop NC Loop
${p}loopheart [text] - Heart Loop (Random Delay)
${p}stoploopheart - Stop Heart Loop
${p}addwords [word1] [word2] - Add Words
${p}mywords - View Saved Words
${p}removeword [num] - Remove Word
${p}clearwords - Clear All Words
${p}usewords [nc#] - Use Saved Words (Random Delay)
${p}stopusewords - Stop Word NC
${p}covergc [text] - Max Speed Attack (5-20ms)
${p}stopcovergc - Stop CoverGC
${p}rage [nc#] [text] - Rage Mode (5-10ms)
${p}stoprage - Stop Rage
${p}timenc [nc#] [text] - Live Clock NC
${p}triple1 to ${p}triple35 [text] - Triple Attack (950ms)
${p}attack [text] - ULTIMATE ATTACK (All 100 NC!)

◎ ══════ ❈ ══════ ◎
🎵 VOICE ATTACK 🎵
◎ ══════ ❈ ══════ ◎
${p}tts [text] - Single Voice Note
${p}ttsatk [text] - Voice Spam (Random Delay)
${p}stopttsatk - Stop Voice Spam

◎ ══════ ❈ ══════ ◎
📁 MEDIA ATTACK 📁
◎ ══════ ❈ ══════ ◎
${p}pic - Picture Spam (Random Delay)
${p}video - Video Spam (Random Delay)
${p}sticker - Sticker Spam (Random Delay)
${p}stoppic - Stop Picture Spam
${p}stopvideo - Stop Video Spam
${p}stopsticker - Stop Sticker Spam
${p}gif - GIF Spam (Random Delay)
${p}vn - Voice Note Spam (Random Delay)
${p}stopgif - Stop GIF Spam
${p}stopvn - Stop Voice Note Spam

◎ ══════ ❈ ══════ ◎
🖼️ GROUP CONTROL 🖼️
◎ ══════ ❈ ══════ ◎
${p}gcpfp add/start/done - Group PFP Loop (5-9s)
${p}grpfp - Group DP Change (Random Delay)
${p}stopgrpfp - Stop DP Change

◎ ══════ ❈ ══════ ◎
👥 GROUP COMMANDS 👥
◎ ══════ ❈ ══════ ◎
${p}tagall [text] - Tag Everyone
${p}kick @user - Kick Member
${p}promote @user - Promote to Admin
${p}demote @user - Demote from Admin
${p}target [text] - Auto-reply to specific user (reply to their message)
${p}stoptarget - Stop target slide
${p}bully @user - Delete all messages from target (bot must be admin)
${p}stopbully - Stop bullying
${p}s [text] - Slide Attack (Random Delay)
${p}txt [text] - Text Spam (12-25s)
${p}stops - Stop Slide
${p}stoptxt - Stop Text Spam
${p}reaction [emoji] - Auto React (Random Delay)
${p}stopreaction - Stop React
${p}leave - Leave Group
${p}summon - Add All Bots

◎ ══════ ❈ ══════ ◎
🎵 YOUTUBE SYSTEM 🎵
◎ ══════ ❈ ══════ ◎
${p}yts [query] - Search & Download

◎ ══════ ❈ ══════ ◎
☠️ REPORT SYSTEM ☠️
◎ ══════ ❈ ══════ ◎
${p}fuck [number] [times] - Report User
${p}stopfuck - Stop Reports

◎ ══════ ❈ ══════ ◎
🌀 ARC SYSTEM 🌀
◎ ══════ ❈ ══════ ◎
${p}arc [name] - Eternal Spam (Random Delay)
${p}stoparc - Stop ARC

◎ ══════ ❈ ══════ ◎
📊 INFO COMMANDS 📊
◎ ══════ ❈ ══════ ◎
${p}menu - Show Menu
${p}status - Full Status
${p}delays - Show Delays (Random Values)
${p}gcstatus - Group Info
${p}arise - Sovereign Command (Admins Only)
${p}clearcache - Clear Cache
${p}stopall - Stop Everything
-all (DM) - Global Stop

╔══════════════════════════╗
║   🚀 KANHA MATRIX v5    ║
║   PURE RANDOM DELAYS    ║
╚══════════════════════════╝`;
}

// ==================== GCSTATUS COMMAND HANDLER ====================
async function handleGcStatusCommand(sock, from, msg, isGroup, hasPerm) {
    if (!isGroup) {
        await sock.sendMessage(from, { text: '❌ This command can only be used in groups!' }, { quoted: msg });
        return;
    }

    try {
        const metadata = await sock.groupMetadata(from);
        const participants = metadata.participants;
        const groupName = metadata.subject || 'Unknown Group';
        const groupDesc = metadata.desc || 'No description';
        const groupCreation = metadata.creation ? new Date(metadata.creation * 1000).toLocaleString() : 'Unknown';
        const groupOwner = metadata.owner ? metadata.owner.split('@')[0] : 'Unknown';
        const groupSize = participants.length;
        
        const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');
        const adminCount = admins.length;
        const membersCount = groupSize - adminCount;
        
        let groupPic = '❌ No picture';
        try {
            const ppUrl = await sock.profilePictureUrl(from, 'image');
            groupPic = `✅ Available`;
        } catch (e) {
            groupPic = '❌ Not set';
        }

        const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const isBotAdmin = participants.some(p => p.id === botJid && (p.admin === 'admin' || p.admin === 'superadmin'));

        const statusMessage = `╔═══════════════════════════════════════╗
║        📊 GROUP STATUS REPORT        ║
╚═══════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━
🏷️ *Group Name:* ${groupName}
🆔 *Group ID:* ${from.split('@')[0]}
📝 *Description:* ${groupDesc}
👥 *Total Members:* ${groupSize}
👑 *Admins:* ${adminCount}
👤 *Members:* ${membersCount}
👤 *Group Owner:* @${groupOwner}
📅 *Created:* ${groupCreation}
🖼️ *Profile Picture:* ${groupPic}
🤖 *Bot Admin:* ${isBotAdmin ? '✅ Yes' : '❌ No'}

━━━━━━━━━━━━━━━━━━━━━━
👑 *ADMIN LIST:*
${admins.map((admin, index) => `${index + 1}. @${admin.id.split('@')[0]}`).join('\n') || 'No admins found'}

━━━━━━━━━━━━━━━━━━━━━━
🔱 ░≪ 𝑃𝑂𝑊𝐸𝑅𝐸𝐷 𝐵𝑌 KANHA ≫░ 🔱`;

        await sock.sendMessage(from, {
            text: statusMessage,
            mentions: admins.map(admin => admin.id)
        }, { quoted: msg });

        updateStats('gcstatus', null, 'execute');

    } catch (error) {
        console.error('[GCSTATUS] Error:', error.message);
        await sock.sendMessage(from, { 
            text: `❌ Failed to fetch group status: ${error.message}` 
        }, { quoted: msg });
    }
}

// ==================== ENHANCED PROFESSIONAL STATUS ====================
function generateProfessionalStatus(botSession, manager) {
    const mem = getMemoryUsage();
    const uptime = getUptime();
    const allBots = manager.commandBus.getAllBots();
    const connectedBots = manager.commandBus.getConnected();
    const allConnected = manager.commandBus.getAllConnected();
    const hseeStats = HSEE.getStats();

    const totalBots = allBots.length;
    const onlineBots = connectedBots.length;
    const healthPercent = totalBots > 0 ? Math.round((onlineBots / totalBots) * 100) : 0;
    const memPercent = Math.min(100, Math.round((parseFloat(mem.heapUsed) / parseFloat(mem.heapTotal)) * 100));

    let taskCounts = {
        nc: 0, triple: 0, txt: 0, slide: 0, tts: 0,
        pic: 0, gcpfp: 0, reaction: 0, audio: 0,
        saudio: 0, video: 0, svideo: 0, sticker: 0, autoreply: 0, tagall: 0,
        arc: 0, rage: 0, ultimate: 0, covergc: 0, timenc: 0,
        ncloop: 0, heartloop: 0, usewords: 0, gifspam: 0, stickerspam: 0, vnspam: 0,
        target: 0, bully: 0
    };

    let botDetails = [];

    allBots.forEach((bot) => {
        let botTasks = {};
        let totalBotTasks = 0;

        let ncCount = 0, tripleCount = 0;
        bot.activeNC.forEach(t => {
            if (t.active) {
                if (t.tripleId) tripleCount++;
                else ncCount++;
            }
        });
        taskCounts.nc += ncCount;
        taskCounts.triple += tripleCount;
        botTasks.nc = ncCount;
        botTasks.triple = tripleCount;
        totalBotTasks += ncCount + tripleCount;

        const taskMaps = [
            ['txt', bot.activeTxt],
            ['slide', bot.activeSlides],
            ['tts', bot.activeTTS],
            ['pic', bot.activePic],
            ['gcpfp', bot.activeGcPfp],
            ['reaction', bot.activeReactions],
            ['audio', bot.activeAudio],
            ['saudio', bot.activeSlideAudio],
            ['video', bot.activeVideo],
            ['svideo', bot.activeSlideVideo],
            ['sticker', bot.activeSticker],
            ['autoreply', bot.activeAutoReply],
            ['tagall', bot.activeTagall],
            ['arc', bot.activeArc],
            ['rage', bot.activeRageMode],
            ['covergc', bot.activeCoverGC],
            ['timenc', bot.activeTimeNC],
            ['ncloop', bot.activeNcLoop],
            ['heartloop', bot.activeHeartLoop],
            ['usewords', bot.activeUseWords],
            ['gifspam', bot.activeGifSpam],
            ['stickerspam', bot.activeStickerSpam],
            ['vnspam', bot.activeVnSpam],
            ['target', bot.activeTargetSlides],
            ['bully', bot.activeBully]
        ];

        taskMaps.forEach(([name, map]) => {
            let count = 0;
            if (map) {
                if (map instanceof Map) {
                    map.forEach(t => { if (t && t.active) count++; });
                } else if (map && typeof map === 'object' && map.active) {
                    count = map.active ? 1 : 0;
                }
            }
            taskCounts[name] += count;
            botTasks[name] = count;
            totalBotTasks += count;
        });

        botDetails.push({ bot, tasks: botTasks, totalTasks: totalBotTasks });
    });

    const totalActive = Object.values(taskCounts).reduce((a, b) => a + b, 0);

    let totalLifetimeExec = 0;
    const lifetimeKeys = ['attack', 'kick', 'promote', 'demote', 'tagall',
        'autoreply', 'tts', 'summon', 'arise', 'leave', 'slide', 'txt',
        'ttsatk', 'audio', 'saudio', 'video', 'svideo', 'pic', 'sticker',
        'gcpfp', 'reaction', 'yts', 'fuck', 'bully', 'arc', 'gcstatus',
        'rage', 'ultimate', 'covergc', 'timenc', 'ncloop', 'heartloop',
        'usewords', 'gifspam', 'stickerspam', 'vnspam', 'target'];

    lifetimeKeys.forEach(k => {
        totalLifetimeExec += (attackStats[k]?.executed || 0);
    });
    if (attackStats.nc) {
        Object.values(attackStats.nc).forEach(v => { totalLifetimeExec += (v.executed || 0); });
    }
    if (attackStats.triple) {
        Object.values(attackStats.triple).forEach(v => { totalLifetimeExec += (v.executed || 0); });
    }

    let status = ``;
    status += `╔══════════════════════════════════════════════╗\n`;
    status += `║  👑 KANHA MATRIX v5 - PURE RANDOM EDITION  ║\n`;
    status += `╚══════════════════════════════════════════════╝\n\n`;

    status += `🏛️ ━━━ SYSTEM VITALS ━━━\n`;
    status += `┃ ⏱️ Uptime        : ${uptime}\n`;
    status += `┃ 🧠 RAM Used      : ${mem.heapUsed}MB / ${mem.heapTotal}MB\n`;
    status += `┃ 📊 Memory Load  : [${getHealthBar(memPercent)}] ${memPercent}%\n`;
    status += `┃ 🔌 External Mem : ${mem.external}MB\n`;
    status += `┃ 🔮 RSS Total    : ${mem.rss}MB\n`;
    status += `┃ ⌨️ Prefix        : ${currentPrefix}\n`;
    status += `┃ ⚡ HSEE Engine  : 🟢 ENABLED\n`;
    status += `┃ 🔢 Total Execs  : ${formatNumber(totalLifetimeExec)}\n`;
    status += `┃ 📅 Node Version : ${process.version}\n`;
    status += `┃ 🖥️ Platform      : ${process.platform} ${process.arch}\n┃\n\n`;

    status += `🤖 ━━━ BOT FLEET [${onlineBots}/${totalBots}] ━━━\n`;
    status += `┃ 💪 Fleet Health  : [${getHealthBar(healthPercent)}] ${healthPercent}%\n`;
    status += `┃ 🟢 Active Bots   : ${onlineBots}\n`;
    status += `┃ 🔇 Suppressed    : ${suppressedBots.size}\n`;
    status += `┃ 🔴 Offline       : ${totalBots - allConnected.length}\n┃\n`;

    botDetails.forEach((detail) => {
        const { bot, tasks, totalTasks } = detail;
        const isSup = suppressedBots.has(bot.botId);
        const health = getBotHealthStatus(bot.connected, isSup);
        const connTime = bot.connectedAt ? getTimeSince(bot.connectedAt) : 'N/A';
        const reconnects = bot.reconnectCount || 0;

        status += `┃ ${health.color} ${health.emoji} *${bot.botId}*\n`;
        status += `┃    ├ 📱 Phone      : ${bot.phoneNumber || 'QR Login'}\n`;
        status += `┃    ├ 📶 Status     : ${health.text}\n`;
        status += `┃    ├ ⚡ Tasks      : ${totalTasks} active\n`;
        status += `┃    ├ 🔄 Reconnects : ${reconnects}\n`;
        status += `┃    ├ 🕐 Connected  : ${connTime}\n`;

        if (totalTasks > 0) {
            let taskList = [];
            if (tasks.nc > 0) taskList.push(`NC:${tasks.nc}`);
            if (tasks.triple > 0) taskList.push(`TR:${tasks.triple}`);
            if (tasks.txt > 0) taskList.push(`TXT:${tasks.txt}`);
            if (tasks.slide > 0) taskList.push(`SLD:${tasks.slide}`);
            if (tasks.tts > 0) taskList.push(`TTS:${tasks.tts}`);
            if (tasks.pic > 0) taskList.push(`PIC:${tasks.pic}`);
            if (tasks.audio > 0) taskList.push(`AUD:${tasks.audio}`);
            if (tasks.video > 0) taskList.push(`VID:${tasks.video}`);
            if (tasks.gcpfp > 0) taskList.push(`PFP:${tasks.gcpfp}`);
            if (tasks.reaction > 0) taskList.push(`RCT:${tasks.reaction}`);
            if (tasks.sticker > 0) taskList.push(`STK:${tasks.sticker}`);
            if (tasks.autoreply > 0) taskList.push(`AR:${tasks.autoreply}`);
            if (tasks.saudio > 0) taskList.push(`SAUD:${tasks.saudio}`);
            if (tasks.svideo > 0) taskList.push(`SVID:${tasks.svideo}`);
            if (tasks.tagall > 0) taskList.push(`TAG:${tasks.tagall}`);
            if (tasks.arc > 0) taskList.push(`ARC:${tasks.arc}`);
            if (tasks.rage > 0) taskList.push(`RAGE:${tasks.rage}`);
            if (tasks.covergc > 0) taskList.push(`COVER:${tasks.covergc}`);
            if (tasks.timenc > 0) taskList.push(`TIME:${tasks.timenc}`);
            if (tasks.ncloop > 0) taskList.push(`LOOP:${tasks.ncloop}`);
            if (tasks.heartloop > 0) taskList.push(`HEART:${tasks.heartloop}`);
            if (tasks.usewords > 0) taskList.push(`WORDS:${tasks.usewords}`);
            if (tasks.gifspam > 0) taskList.push(`GIF:${tasks.gifspam}`);
            if (tasks.stickerspam > 0) taskList.push(`STKSPAM:${tasks.stickerspam}`);
            if (tasks.vnspam > 0) taskList.push(`VN:${tasks.vnspam}`);
            if (tasks.target > 0) taskList.push(`🎯TARGET:${tasks.target}`);
            if (tasks.bully > 0) taskList.push(`👊BULLY:${tasks.bully}`);
            status += `┃    └ 📋 Breakdown  : ${taskList.join(' | ')}\n`;
        } else {
            status += `┃    └ 🌙 Idle\n`;
        }
        status += `┃\n`;
    });

    status += `\n🚀 ━━━ HSEE ENGINE ━━━\n`;
    status += `┃ 🔋 Status         : 🟢 ENABLED\n`;
    status += `┃ 🎯 Command Queue  : ${hseeStats.commandQueue.size} queued | ${hseeStats.commandQueue.pending} processing\n`;
    status += `┃ ⚔️ Attack Queue   : ${hseeStats.attackQueue.size} queued | ${hseeStats.attackQueue.pending} processing\n`;
    status += `┃ 📨 Normal Queue   : ${hseeStats.normalQueue.size} queued | ${hseeStats.normalQueue.pending} processing\n`;
    status += `┃ 🗄️ Group Cache    : ${hseeStats.cacheStats.keys || 0} groups cached\n`;
    status += `┃ ✅ Cache Hits     : ${formatNumber(hseeStats.cacheStats.hits || 0)}\n`;
    status += `┃ ❌ Cache Misses   : ${formatNumber(hseeStats.cacheStats.misses || 0)}\n`;
    const hitRate = (hseeStats.cacheStats.hits || 0) + (hseeStats.cacheStats.misses || 0) > 0
        ? Math.round(((hseeStats.cacheStats.hits || 0) / ((hseeStats.cacheStats.hits || 0) + (hseeStats.cacheStats.misses || 0))) * 100) : 0;
    status += `┃ 📈 Hit Rate       : ${hitRate}%\n┃\n\n`;

    status += `⚡ ━━━ ACTIVE OPERATIONS [${totalActive}] ━━━\n`;
    if (totalActive === 0) {
        status += `┃ 🌙 All systems idle - No active operations\n`;
    } else {
        if (taskCounts.nc > 0) status += `┃ 🧪 NC Changes     : ${taskCounts.nc} running (1000-1500ms)\n`;
        if (taskCounts.triple > 0) status += `┃ 🔱 Triple NC      : ${taskCounts.triple} running (950ms)\n`;
        if (taskCounts.txt > 0) status += `┃ 📝 Text Spam      : ${taskCounts.txt} running (12-25s)\n`;
        if (taskCounts.slide > 0) status += `┃ 🎚️ Slide          : ${taskCounts.slide} running (0.5-1.5s)\n`;
        if (taskCounts.tts > 0) status += `┃ 🗣️ TTS Attack     : ${taskCounts.tts} running (1-3s)\n`;
        if (taskCounts.pic > 0) status += `┃ 🖼️ Pic Spam       : ${taskCounts.pic} running (1.5-2.5s)\n`;
        if (taskCounts.gcpfp > 0) status += `┃ 🎭 GC PFP         : ${taskCounts.gcpfp} running (5-9s)\n`;
        if (taskCounts.reaction > 0) status += `┃ 💫 Reaction       : ${taskCounts.reaction} running (1.5-4s)\n`;
        if (taskCounts.audio > 0) status += `┃ 🎧 Audio          : ${taskCounts.audio} running (0.6-1.8s)\n`;
        if (taskCounts.saudio > 0) status += `┃ 🎶 Slide Audio    : ${taskCounts.saudio} running (0.6-1.8s)\n`;
        if (taskCounts.video > 0) status += `┃ 🎬 Video          : ${taskCounts.video} running (0.8-2s)\n`;
        if (taskCounts.svideo > 0) status += `┃ 📹 Slide Video    : ${taskCounts.svideo} running (0.8-2s)\n`;
        if (taskCounts.sticker > 0) status += `┃ 🏷️ Sticker        : ${taskCounts.sticker} running (1.5-2s)\n`;
        if (taskCounts.autoreply > 0) status += `┃ 💬 Auto-Reply     : ${taskCounts.autoreply} running\n`;
        if (taskCounts.tagall > 0) status += `┃ 📢 Tag All        : ${taskCounts.tagall} running\n`;
        if (taskCounts.arc > 0) status += `┃ 🌀 Arc Spam        : ${taskCounts.arc} running (0.5-2s)\n`;
        if (taskCounts.rage > 0) status += `┃ 😤 Rage Mode       : ${taskCounts.rage} running (5-10ms)\n`;
        if (taskCounts.covergc > 0) status += `┃ 🔥 Cover GC       : ${taskCounts.covergc} running (5-20ms)\n`;
        if (taskCounts.timenc > 0) status += `┃ ⏱️ Time NC         : ${taskCounts.timenc} running\n`;
        if (taskCounts.ncloop > 0) status += `┃ 🔁 NC Loop         : ${taskCounts.ncloop} running (50-200ms)\n`;
        if (taskCounts.heartloop > 0) status += `┃ 💞 Heart Loop      : ${taskCounts.heartloop} running (20-100ms)\n`;
        if (taskCounts.usewords > 0) status += `┃ 📝 Word NC         : ${taskCounts.usewords} running (100-300ms)\n`;
        if (taskCounts.gifspam > 0) status += `┃ 🎞️ GIF Spam        : ${taskCounts.gifspam} running (300-800ms)\n`;
        if (taskCounts.stickerspam > 0) status += `┃ 🏷️ Sticker Spam    : ${taskCounts.stickerspam} running\n`;
        if (taskCounts.vnspam > 0) status += `┃ 🎤 Voice Note Spam : ${taskCounts.vnspam} running (500-1500ms)\n`;
        if (taskCounts.target > 0) status += `┃ 🎯 Target Slide    : ${taskCounts.target} running (1-5s)\n`;
        if (taskCounts.bully > 0) status += `┃ 👊 Bully Mode      : ${taskCounts.bully} running\n`;
    }
    if (activeFuckTasks.size > 0) {
        status += `┃ ☠️ Report Tasks   : ${activeFuckTasks.size} running\n`;
    }
    if (activeBullyTargets.size > 0) {
        status += `┃ 👊 Bully Targets  : ${activeBullyTargets.size} active\n`;
    }
    status += `┃\n\n`;

    status += `👑 ━━━ COMMAND HIERARCHY ━━━\n`;
    status += `┃ 👑 Owner         : ${roles.owner ? `@${roles.owner.split('@')[0]}` : 'None'}\n`;
    status += `┃ 🏆 Admins (${roles.admins.length}/2):\n`;
    if (roles.admins.length === 0) {
        status += `┃    └ 🚫 No admins registered\n`;
    } else {
        roles.admins.forEach((admin, i) => {
            const num = admin.split('@')[0];
            const hasArise = ariseData[admin] ? '🏴' : '⬜';
            status += `┃    ${i === roles.admins.length - 1 ? '└' : '├'} ${hasArise} @${num}\n`;
        });
    }
    status += `┃ 🛡️ Sub-Admins:\n`;
    let subCount = 0;
    for (const group in roles.subAdmins) {
        subCount += roles.subAdmins[group].length;
    }
    status += `┃    └ Total: ${subCount} sub-admins across all groups\n┃\n\n`;

    status += `📈 ━━━ LIFETIME STATISTICS ━━━\n`;
    status += `┃ ⚔️ ATTACK OPERATIONS\n`;
    status += `┃ ├ 💣 Combined Attacks : ${formatNumber(attackStats.attack?.executed || 0)}\n`;
    status += `┃ ├ 🧪 NC Executions    : ${formatNumber(Object.values(attackStats.nc || {}).reduce((a, v) => a + (v.executed || 0), 0))}\n`;
    status += `┃ ├ 🔱 Triple Executions: ${formatNumber(Object.values(attackStats.triple || {}).reduce((a, v) => a + (v.executed || 0), 0))}\n`;
    status += `┃ ├ 📝 Text Floods      : ${formatNumber(attackStats.txt?.executed || 0)}\n`;
    status += `┃ ├ 🎚️ Slide Attacks   : ${formatNumber(attackStats.slide?.executed || 0)}\n`;
    status += `┃ ├ 🎯 Target Replies   : ${formatNumber(attackStats.target?.executed || 0)}\n`;
    status += `┃ ├ ☠️ Reports Sent     : ${formatNumber(attackStats.fuck?.executed || 0)}\n`;
    status += `┃ ├ 👊 Bully Deletes    : ${formatNumber(attackStats.bully?.executed || 0)}\n`;
    status += `┃ ├ 😤 Rage Attacks     : ${formatNumber(attackStats.rage?.executed || 0)}\n`;
    status += `┃ ├ 💥 Ultimate Attacks : ${formatNumber(attackStats.ultimate?.executed || 0)}\n`;
    status += `┃ ├ 🔥 Cover GC Attacks : ${formatNumber(attackStats.covergc?.executed || 0)}\n`;
    status += `┃ ├ ⏱️ Time NC Attacks  : ${formatNumber(attackStats.timenc?.executed || 0)}\n`;
    status += `┃ ├ 🔁 NC Loop Attacks  : ${formatNumber(attackStats.ncloop?.executed || 0)}\n`;
    status += `┃ ├ 💞 Heart Loop Attacks: ${formatNumber(attackStats.heartloop?.executed || 0)}\n`;
    status += `┃ ├ 📝 Word NC Attacks  : ${formatNumber(attackStats.usewords?.executed || 0)}\n`;
    status += `┃ └ 💬 Auto-Replies    : ${formatNumber(attackStats.autoreply?.executed || 0)}\n`;
    status += `┃\n┃ 📁 MEDIA OPERATIONS\n`;
    status += `┃ ├ 🗣️ TTS Generated    : ${formatNumber(attackStats.tts?.executed || 0)}\n`;
    status += `┃ ├ 🔊 TTS Attacks      : ${formatNumber(attackStats.ttsatk?.executed || 0)}\n`;
    status += `┃ ├ 🎧 Audio Floods     : ${formatNumber(attackStats.audio?.executed || 0)}\n`;
    status += `┃ ├ 🎵 YTS Downloads    : ${formatNumber(attackStats.yts?.executed || 0)}\n`;
    status += `┃ ├ 🖼️ Pic Floods       : ${formatNumber(attackStats.pic?.executed || 0)}\n`;
    status += `┃ ├ 🎬 Video Floods     : ${formatNumber(attackStats.video?.executed || 0)}\n`;
    status += `┃ ├ 📹 Slide Video      : ${formatNumber(attackStats.svideo?.executed || 0)}\n`;
    status += `┃ ├ 🏷️ Sticker Floods   : ${formatNumber(attackStats.sticker?.executed || 0)}\n`;
    status += `┃ ├ 🎞️ GIF Spam         : ${formatNumber(attackStats.gifspam?.executed || 0)}\n`;
    status += `┃ ├ 🏷️ Sticker Spam     : ${formatNumber(attackStats.stickerspam?.executed || 0)}\n`;
    status += `┃ └ 🎤 Voice Note Spam  : ${formatNumber(attackStats.vnspam?.executed || 0)}\n`;
    status += `┃\n┃ 👥 GROUP OPERATIONS\n`;
    status += `┃ ├ 👢 Kicks            : ${formatNumber(attackStats.kick?.executed || 0)}\n`;
    status += `┃ ├ ⬆️ Promotes         : ${formatNumber(attackStats.promote?.executed || 0)}\n`;
    status += `┃ ├ ⬇️ Demotes          : ${formatNumber(attackStats.demote?.executed || 0)}\n`;
    status += `┃ ├ 📢 Tag Alls         : ${formatNumber(attackStats.tagall?.executed || 0)}\n`;
    status += `┃ ├ 🎭 GC PFP Changes   : ${formatNumber(attackStats.gcpfp?.executed || 0)}\n`;
    status += `┃ ├ 💫 Reactions        : ${formatNumber(attackStats.reaction?.executed || 0)}\n`;
    status += `┃ ├ 📡 Summons          : ${formatNumber(attackStats.summon?.executed || 0)}\n`;
    status += `┃ ├ 🏴 Arise Triggers   : ${formatNumber(attackStats.arise?.executed || 0)}\n`;
    status += `┃ ├ 🚪 Leaves           : ${formatNumber(attackStats.leave?.executed || 0)}\n`;
    status += `┃ ├ 🌀 Arc Spams        : ${formatNumber(attackStats.arc?.executed || 0)}\n`;
    status += `┃ └ 📊 GC Status Checks : ${formatNumber(attackStats.gcstatus?.executed || 0)}\n`;
    status += `┃ └ 🔢 Grand Total      : ${formatNumber(totalLifetimeExec)} operations\n┃\n\n`;

    if (suppressedBots.size > 0) {
        status += `🔇 ━━━ SUPPRESSED BOTS ━━━\n`;
        suppressedBots.forEach(botId => { status += `┃ 😴 ${botId}\n`; });
        status += `┃\n\n`;
    }

    const gcGroups = Object.keys(gcPfpCollections).filter(k => gcPfpCollections[k]?.images?.length > 0);
    if (gcGroups.length > 0) {
        status += `📸 ━━━ GCPFP COLLECTIONS ━━━\n`;
        gcGroups.forEach(g => {
            const d = gcPfpCollections[g];
            status += `┃ 🖼️ ${g.split('@')[0].slice(0, 15)}... : ${d.images.length} images ${d.collecting ? '📥 Collecting' : '✅ Ready'}\n`;
        });
        status += `┃\n\n`;
    }

    const ariseAdmins = Object.keys(ariseData);
    if (ariseAdmins.length > 0) {
        status += `🏴 ━━━ ARISE PROFILES ━━━\n`;
        ariseAdmins.forEach(admin => {
            const d = ariseData[admin];
            status += `┃ 👑 @${admin.split('@')[0]}\n`;
            status += `┃    ├ 📝 Caption : ${(d.caption || '').slice(0, 30)}${d.caption?.length > 30 ? '...' : ''}\n`;
            status += `┃    ├ 🖼️ Image   : ${d.image ? '✅ Set' : '❌ None'}\n`;
            status += `┃    └ 🕐 Set     : ${getTimeSince(d.setAt)}\n`;
        });
        status += `┃\n\n`;
    }

    status += `╔══════════════════════════════════════════════╗\n`;
    status += `║   🔱 KANHA MATRIX v5 - PURE RANDOM EDITION  ║\n`;
    status += `║   ⚡ All Delays Are Random | No Manual Override ║\n`;
    status += `║   📊 Total Lifetime Ops: ${formatNumber(totalLifetimeExec).padEnd(20)}║\n`;
    status += `╚══════════════════════════════════════════════╝`;

    return status;
}

// ==================== FUCK COMMAND ====================
async function executeFuckCommand(sock, targetNumber, times, from, msg, botId, sendSlideFunc) {
    const taskId = `${from}_fuck_${targetNumber}_${Date.now()}`;
    const maxTimes = Math.min(times, 1000);

    const task = {
        active: true,
        target: targetNumber,
        total: maxTimes,
        completed: 0,
        failed: 0,
        startedAt: Date.now()
    };
    activeFuckTasks.set(taskId, task);
    updateStats('fuck', null, 'start');

    const targetJid = targetNumber + '@s.whatsapp.net';

    (async () => {
        for (let i = 0; i < maxTimes; i++) {
            if (!task.active) break;

            try {
                const randomDelay = Math.floor(Math.random() * 7000);
                await delay(randomDelay);

                if (!task.active) break;

                try {
                    await sock.updateBlockStatus(targetJid, 'block');
                    await delay(500);
                    await sock.updateBlockStatus(targetJid, 'unblock');
                    task.completed++;
                    updateStats('fuck', null, 'execute');
                } catch (blockErr) {
                    try {
                        const reportMsg = {
                            tag: 'iq',
                            attrs: {
                                to: '@s.whatsapp.net',
                                type: 'set',
                                xmlns: 'urn:xmpp:whatsapp:dirty',
                            },
                            content: [{
                                tag: 'clean',
                                attrs: { type: 'account_sync' },
                                content: undefined,
                            }],
                        };
                        await sock.query(reportMsg).catch(() => {});
                        task.completed++;
                        updateStats('fuck', null, 'execute');
                    } catch (e2) {
                        task.failed++;
                    }
                }
            } catch (e) {
                task.failed++;
                console.error(`[FUCK] Report ${i + 1} error:`, e.message);
            }

            if ((i + 1) % 25 === 0 && task.active) {
                try {
                    await sendSlideFunc(from, `☠️ *REPORT PROGRESS*\n\n🎯 Target: ${targetNumber}\n✅ Done: ${task.completed}/${maxTimes}\n❌ Failed: ${task.failed}\n⏳ Remaining: ${maxTimes - (i + 1)}`, msg);
                } catch (e) {}
            }
        }

        const elapsed = ((Date.now() - task.startedAt) / 1000).toFixed(1);
        activeFuckTasks.delete(taskId);
        updateStats('fuck', null, 'stop');

        try {
            await sendSlideFunc(from, `☠️ *REPORT COMPLETE!*\n\n🎯 Target: ${targetNumber}\n✅ Completed: ${task.completed}/${maxTimes}\n❌ Failed: ${task.failed}\n⏱️ Time: ${elapsed}s\n🤖 Bot: ${botId}`, msg);
        } catch (e) {}
    })();

    return taskId;
}

// ==================== COMMAND BUS ====================
class CommandBus {
    constructor() {
        this.botSessions = new Map();
        this.processedMessages = new Map();

        setInterval(() => {
            try {
                const now = Date.now();
                this.processedMessages.forEach((ts, id) => {
                    if (now - ts > 60000) this.processedMessages.delete(id);
                });
            } catch (e) {
                console.error('[CommandBus] Cleanup error:', e.message);
            }
        }, 30000);
    }

    registerBot(id, session) { this.botSessions.set(id, session); }
    unregisterBot(id) { this.botSessions.delete(id); }

    shouldProcess(msgId) {
        if (this.processedMessages.has(msgId)) return false;
        this.processedMessages.set(msgId, Date.now());
        return true;
    }

    async broadcast(type, data, originId, confirm = true) {
        try {
            const bots = [...this.botSessions.values()].filter(b => b.connected && !suppressedBots.has(b.botId));
            const promises = bots.map(bot =>
                HSEE.runNormal(() =>
                    bot.execute(type, data, bot.botId === originId && confirm)
                ).catch(e => console.error(`[${bot.botId}] Exec error:`, e.message))
            );
            await Promise.allSettled(promises);
        } catch (e) {
            console.error('[CommandBus] Broadcast error:', e.message);
        }
    }

    async broadcastAll(type, data) {
        try {
            const bots = [...this.botSessions.values()].filter(b => b.connected);
            const promises = bots.map(bot =>
                bot.execute(type, data, false).catch(e => console.error(`[${bot.botId}] Exec error:`, e.message))
            );
            await Promise.allSettled(promises);
        } catch (e) {
            console.error('[CommandBus] BroadcastAll error:', e.message);
        }
    }

    getAllBots() { return [...this.botSessions.values()]; }

    getConnected() {
        return [...this.botSessions.values()].filter(b => b.connected && !suppressedBots.has(b.botId));
    }

    getAllConnected() {
        return [...this.botSessions.values()].filter(b => b.connected);
    }

    getLeader() { return this.getConnected()[0] || null; }

    getBotByIdOrNumber(identifier) {
        try {
            if (identifier.toUpperCase().startsWith('BOT')) {
                return this.botSessions.get(identifier.toUpperCase());
            }
            const num = parseInt(identifier);
            if (!isNaN(num)) {
                return this.botSessions.get(`BOT${num}`);
            }
        } catch (e) {
            console.error('[CommandBus] getBotByIdOrNumber error:', e.message);
        }
        return null;
    }

    getBotsByNumbers(numbers) {
        const bots = [];
        for (const num of numbers) {
            const bot = this.getBotByIdOrNumber(String(num));
            if (bot) bots.push(bot);
        }
        return bots;
    }
}

// ==================== BOT SESSION ====================
class BotSession {
    constructor(botId, phone, manager, reqJid = null, useQR = false) {
        this.botId = botId;
        this.phoneNumber = phone;
        this.manager = manager;
        this.reqJid = reqJid;
        this.useQR = useQR;
        this.sock = null;
        this.connected = false;
        this.botNumber = null;
        this.authPath = `./auth/${botId}`;
        this.pairingRequested = false;
        this.loggedOut = false;
        this.reconnectCount = 0;
        this.connectedAt = null;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 3000;
        this.disabled = false;

        // ===== ALL ACTIVE TASK MAPS =====
        this.activeFDesc = new Map();
        this.activeTripleM = new Map();
        this.activeDText = new Map();
        this.activeNC = new Map();
        this.activeSlides = new Map();
        this.activeTxt = new Map();
        this.activeTTS = new Map();
        this.activePic = new Map();
        this.activeGcPfp = new Map();
        this.activeReactions = new Map();
        this.activeAudio = new Map();
        this.activeSlideAudio = new Map();
        this.activeVideo = new Map();
        this.activeSlideVideo = new Map();
        this.activeSticker = new Map();
        this.activeAutoReply = new Map();
        this.activeTagall = new Map();
        this.activeBully = new Map();
        this.activeArc = new Map();
        this.activeGrpfp = new Map();
        
        // New features
        this.activeNcLoop = null;
        this.activeHeartLoop = null;
        this.activeUseWords = null;
        this.activeCoverGC = null;
        this.activeTimeNC = null;
        this.activeRageMode = null;
        this.activeNcSpam = null;
        this.activeGifSpam = new Map();
        this.activeStickerSpam = new Map();
        this.activeVnSpam = new Map();
        this.activeAttack = false;
        this.attackThreads = [];
        
        // Target slide
        this.activeTargetSlides = new Map();

        // ===== SESSION MAPS =====
        this.prefixChangeSessions = new Map();
        this.attackButtonSessions = new Map();
        this.autoReplyTargetSessions = new Map();
        this.ariseSessions = new Map();
        this.ytsSessions = new Map();

        this.gcpfpCollecting = new Map();

        setupSessionCleanup(this);
    }

    // ==================== BAILEYS 7 CONNECTION ====================
    async connect() {
        try {
            if (this.loggedOut || this.disabled) {
                console.log(`[${this.botId}] Bot is logged out or disabled. Not reconnecting.`);
                return;
            }

            if (!fs.existsSync(this.authPath)) fs.mkdirSync(this.authPath, { recursive: true });

            const { state, saveCreds } = await useMultiFileAuthState(this.authPath);
            const needsPair = !state.creds.registered;

            let version;
            try {
                const versionInfo = await fetchLatestBaileysVersion();
                version = versionInfo.version;
                console.log(`[${this.botId}] Using WA version: ${version.join('.')}`);
            } catch (e) {
                console.log(`[${this.botId}] Could not fetch version, using default`);
                version = undefined;
            }

            this.sock = makeWASocket({
                version,
                auth: {
                    creds: state.creds,
                    keys: makeCacheableSignalKeyStore(state.keys, baileysLogger)
                },
                logger: baileysLogger,
                browser: Browsers.ubuntu('Chrome'),
                printQRInTerminal: this.useQR,
                connectTimeoutMs: 120000,
                defaultQueryTimeoutMs: 60000,
                keepAliveIntervalMs: 25000,
                emitOwnEvents: true,
                markOnlineOnConnect: true,
                syncFullHistory: false,
                generateHighQualityLinkPreview: false,
                retryRequestDelayMs: 500,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                getMessage: async (key) => {
                    try {
                        const cached = msgRetryCounterCache.get(key.id);
                        if (cached) return cached;
                    } catch (e) {}
                    return { conversation: '' };
                },
                msgRetryCounterCache
            });

            // ===== CONNECTION UPDATE =====
            this.sock.ev.on('connection.update', async (update) => {
                try {
                    const { connection, lastDisconnect, qr } = update;

                    if (qr && this.useQR) {
                        console.log(`\n📱 QR Code for ${this.botId} - Scan Now!\n`);
                        try {
                            const qrcode = await import('qrcode-terminal');
                            qrcode.default.generate(qr, { small: true });
                        } catch (e) {
                            console.log('QR Code String:', qr);
                        }
                    }

                    if (!this.useQR && needsPair && this.phoneNumber && !this.pairingRequested) {
                        this.pairingRequested = true;
                        await delay(3000);
                        try {
                            let cleanNumber = this.phoneNumber.replace(/[^0-9]/g, '');
                            if (cleanNumber.startsWith('0')) cleanNumber = cleanNumber.slice(1);
                            console.log(`[${this.botId}] Requesting pairing code for: ${cleanNumber}`);
                            const code = await this.sock.requestPairingCode(cleanNumber);
                            console.log(`\n╔══════════════════════════════╗`);
                            console.log(`║    PAIRING CODE: ${code}     ║`);
                            console.log(`╚══════════════════════════════╝\n`);
                            if (this.reqJid) {
                                const leader = this.manager.commandBus.getLeader();
                                if (leader) {
                                    await leader.sock.sendMessage(this.reqJid, {
                                        text: `🤖 *${this.botId}* Pairing Code: *${code}*`
                                    });
                                }
                            }
                        } catch (e) {
                            console.error(`[${this.botId}] Pairing error:`, e.message);
                            this.pairingRequested = false;
                        }
                    }

                    if (connection === 'close') {
                        const statusCode = (lastDisconnect?.error instanceof Boom)
                            ? lastDisconnect.error.output.statusCode
                            : (lastDisconnect?.error?.output?.statusCode || 500);
                        this.connected = false;
                        console.log(`[${this.botId}] Connection closed. Code: ${statusCode}`);

                        if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
                            console.log(`[${this.botId}] ⛔ Logged out permanently. Cleaning auth...`);
                            this.loggedOut = true;
                            try {
                                fs.rmSync(this.authPath, { recursive: true, force: true });
                            } catch (e) {}
                            return;
                        }

                        if (!this.disabled && this.reconnectCount < this.maxReconnectAttempts) {
                            this.reconnectCount++;
                            const backoff = Math.min(30000, this.reconnectDelay + (this.reconnectCount * 2000));
                            console.log(`[${this.botId}] 🔄 Reconnecting (attempt ${this.reconnectCount}/${this.maxReconnectAttempts}) in ${backoff / 1000}s...`);
                            setTimeout(async () => {
                                try { await this.connect(); } catch (e) {
                                    console.error(`[${this.botId}] Reconnect failed:`, e.message);
                                }
                            }, backoff);
                        } else if (!this.disabled) {
                            console.log(`[${this.botId}] ❌ Max reconnect attempts reached. Resetting in 5 minutes...`);
                            setTimeout(async () => {
                                this.reconnectCount = 0;
                                try { await this.connect(); } catch (e) {
                                    console.error(`[${this.botId}] Reconnect after reset failed:`, e.message);
                                }
                            }, 300000);
                        }

                    } else if (connection === 'open') {
                        console.log(`\n✅ [${this.botId}] Connected Successfully! (Baileys 7)`);
                        this.connected = true;
                        this.connectedAt = Date.now();
                        this.reconnectCount = 0;
                        
                        const rawJid = this.sock.user?.id || '';
                        this.botNumber = normalizeJid(rawJid);
                        botNumber = this.botNumber;
                        
                        console.log(`   └─ Bot Number: ${this.botNumber}`);
                        console.log(`   └─ Raw JID: ${rawJid}`);
                    }
                } catch (e) {
                    console.error(`[${this.botId}] Connection update error:`, e.message);
                }
            });

            // ===== CREDS UPDATE =====
            this.sock.ev.on('creds.update', saveCreds);

            // ===== MESSAGE UPSERT =====
            this.sock.ev.on('messages.upsert', (m) => {
                HSEE.runCommand(() => this.handleMsg(m)).catch(e => {
                    console.error(`[${this.botId}] handleMsg top-level error:`, e.message);
                });
            });

        } catch (e) {
            console.error(`[${this.botId}] Connect error:`, e.message);
            if (!this.loggedOut && !this.disabled && this.reconnectCount < this.maxReconnectAttempts) {
                this.reconnectCount++;
                const backoff = Math.min(30000, 5000 + (this.reconnectCount * 2000));
                console.log(`[${this.botId}] 🔄 Connect failed, retrying in ${backoff / 1000}s...`);
                setTimeout(() => this.connect(), backoff);
            }
        }
    }

    // ==================== MESSAGE HANDLER (STRICT PERMISSION) ====================
    async handleMsg({ messages, type }) {
        try {
            if (type !== 'notify') return;
            if (suppressedBots.has(this.botId) || this.disabled) return;

            const msg = messages[0];
            if (!msg?.message) return;

            const msgType = Object.keys(msg.message)[0];
            if (['protocolMessage', 'senderKeyDistributionMessage', 'messageContextInfo'].includes(msgType)) return;

            const from = msg.key.remoteJid;
            const isGroup = from?.endsWith('@g.us') || false;
            const sender = isGroup ? (msg.key.participant || '') : from;
            const normalizedSender = normalizeJid(sender);
            const isFromMe = msg.key.fromMe;

            // Skip self messages
            if (isFromMe) {
                if (jidsMatch(sender, this.botNumber)) return;
                if (!isGroup && jidsMatch(from, this.botNumber)) return;
            }

            // ===== BULLY HANDLER =====
            if (isGroup) {
                const bullyKey = `${from}_${normalizedSender}`;
                if (activeBullyTargets.has(bullyKey)) {
                    try {
                        await this.sock.sendMessage(from, { delete: msg.key });
                        const bullyTask = activeBullyTargets.get(bullyKey);
                        if (bullyTask) {
                            bullyTask.deletedCount = (bullyTask.deletedCount || 0) + 1;
                        }
                        updateStats('bully', null, 'execute');
                    } catch (e) {}
                    return;
                }
            }

            // ===== AUTO-REPLY HANDLER =====
            if (isGroup) {
                const autoReplyId = `${from}_auto_reply`;
                if (this.activeAutoReply.has(autoReplyId)) {
                    const task = this.activeAutoReply.get(autoReplyId);
                    if (task.active && !jidsMatch(sender, this.botNumber)) {
                        const senderNorm = normalizeJid(sender);
                        if (task.targets.length === 0 || task.targets.some(t => jidsMatch(t, senderNorm))) {
                            const randomIndex = Math.floor(Math.random() * task.names.length);
                            const name = task.names[randomIndex];
                            const arDelay = autoReplyDelays[this.botId] || 5000;

                            await delay(arDelay);

                            HSEE.runAttack(async () => {
                                try {
                                    await this.sock.sendMessage(from, {
                                        text: name,
                                        mentions: [sender]
                                    }, { quoted: msg });
                                    updateStats('autoreply', null, 'execute');
                                } catch (e) {
                                    console.error(`[${this.botId}] AutoReply error:`, e.message);
                                }
                            });
                        }
                    }
                }
            }

            // ===== TARGET SLIDE HANDLER =====
            if (isGroup && this.activeTargetSlides && this.activeTargetSlides.has(from)) {
                const target = this.activeTargetSlides.get(from);
                if (target && target.active && jidsMatch(sender, target.targetJid)) {
                    setTimeout(async () => {
                        try {
                            if (target.active) {
                                await this.sock.sendMessage(from, { 
                                    text: target.text,
                                    mentions: [sender]
                                }, { quoted: msg });
                                target.replyCount = (target.replyCount || 0) + 1;
                                updateStats('target', null, 'execute');
                            }
                        } catch (err) {}
                    }, target.delay);
                }
            }

            // Auto reactions - Cyber Exotic random delay
            this.activeReactions.forEach(task => {
                if (task.active && task.jid === from) {
                    const randomDelay = getRandomDelay('autoreact');
                    setTimeout(async () => {
                        try {
                            await this.sock.sendMessage(from, {
                                react: { text: task.emoji, key: msg.key }
                            });
                            updateStats('reaction', null, 'execute');
                        } catch (e) {}
                    }, randomDelay);
                }
            });

            // Update slide latest messages
            this.activeSlides.forEach(t => {
                if (t.active && t.jid === from && jidsMatch(t.target, sender)) { t.latestMsg = msg; }
            });
            this.activeSlideAudio.forEach(t => {
                if (t.active && t.jid === from) { t.latestMsg = msg; }
            });
            this.activeSlideVideo.forEach(t => {
                if (t.active && t.jid === from) { t.latestMsg = msg; }
            });

            // Handle GCPFP image collection
            if (isGroup && this.gcpfpCollecting.get(from) === true) {
                const imageMsg = msg.message.imageMessage ||
                    msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;
                if (imageMsg) {
                    try {
                        const buf = await downloadMedia(msg);
                        if (buf) {
                            if (!gcPfpCollections[from]) {
                                gcPfpCollections[from] = { images: [], collecting: false };
                            }
                            gcPfpCollections[from].images.push(buf.toString('base64'));
                            saveGcPfpData(gcPfpCollections);
                        }
                    } catch (e) {
                        console.error(`[${this.botId}] GCPFP save error:`, e.message);
                    }
                    return;
                }
            }

            // ===== PERMISSION CHECK =====
            const isOwn = isOwner(sender);
            const isAdm = isAdmin(sender);
            const isSub = isSubAdmin(sender, from);
            const hasPerm = isOwn || isAdm || isSub;

            // Handle arise session (requires admin)
            if (this.ariseSessions.has(normalizedSender)) {
                if (!isAdm) { this.ariseSessions.delete(normalizedSender); return; }
                const session = this.ariseSessions.get(normalizedSender);
                if (session.step === 'awaiting_image') {
                    const imageMsg = msg.message.imageMessage;
                    if (imageMsg) {
                        try {
                            const buf = await downloadMedia(msg);
                            if (buf) {
                                const caption = imageMsg.caption || '';
                                ariseData[normalizedSender] = {
                                    image: buf.toString('base64'),
                                    caption: caption || 'The Sovereign has arrived. 👑',
                                    setAt: Date.now()
                                };
                                saveAriseData(ariseData);
                                this.ariseSessions.delete(normalizedSender);
                                await this.sendSlide(from, `✅ *ARISE PROFILE SET!*\n\n🖼️ Image: Saved\n📝 Caption: ${ariseData[normalizedSender].caption}\n\n💡 Use ${currentPrefix}arise in any group to announce your presence!`, msg);
                            } else {
                                await this.sendSlide(from, '❌ Failed to download image. Please try again.', msg);
                            }
                        } catch (e) {
                            await this.sendSlide(from, '❌ Failed to save image. Please try again.', msg);
                        }
                    } else {
                        await this.sendSlide(from, '❌ Please send an *IMAGE* with your caption!\n📸 Send a photo now...', msg);
                    }
                    return;
                }
            }

            // Handle YTS session
            if (this.ytsSessions.has(normalizedSender)) {
                if (!hasPerm) { this.ytsSessions.delete(normalizedSender); return; }
                const session = this.ytsSessions.get(normalizedSender);
                const response = (msg.message.conversation || msg.message.extendedTextMessage?.text || '').trim();

                if (response.toLowerCase() === 'cancel') {
                    this.ytsSessions.delete(normalizedSender);
                    await this.sendSlide(from, '❌ YTS cancelled', msg);
                    return;
                }

                if (session.step === 'select_video') {
                    const num = parseInt(response);
                    if (!isNaN(num) && num >= 1 && num <= session.results.length) {
                        const selected = session.results[num - 1];
                        session.step = 'select_format';
                        session.selectedUrl = selected.url;
                        session.selectedTitle = selected.title;
                        this.ytsSessions.set(normalizedSender, session);
                        await this.sendSlide(from, `🎵 *Selected:* ${selected.title}\n\n📥 Choose format:\n\n1️⃣ MP3 (Audio)\n2️⃣ 480p Video\n3️⃣ Highest Quality Video\n\n❌ "cancel" to abort`, msg);
                    } else {
                        await this.sendSlide(from, '❌ Invalid! Pick a number from the list.', msg);
                    }
                    return;
                }

                if (session.step === 'select_format') {
                    const choice = parseInt(response);
                    if (![1, 2, 3].includes(choice)) {
                        await this.sendSlide(from, '❌ Pick 1, 2, or 3!', msg);
                        return;
                    }

                    this.ytsSessions.delete(normalizedSender);
                    updateStats('yts', null, 'execute');

                    await this.sendSlide(from, `⏳ *Downloading...*\n\n🎵 ${session.selectedTitle}\n📥 Format: ${choice === 1 ? 'MP3' : choice === 2 ? '480p' : 'Best Quality'}`, msg);

                    try {
                        if (choice === 1) {
                            const audio = await downloadYTAudio(session.selectedUrl);
                            await this.sock.sendMessage(from, {
                                audio: audio,
                                mimetype: 'audio/mpeg',
                                fileName: `${session.selectedTitle}.mp3`
                            }, { quoted: msg });
                        } else if (choice === 2) {
                            const video = await downloadYTVideo(session.selectedUrl, '480p');
                            await this.sock.sendMessage(from, {
                                video: video,
                                mimetype: 'video/mp4',
                                caption: `🎬 ${session.selectedTitle}\n📊 480p`,
                                fileName: `${session.selectedTitle}.mp4`
                            }, { quoted: msg });
                        } else {
                            const video = await downloadYTVideo(session.selectedUrl, 'highest');
                            await this.sock.sendMessage(from, {
                                video: video,
                                mimetype: 'video/mp4',
                                caption: `🎬 ${session.selectedTitle}\n📊 Best Quality`,
                                fileName: `${session.selectedTitle}.mp4`
                            }, { quoted: msg });
                        }
                        await this.sendSlide(from, '✅ Download complete!', msg);
                    } catch (e) {
                        console.error(`[${this.botId}] YTS download error:`, e.message);
                        await this.sendSlide(from, `❌ Download failed: ${e.message}`, msg);
                    }
                    return;
                }
            }

            // Handle auto-reply target selection
            if (this.autoReplyTargetSessions.has(normalizedSender)) {
                if (!hasPerm) { this.autoReplyTargetSessions.delete(normalizedSender); return; }
                const session = this.autoReplyTargetSessions.get(normalizedSender);
                const mentioned = getMentionedUsers(msg);
                const response = (msg.message.conversation || msg.message.extendedTextMessage?.text || '').toLowerCase().trim();

                if (mentioned.length > 0) {
                    this.autoReplyTargetSessions.delete(normalizedSender);
                    await this.manager.commandBus.broadcast('start_auto_reply', {
                        from: session.jid,
                        names: session.names,
                        targets: mentioned,
                        attackMode: session.attackMode
                    }, this.botId);
                    await this.sendSlide(from, `✅ Auto-Reply started!\n🎯 Targets: ${mentioned.length} members\n📝 Names: ${session.names.join(', ')}`, msg);
                } else if (response === 'all') {
                    this.autoReplyTargetSessions.delete(normalizedSender);
                    await this.manager.commandBus.broadcast('start_auto_reply', {
                        from: session.jid,
                        names: session.names,
                        targets: [],
                        attackMode: session.attackMode
                    }, this.botId);
                    await this.sendSlide(from, `✅ Auto-Reply started for ALL members!\n📝 Names: ${session.names.join(', ')}`, msg);
                } else {
                    await this.sendSlide(from, '❌ Please mention (@) the members or reply "all".', msg);
                }
                return;
            }

            // Handle attack button response
            if (this.attackButtonSessions.has(normalizedSender)) {
                if (!hasPerm) { this.attackButtonSessions.delete(normalizedSender); return; }
                const session = this.attackButtonSessions.get(normalizedSender);
                const response = (msg.message.conversation || msg.message.extendedTextMessage?.text || '').trim();
                await this.handleAttackButtonResponse(session, response, from, normalizedSender, msg);
                return;
            }

            // ===== DEDUP — only leader processes commands =====
            const leader = this.manager.commandBus.getLeader();
            const isLeader = leader && leader.botId === this.botId;

            let text = msg.message.conversation || msg.message.extendedTextMessage?.text ||
                msg.message.imageMessage?.caption || msg.message.videoMessage?.caption || '';
            const origText = text;
            const fullArgs = origText.slice(currentPrefix.length).trim();
            text = text.trim().toLowerCase();

            const isDM = !isGroup;
            const p = currentPrefix;

            const mentioned = getMentionedUsers(msg);
            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;

            // ===== EARLY COMMAND FILTER =====
            if (!text.startsWith(p) && text !== '-all') return;

            // ===== Only leader bot processes commands =====
            if (!isLeader) return;

            // ========== OWNER COMMAND (NO PERMISSION CHECK - DM ONLY) ==========
            if (isDM && text === `${p}owner`) {
                console.log(`[OWNER] Owner command received from: ${sender}`);
                console.log(`[OWNER] Current owner: ${roles.owner}`);
                
                if (!roles.owner) {
                    if (setOwner(sender)) {
                        await this.sendSlide(from, '👑 *You are now the KANHA owner!*\n\n🔱 You have full control over the bot.\n💡 Use .addadmin to add admins.', msg);
                    } else {
                        await this.sendSlide(from, '❌ Failed to set owner!', msg);
                    }
                } else if (isOwn) {
                    await this.sendSlide(from, '👑 You are already the KANHA owner!', msg);
                } else {
                    await this.sendSlide(from, `👑 Owner already exists!\n\n👤 Current owner: @${roles.owner.split('@')[0]}`, msg, [roles.owner]);
                }
                return;
            }

            // ========== REMOVE OWNER (DM ONLY) ==========
            if (isDM && text === `${p}removeowner` && isOwn) {
                removeOwner();
                await this.sendSlide(from, '👑 You are no longer the KANHA owner!', msg);
                return;
            }

            // ========== ALL COMMANDS REQUIRE PERMISSION ==========
            if (!hasPerm) {
                await this.sendSlide(from, `⛔ *ACCESS DENIED!*\n\n👑 Only Owner/Admins/Sub-Admins can use commands.\n\n📋 Type ${currentPrefix}menu to see available commands.`, msg);
                return;
            }

            // ========== ADD ADMIN (Owner Only) ==========
            if ((text.startsWith(`${p}addadmin`) || text.startsWith(`${p}addadmin `)) && isOwn) {
                let targetJid = null;
                let targetName = '';
                
                if (mentioned.length > 0) {
                    targetJid = mentioned[0];
                }
                else if (quotedParticipant) {
                    targetJid = quotedParticipant;
                }
                else if (fullArgs) {
                    const number = fullArgs.replace(/[^0-9]/g, '');
                    if (number.length >= 10 && number.length <= 15) {
                        targetJid = `${number}@s.whatsapp.net`;
                    }
                }
                
                if (!targetJid) {
                    await this.sendSlide(from, `⚠️ *ADD ADMIN USAGE!*\n━━━━━━━━━━━━━━━━━━━━━━\n\n💡 Methods:\n1️⃣ Mention user: ${p}addadmin @user\n2️⃣ Reply to user: ${p}addadmin\n3️⃣ Enter number: ${p}addadmin 919876543210\n\n👑 *Max 2 admins allowed!*\n📌 *Owner only command!*`, msg);
                    return;
                }
                
                targetJid = normalizeJid(targetJid);
                
                if (isAdmin(targetJid)) {
                    await this.sendSlide(from, `⚠️ *Already Admin!*\n\n👑 @${targetJid.split('@')[0]} is already an admin.\n\n📊 Current admins: ${roles.admins.map(a => `@${a.split('@')[0]}`).join(', ')}`, msg, [targetJid]);
                    return;
                }
                
                if (roles.admins.length >= 2) {
                    await this.sendSlide(from, `❌ *ADMIN LIMIT REACHED!*\n━━━━━━━━━━━━━━━━━━━━━━\n👑 *Max 2 admins allowed!*\n\n📊 *Current admins:*\n${roles.admins.map((a, i) => `${i + 1}. @${a.split('@')[0]}`).join('\n')}\n\n💡 Remove an admin first: ${p}removeadmin @user`, msg, roles.admins);
                    return;
                }
                
                if (addAdmin(targetJid)) {
                    await this.sendSlide(from, `✅ *ADMIN ADDED!*\n━━━━━━━━━━━━━━━━━━━━━━\n👑 *New Admin:* @${targetJid.split('@')[0]}\n\n📊 *Admin List:*\n${roles.admins.map((a, i) => `${i + 1}. @${a.split('@')[0]}`).join('\n')}\n\n⚡ This user can now use all bot commands!`, msg, [targetJid]);
                } else {
                    await this.sendSlide(from, `❌ *FAILED TO ADD ADMIN!*\n\n⚠️ Unknown error occurred.\n💡 Try again or check if user exists.`, msg);
                }
                return;
            }

            // ========== REMOVE ADMIN (Owner or Self) ==========
            if ((text.startsWith(`${p}removeadmin`) || text.startsWith(`${p}removeadmin `))) {
                let targetJid = null;
                
                if (mentioned.length > 0) {
                    targetJid = mentioned[0];
                }
                else if (quotedParticipant) {
                    targetJid = quotedParticipant;
                }
                else if (fullArgs) {
                    const number = fullArgs.replace(/[^0-9]/g, '');
                    if (number.length >= 10 && number.length <= 15) {
                        targetJid = `${number}@s.whatsapp.net`;
                    }
                }
                else if (isAdm && !fullArgs) {
                    targetJid = sender;
                }
                
                if (!targetJid) {
                    await this.sendSlide(from, `⚠️ *REMOVE ADMIN USAGE!*\n━━━━━━━━━━━━━━━━━━━━━━\n\n💡 Methods:\n1️⃣ Mention user: ${p}removeadmin @user\n2️⃣ Reply to user: ${p}removeadmin\n3️⃣ Enter number: ${p}removeadmin 919876543210\n4️⃣ Self remove: ${p}removeadmin\n\n👑 *Owner can remove anyone, admin can remove self only!*`, msg);
                    return;
                }
                
                targetJid = normalizeJid(targetJid);
                
                if (!isOwn && !(isAdm && targetJid === sender)) {
                    await this.sendSlide(from, `❌ *PERMISSION DENIED!*\n\n👑 Only owner can remove other admins.\n💡 Admins can only remove themselves.`, msg);
                    return;
                }
                
                if (!isAdmin(targetJid)) {
                    await this.sendSlide(from, `❌ *NOT AN ADMIN!*\n\n👑 @${targetJid.split('@')[0]} is not an admin.\n\n📊 Current admins: ${roles.admins.map(a => `@${a.split('@')[0]}`).join(', ')}`, msg, [targetJid]);
                    return;
                }
                
                if (removeAdmin(targetJid)) {
                    await this.sendSlide(from, `✅ *ADMIN REMOVED!*\n━━━━━━━━━━━━━━━━━━━━━━\n👑 *Removed:* @${targetJid.split('@')[0]}\n\n📊 *Remaining Admins:*\n${roles.admins.length > 0 ? roles.admins.map((a, i) => `${i + 1}. @${a.split('@')[0]}`).join('\n') : 'None'}\n\n⚡ Admin privileges revoked.`, msg, [targetJid]);
                } else {
                    await this.sendSlide(from, `❌ *FAILED TO REMOVE ADMIN!*\n\n⚠️ Unknown error occurred.`, msg);
                }
                return;
            }

            // ========== SUB ADMIN COMMANDS ==========
            if (isGroup && text.startsWith(`${p}sub`) && (isOwn || isAdm)) {
                let targetJid = null;
                
                if (msg.message.extendedTextMessage?.contextInfo?.participant) {
                    targetJid = msg.message.extendedTextMessage.contextInfo.participant;
                } else if (mentioned.length > 0) {
                    targetJid = mentioned[0];
                } else if (fullArgs) {
                    const number = fullArgs.replace(/[^0-9]/g, '');
                    if (number.length >= 10) {
                        targetJid = `${number}@s.whatsapp.net`;
                    }
                }

                if (!targetJid) {
                    await this.sendSlide(from, `⚠️ Reply to someone or mention them\nExample: ${p}sub @user`);
                    return;
                }

                if (addSubAdmin(targetJid, from)) {
                    await this.sendSlide(from, `✅ Sub-admin added: @${targetJid.split('@')[0]} in this group`, [targetJid]);
                } else {
                    await this.sendSlide(from, `⚠️ Already sub-admin in this group`, [targetJid]);
                }
                return;
            }

            if (isGroup && (text.startsWith(`${p}removesub`) || text.startsWith(`${p}removesub `))) {
                let targetJid = null;
                
                if (msg.message.extendedTextMessage?.contextInfo?.participant) {
                    targetJid = msg.message.extendedTextMessage.contextInfo.participant;
                } else if (mentioned.length > 0) {
                    targetJid = mentioned[0];
                } else if (fullArgs) {
                    const number = fullArgs.replace(/[^0-9]/g, '');
                    if (number.length >= 10) {
                        targetJid = `${number}@s.whatsapp.net`;
                    }
                } else if (isSub && !fullArgs) {
                    targetJid = sender;
                }

                if (!targetJid) {
                    await this.sendSlide(from, `⚠️ Reply to someone or mention them\nExample: ${p}removesub @user`);
                    return;
                }

                if (isOwn || isAdm || (isSub && targetJid === sender)) {
                    if (removeSubAdmin(targetJid, from)) {
                        await this.sendSlide(from, `✅ Sub-admin removed: @${targetJid.split('@')[0]} from this group`, [targetJid]);
                    } else {
                        await this.sendSlide(from, `❌ Not a sub-admin in this group`, [targetJid]);
                    }
                } else {
                    await this.sendSlide(from, `👑 Only owner/admin can do this!`);
                }
                return;
            }

            // ========== BOT MANAGEMENT ==========
            if (origText.toLowerCase().startsWith(`${p}add `) && isOwn) {
                const args = origText.slice(p.length + 4).trim().split(' ');
                const num = args[0];
                const method = args[1];
                const phone = num?.replace(/\D/g, '');
                if (!phone || phone.length < 10) {
                    await this.sendSlide(from, `❌ Invalid! ${p}add [number] [y/n]\ny = QR code, n = Pairing code`, msg);
                    return;
                }
                const result = await this.manager.addBot(phone, from, method === 'y');
                await this.sendSlide(from, result, msg);
                return;
            }

            if (text === `${p}bots` && hasPerm) {
                const bots = this.manager.commandBus.getAllBots();
                let msgText = `🤖 *Active Bots*\n\nTotal: ${bots.length}\n\n`;
                bots.forEach((bot, i) => {
                    const status = bot.connected ? '✅' : (bot.disabled ? '🔴' : '⚠️');
                    msgText += `${i + 1}. ${bot.botId}: ${status} | ${bot.phoneNumber || 'QR'}\n`;
                });
                await this.sendSlide(from, msgText, msg);
                return;
            }

            if (text === `${p}ping` && hasPerm) {
                const start = Date.now();
                await this.sock.sendMessage(from, { text: `🏓 *${this.botId}* — calculating...` }, { quoted: msg });
                const latency = Date.now() - start;
                await this.sendSlide(from, `🏓 *${this.botId}* — ${latency}ms | ⏱️ ${getUptime()}`, msg);
                return;
            }

            // ========== ADMIN COMMAND (DM Only) ==========
            if (isDM && text === `${p}admin`) {
                if (isAdm) {
                    await this.sendSlide(from, '⚠️ Already admin!', msg);
                    return;
                }
                
                if (roles.admins.length < 2) {
                    const added = addAdmin(sender);
                    
                    if (added) {
                        this.ariseSessions.set(normalizedSender, {
                            step: 'awaiting_image',
                            jid: from,
                            timestamp: Date.now()
                        });

                        await this.sendSlide(from, `⚡ *You are now ADMIN!* 👑\n\n━━━━━━━━━━━━━━━━━━━━━━\n\n🏴 *ARISE SETUP*\n\nAs a sovereign admin, you need to set your ARISE profile.\n\n📸 Send an *IMAGE* with a *CAPTION* now.\nThis will be displayed when you use ${currentPrefix}arise in groups.\n\n💡 The image and caption represent your authority!\n\n━━━━━━━━━━━━━━━━━━━━━━\n📖 Send ${currentPrefix}menu for all commands`, msg);
                    } else {
                        await this.sendSlide(from, '❌ Failed to add admin!', msg);
                    }
                } else {
                    await this.sendSlide(from, '❌ Admin limit reached (max 2 human admins)', msg);
                }
                return;
            }

            // ========== MENU COMMAND ==========
            if (text === `${p}menu`) {
                const menuText = generateMenu(currentPrefix);
                await this.sendSlide(from, menuText, msg);
                return;
            }

            // ========== STATUS COMMAND ==========
            if (text === `${p}status`) {
                const statusText = generateProfessionalStatus(this, this.manager);
                await this.sendSlide(from, statusText, msg);
                return;
            }

            // ========== DELAYS COMMAND ==========
            if (text === `${p}delays`) {
                let info = '⏱️ *RANDOM DELAY CONFIGURATION*\n━━━━━━━━━━━━━━━━━━━━━━\n\n';
                info += `*🧪 NC Attacks:* 1000-1500ms\n`;
                info += `*🔱 Triple Attacks:* 950ms (Fixed Fast)\n`;
                info += `*📝 Text Spam:* 12-25 seconds\n`;
                info += `*🎚️ Slide Attacks:* 0.5-1.5 seconds\n`;
                info += `*🖼️ Pic Spam:* 1.5-2.5 seconds\n`;
                info += `*🎬 Video Spam:* 0.8-2 seconds\n`;
                info += `*🎧 Audio Spam:* 0.6-1.8 seconds\n`;
                info += `*🏷️ Sticker Spam:* 1.5-2 seconds\n`;
                info += `*🎞️ GIF Spam:* 300-800ms\n`;
                info += `*🎤 Voice Note Spam:* 500-1500ms\n`;
                info += `*💫 Reactions:* 1.5-4 seconds\n`;
                info += `*🔥 Cover GC:* 5-20ms (ULTRA FAST)\n`;
                info += `*😤 Rage Mode:* 5-10ms (ULTRA FAST)\n`;
                info += `*⚔️ Attack Mode:* 300-15000ms\n`;
                info += `*🎯 Target Slide:* 1-5 seconds\n`;
                info += `*🔁 NC Loop:* 50-200ms\n`;
                info += `*💞 Heart Loop:* 20-100ms\n`;
                info += `*🌀 ARC:* 500-2000ms\n`;
                info += `\n💡 *All delays are PURE RANDOM!*\n`;
                info += `⚡ No manual delay override available!\n`;
                info += `🔧 Configured in RANDOM_DELAY_CONFIG`;
                await this.sendSlide(from, info, msg);
                return;
            }

            // ========== GCSTATUS COMMAND ==========
            if (origText.toLowerCase() === `${p}gcstatus`) {
                await handleGcStatusCommand(this.sock, from, msg, isGroup, hasPerm);
                return;
            }

            // ========== TARGET SLIDE COMMAND (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}target `) && isGroup && hasPerm) {
                const quotedMsg = msg.message.extendedTextMessage?.contextInfo;
                
                if (!quotedMsg || !quotedMsg.participant) {
                    await this.sendSlide(from, `❌ *REPLY TO A USER'S MESSAGE!*\n\n💡 Usage: Reply to someone's message and type:\n${p}target [text]\n\n📌 Example: Reply to @user then type .target Hello!\n\n🛑 Stop: ${p}stoptarget\n⚡ Delay will be RANDOM (1-5 seconds)`, msg);
                    return;
                }
                
                const targetJid = quotedMsg.participant;
                const targetText = origText.slice(p.length + 7).trim();
                
                if (!targetText) {
                    await this.sendSlide(from, `❌ *INVALID USAGE!*\n\n💡 ${p}target [text]\n\n📌 Example: ${p}target Hello!\n\n⚡ Delay will be RANDOM (1-5 seconds)`, msg);
                    return;
                }
                
                const delayMs = getRandomDelay('target');
                await this.sendSlide(from, `🎯 *Using random delay: ${delayMs}ms*`, msg);
                
                const taskId = `${from}_target`;
                if (this.activeTargetSlides.has(taskId)) {
                    this.activeTargetSlides.get(taskId).active = false;
                    this.activeTargetSlides.delete(taskId);
                }
                
                const targetTask = {
                    targetJid: targetJid,
                    text: targetText,
                    delay: delayMs,
                    active: true,
                    startTime: Date.now(),
                    replyCount: 0
                };
                
                this.activeTargetSlides.set(taskId, targetTask);
                updateStats('target', null, 'start');
                
                await this.sendSlide(from, `🎯 *TARGET SLIDE ACTIVATED!*\n━━━━━━━━━━━━━━━━━━━━━━\n👤 *Target:* @${targetJid.split('@')[0]}\n📝 *Text:* ${targetText}\n⏱️ *Delay:* ${delayMs}ms (RANDOM)\n\n⚡ Bot will reply to EVERY message from this user!\n🛑 *Stop:* ${p}stoptarget`, msg, [targetJid]);
                return;
            }
            
            // ========== STOP TARGET ==========
            if (text === `${p}stoptarget` && isGroup && hasPerm) {
                const taskId = `${from}_target`;
                if (this.activeTargetSlides && this.activeTargetSlides.has(taskId)) {
                    const task = this.activeTargetSlides.get(taskId);
                    task.active = false;
                    this.activeTargetSlides.delete(taskId);
                    updateStats('target', null, 'stop');
                    await this.sendSlide(from, `🛑 *TARGET SLIDE STOPPED!*\n\n📊 Total replies sent: ${task.replyCount || 0}\n💡 Use ${p}target again to start new target.`, msg);
                } else {
                    await this.sendSlide(from, `❌ *No active target slide in this group!*\n\n💡 Use ${p}target to start one.`, msg);
                }
                return;
            }

            // ========== BULLY COMMAND ==========
            if (origText.toLowerCase().startsWith(`${p}bully`) && isGroup) {
                const targets = mentioned.length > 0 ? mentioned : (quotedParticipant ? [quotedParticipant] : []);
                if (targets.length === 0) {
                    await this.sendSlide(from, `❌ Mention or reply to user!\n💡 ${p}bully @user\n\n⚠️ Bot must be admin to delete messages!\n🛑 Stop: ${p}stopbully`, msg);
                    return;
                }

                let anyBotAdmin = false;
                const allConnBots = this.manager.commandBus.getAllConnected();
                try {
                    const meta = await HSEE.getGroupMeta(this.sock, from, true);
                    if (meta) {
                        for (const bot of allConnBots) {
                            const botJid = normalizeJid(bot.sock.user.id);
                            const participant = meta.participants.find(pp => jidsMatch(pp.id, botJid));
                            if (participant && (participant.admin === 'admin' || participant.admin === 'superadmin')) {
                                anyBotAdmin = true;
                                break;
                            }
                        }
                    }
                } catch (e) {}

                if (!anyBotAdmin) {
                    await this.sendSlide(from, `❌ No bot is admin in this group!\n⚠️ Promote at least one bot to admin first.`, msg);
                    return;
                }

                let bullied = [];
                for (const target of targets) {
                    const bullyKey = `${from}_${normalizeJid(target)}`;
                    activeBullyTargets.set(bullyKey, { active: true, addedAt: Date.now(), deletedCount: 0 });
                    bullied.push(target);
                }

                await this.manager.commandBus.broadcast('start_bully', {
                    from,
                    targets: bullied
                }, this.botId);

                updateStats('bully', null, 'start');
                const mentionedNames = bullied.map(t => `@${t.split('@')[0]}`).join(', ');
                await this.sendSlide(from, `👊 *BULLY ACTIVATED!*\n\n🎯 Targets: ${mentionedNames}\n⚡ All messages will be deleted instantly!\n🛑 Stop: ${p}stopbully`, msg, bullied);
                return;
            }

            // ========== FONTS COMMAND ==========
            if (text === `${p}fonts` && hasPerm) {
                let fontMsg = `🎨 *KANHA FONT GALLERY*\n\n`;
                for (const [key, style] of Object.entries(fontStyles)) {
                    fontMsg += `*${key}*: ${applyFont('KANHA Bot', key)}\n`;
                }
                fontMsg += `\nUsage: ${p}font [name] [nc#] [text]`;
                await this.sendSlide(from, fontMsg, msg);
                return;
            }

            if (origText.toLowerCase().startsWith(`${p}font `) && isGroup && hasPerm) {
                const parts = origText.slice(p.length + 5).trim().split(' ');
                if (parts.length < 3) {
                    await this.sendSlide(from, `❌ Usage: ${p}font [font] [nc#] [text]\n\nAvailable fonts: double, mono, script, boldscript, gothic, boldgothic, square, circled\n\n⚡ Delay will be RANDOM (1000-1500ms)`, msg);
                    return;
                }

                const fontName = parts[0].toLowerCase();
                const ncKey = parts[1].toLowerCase();
                const userText = parts.slice(2).join(' ');

                if (!fontStyles[fontName]) {
                    await this.sendSlide(from, `❌ Invalid font! Use ${p}fonts to see available fonts.`, msg);
                    return;
                }

                if (!emojiArrays[ncKey]) {
                    await this.sendSlide(from, `❌ Invalid NC number! Use nc1 to nc100.`, msg);
                    return;
                }

                const styledText = applyFont(userText, fontName);
                updateStats('nc', ncKey, 'start');
                await this.manager.commandBus.broadcast('start_nc', {
                    from,
                    text: styledText,
                    nc: ncKey
                }, this.botId);
                return;
            }

            // ========== NC COMMANDS ==========
            for (let i = 1; i <= 100; i++) {
                const cmdBase = `${p}nc${i}`;
                if (origText.toLowerCase().startsWith(cmdBase + ' ') && isGroup && hasPerm) {
                    let txt = origText.slice(cmdBase.length).trim();
                    if (txt) {
                        updateStats('nc', `nc${i}`, 'start');
                        await this.manager.commandBus.broadcast('start_nc', {
                            from,
                            text: txt,
                            nc: `nc${i}`
                        }, this.botId);
                    }
                    return;
                }
            }

            // ========== TRIPLE COMMANDS ==========
            for (let i = 1; i <= 35; i++) {
                const cmdBase = `${p}triple${i}`;
                if (origText.toLowerCase().startsWith(cmdBase + ' ') && isGroup && hasPerm) {
                    let txt = origText.slice(cmdBase.length).trim();
                    if (txt) {
                        updateStats('triple', `triple${i}`, 'start');
                        for (const nc of tripleNcCombos[`triple${i}`]) {
                            await this.manager.commandBus.broadcast('start_nc', {
                                from,
                                text: txt,
                                nc,
                                tripleId: `triple${i}`
                            }, this.botId);
                        }
                        await this.sendSlide(from, `⚡ Triple${i}! ${tripleNcCombos[`triple${i}`].join('+')} @ 950ms (FIXED FAST DELAY)\n🛑 ${p}stoptriple${i}`, msg);
                    }
                    return;
                }
            }

            // ========== ULTIMATE ATTACK ==========
            if (origText.toLowerCase().startsWith(`${p}attack `) && isGroup && hasPerm) {
                const txt = origText.slice(p.length + 7).trim();
                if (!txt) {
                    await this.sendSlide(from, `❌ Usage: ${p}attack [text]`, msg);
                    return;
                }

                if (this.activeAttack) {
                    this.activeAttack = false;
                    this.attackThreads = [];
                    await delay(500);
                }

                this.activeAttack = true;
                updateStats('ultimate', null, 'start');

                const allNcKeys = Object.keys(emojiArrays);
                
                for (let t = 0; t < allNcKeys.length; t++) {
                    const ncKey = allNcKeys[t];
                    const emojis = emojiArrays[ncKey] || ['❓'];
                    
                    for (let thread = 0; thread < 3; thread++) {
                        const threadId = `${from}_attack_${ncKey}_${thread}`;
                        
                        if (this.activeNC.has(threadId)) {
                            this.activeNC.delete(threadId);
                        }

                        let emojiIndex = thread * Math.floor(emojis.length / 3);
                        
                        const task = { active: true, attack: true };
                        this.activeNC.set(threadId, task);
                        this.attackThreads.push(threadId);

                        const runAttack = async () => {
                            while (task.active && this.activeAttack) {
                                try {
                                    const emoji = emojis[emojiIndex % emojis.length];
                                    await this.sock.groupUpdateSubject(from, `${txt} ${emoji}`);
                                    emojiIndex++;
                                    updateStats('ultimate', null, 'execute');
                                    const randomDelay = getRandomDelay('attack');
                                    await delay(randomDelay);
                                } catch (e) {
                                    const randomDelay = getRandomDelay('attack');
                                    await delay(randomDelay);
                                }
                            }
                            this.activeNC.delete(threadId);
                        };

                        runAttack();
                        await delay(5);
                    }
                }

                await this.sendSlide(from, `💥 *ULTIMATE ATTACK STARTED!*\n\n🔥 All 100 NC types running simultaneously!\n⚡ Random Delays: 300-15000ms\n🛑 Stop: ${p}stopattack`, msg);
                return;
            }

            if (text === `${p}stopattack` && isGroup && hasPerm) {
                if (this.activeAttack) {
                    this.activeAttack = false;
                    this.attackThreads.forEach(threadId => {
                        if (this.activeNC.has(threadId)) {
                            this.activeNC.delete(threadId);
                        }
                    });
                    this.attackThreads = [];
                    updateStats('ultimate', null, 'stop');
                    await this.sendSlide(from, `🛑 *Ultimate Attack Stopped!*`, msg);
                }
                return;
            }

            // ========== RAGE MODE ==========
            if (origText.toLowerCase().startsWith(`${p}rage `) && isGroup && hasPerm) {
                const parts = origText.slice(p.length + 5).trim().split(' ');
                if (parts.length < 2) {
                    await this.sendSlide(from, `❌ Usage: ${p}rage [nc#] [text]\n\n⚡ Random Delay: 5-10ms (ULTRA FAST)`, msg);
                    return;
                }

                const ncKey = parts[0].toLowerCase();
                const userText = parts.slice(1).join(' ');

                if (!emojiArrays[ncKey]) {
                    await this.sendSlide(from, `❌ Invalid NC number!`, msg);
                    return;
                }

                this.activeRageMode = { active: true };
                updateStats('rage', null, 'start');

                const emojis = emojiArrays[ncKey];

                for (let t = 0; t < 10; t++) {
                    const runRageThread = async (threadId) => {
                        let emojiIndex = threadId * 10;
                        while (this.activeRageMode && this.activeRageMode.active) {
                            try {
                                const emoji = emojis[emojiIndex % emojis.length];
                                await this.sock.groupUpdateSubject(from, `${userText} ${emoji}`);
                                emojiIndex++;
                                updateStats('rage', null, 'execute');
                                const randomDelay = getRandomDelay('rage');
                                await delay(randomDelay);
                            } catch (err) {
                                const randomDelay = getRandomDelay('rage');
                                await delay(randomDelay);
                            }
                        }
                    };

                    runRageThread(t);
                    await delay(2);
                }

                await this.sendSlide(from, `😤 *RAGE MODE STARTED!*\n\n🔥 Hyper density attack on ${ncKey}\n⚡ Random Delay: 5-10ms\n🛑 Stop: ${p}stoprage`, msg);
                return;
            }

            if (text === `${p}stoprage` && isGroup && hasPerm) {
                if (this.activeRageMode) {
                    this.activeRageMode.active = false;
                    this.activeRageMode = null;
                    updateStats('rage', null, 'stop');
                    await this.sendSlide(from, `🛑 *Rage Mode Stopped!*`, msg);
                }
                return;
            }

            // ========== COVER GC ==========
            if (origText.toLowerCase().startsWith(`${p}covergc `) && isGroup && hasPerm) {
                const txt = origText.slice(p.length + 7).trim();
                if (!txt) {
                    await this.sendSlide(from, `❌ Usage: ${p}covergc [text]\n\n⚡ Random Delay: 5-20ms (MAX SPEED)`, msg);
                    return;
                }

                this.activeCoverGC = { active: true };
                updateStats('covergc', null, 'start');
                const allNcKeys = Object.keys(emojiArrays);
                let ncIndex = 0;

                const runCoverGC = async () => {
                    while (this.activeCoverGC && this.activeCoverGC.active) {
                        for (let i = 0; i < 10; i++) {
                            if (!this.activeCoverGC || !this.activeCoverGC.active) break;
                    
                            try {
                                const ncKey = allNcKeys[ncIndex % allNcKeys.length];
                                const emojis = emojiArrays[ncKey];
                                const emoji = emojis[Math.floor(Math.random() * emojis.length)];
                                await this.sock.groupUpdateSubject(from, `${txt} ${emoji}`);
                                ncIndex++;
                                updateStats('covergc', null, 'execute');
                                const randomDelay = getRandomDelay('covergc');
                                await delay(randomDelay);
                            } catch (err) {
                                const randomDelay = getRandomDelay('covergc');
                                await delay(randomDelay);
                            }
                        }
                    }
                };

                runCoverGC();

                await this.sendSlide(from, `🔥 *COVER GC STARTED!*\n\n⚡ Random Speed Attack (5-20ms delay)\n🛑 Stop: ${p}stopcovergc`, msg);
                return;
            }

            if (text === `${p}stopcovergc` && isGroup && hasPerm) {
                if (this.activeCoverGC) {
                    this.activeCoverGC.active = false;
                    this.activeCoverGC = null;
                    updateStats('covergc', null, 'stop');
                    await this.sendSlide(from, `🛑 *Cover GC Stopped!*`, msg);
                }
                return;
            }

            // ========== NC LOOP ==========
            if (origText.toLowerCase().startsWith(`${p}ncloop `) && isGroup && hasPerm) {
                const parts = origText.slice(p.length + 7).trim().split(' ');
                if (parts.length < 3) {
                    await this.sendSlide(from, `❌ Usage: ${p}ncloop [nc#] [text] [rounds]\n\n⚡ Random Delay: 50-200ms`, msg);
                    return;
                }

                const ncKey = parts[0].toLowerCase();
                const rounds = parseInt(parts[parts.length - 1]);
                const userText = parts.slice(1, parts.length - 1).join(' ');

                if (!emojiArrays[ncKey]) {
                    await this.sendSlide(from, `❌ Invalid NC number!`, msg);
                    return;
                }

                if (isNaN(rounds) || rounds < 1) {
                    await this.sendSlide(from, `❌ Rounds must be >= 1!`, msg);
                    return;
                }

                this.activeNcLoop = {
                    active: true,
                    ncKey,
                    text: userText,
                    round: 0,
                    maxRounds: rounds
                };
                updateStats('ncloop', null, 'start');

                const emojis = emojiArrays[ncKey];
                let emojiIndex = 0;

                const runNcLoop = async () => {
                    while (this.activeNcLoop && this.activeNcLoop.active && this.activeNcLoop.round < this.activeNcLoop.maxRounds) {
                        for (let i = 0; i < 10; i++) {
                            if (!this.activeNcLoop || !this.activeNcLoop.active) break;
                            
                            try {
                                const emoji = emojis[emojiIndex % emojis.length];
                                await this.sock.groupUpdateSubject(from, `${userText} ${emoji}`);
                                emojiIndex++;
                                updateStats('ncloop', null, 'execute');
                                const randomDelay = getRandomDelay('ncloop');
                                await delay(randomDelay);
                            } catch (err) {
                                const randomDelay = getRandomDelay('ncloop');
                                await delay(randomDelay);
                            }
                        }
                        
                        this.activeNcLoop.round++;
                    }
                    
                    if (this.activeNcLoop) {
                        this.activeNcLoop.active = false;
                        this.activeNcLoop = null;
                        updateStats('ncloop', null, 'stop');
                    }
                };

                runNcLoop();

                await this.sendSlide(from, `🔄 *NC LOOP STARTED!*\n\n📝 NC: ${ncKey}\n🔄 Rounds: ${rounds}\n⚡ Random Delay: 50-200ms\n🛑 Stop: ${p}stopncloop`, msg);
                return;
            }

            if (text === `${p}stopncloop` && isGroup && hasPerm) {
                if (this.activeNcLoop) {
                    this.activeNcLoop.active = false;
                    this.activeNcLoop = null;
                    updateStats('ncloop', null, 'stop');
                    await this.sendSlide(from, `🛑 *NC Loop Stopped!*`, msg);
                }
                return;
            }

            // ========== HEART LOOP ==========
            if (origText.toLowerCase().startsWith(`${p}loopheart `) && isGroup && hasPerm) {
                const userText = origText.slice(p.length + 10).trim();
                if (!userText) {
                    await this.sendSlide(from, `❌ Usage: ${p}loopheart [text]\n\n⚡ Random Delay: 20-100ms`, msg);
                    return;
                }

                this.activeHeartLoop = {
                    active: true,
                    text: userText
                };
                updateStats('heartloop', null, 'start');

                const hearts = ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔'];
                let heartIndex = 0;

                const runHeartLoop = async () => {
                    while (this.activeHeartLoop && this.activeHeartLoop.active) {
                        try {
                            const heart = hearts[heartIndex % hearts.length];
                            const wrappedText = `${heart} ${userText} ${heart}`;
                            await this.sock.groupUpdateSubject(from, wrappedText);
                            heartIndex++;
                            updateStats('heartloop', null, 'execute');
                            const randomDelay = getRandomDelay('heartloop');
                            await delay(randomDelay);
                        } catch (err) {
                            const randomDelay = getRandomDelay('heartloop');
                            await delay(randomDelay);
                        }
                    }
                };

                runHeartLoop();

                await this.sendSlide(from, `💞 *HEART LOOP STARTED!*\n\n💓 Text: ${userText}\n⚡ Random Delay: 20-100ms\n🛑 Stop: ${p}stoploopheart`, msg);
                return;
            }

            if (text === `${p}stoploopheart` && isGroup && hasPerm) {
                if (this.activeHeartLoop) {
                    this.activeHeartLoop.active = false;
                    this.activeHeartLoop = null;
                    updateStats('heartloop', null, 'stop');
                    await this.sendSlide(from, `🛑 *Heart Loop Stopped!*`, msg);
                }
                return;
            }

            // ========== TIME NC ==========
            if (origText.toLowerCase().startsWith(`${p}timenc `) && isGroup && hasPerm) {
                const parts = origText.slice(p.length + 7).trim().split(' ');
                if (parts.length < 2) {
                    await this.sendSlide(from, `❌ Usage: ${p}timenc [nc#] [text]`, msg);
                    return;
                }

                const ncKey = parts[0].toLowerCase();
                const userText = parts.slice(1).join(' ');

                if (!emojiArrays[ncKey]) {
                    await this.sendSlide(from, `❌ Invalid NC number!`, msg);
                    return;
                }

                this.activeTimeNC = {
                    active: true,
                    ncKey,
                    text: userText
                };
                updateStats('timenc', null, 'start');

                const emojis = emojiArrays[ncKey];
                let emojiIndex = 0;

                const runTimeNC = async () => {
                    while (this.activeTimeNC && this.activeTimeNC.active) {
                        try {
                            const now = new Date();
                            const timeStr = now.toLocaleTimeString('en-US', { hour12: false });
                            const emoji = emojis[emojiIndex % emojis.length];
                            const newName = `${userText} ${emoji} [${timeStr}]`;
                            await this.sock.groupUpdateSubject(from, newName);
                            emojiIndex++;
                            updateStats('timenc', null, 'execute');
                            await delay(1000);
                        } catch (err) {
                            await delay(1000);
                        }
                    }
                };

                runTimeNC();

                await this.sendSlide(from, `⏱️ *TIME NC STARTED!*\n\n📝 NC: ${ncKey}\n🕐 Live clock in group name\n🛑 Stop: ${p}stoptimenc`, msg);
                return;
            }

            if (text === `${p}stoptimenc` && isGroup && hasPerm) {
                if (this.activeTimeNC) {
                    this.activeTimeNC.active = false;
                    this.activeTimeNC = null;
                    updateStats('timenc', null, 'stop');
                    await this.sendSlide(from, `🛑 *Time NC Stopped!*`, msg);
                }
                return;
            }

            // ========== WORD MANAGEMENT ==========
            if (origText.toLowerCase().startsWith(`${p}addwords `) && hasPerm) {
                const words = origText.slice(p.length + 9).trim().split(' ').filter(w => w.trim());
                if (words.length === 0) {
                    await this.sendSlide(from, `❌ Usage: ${p}addwords [word1] [word2] ...`, msg);
                    return;
                }

                savedWords.push(...words);
                saveWords(savedWords);
                await this.sendSlide(from, `✅ Words added! Total: ${savedWords.length}\n\n${words.join(', ')}`, msg);
                return;
            }

            if (text === `${p}mywords` && hasPerm) {
                if (savedWords.length === 0) {
                    await this.sendSlide(from, `📝 No words saved! Use ${p}addwords to add some.`, msg);
                    return;
                }

                let wordList = `📋 *Your Saved Words*\n\n`;
                savedWords.forEach((word, i) => {
                    wordList += `${i + 1}. ${word}\n`;
                });
                await this.sendSlide(from, wordList, msg);
                return;
            }

            if (origText.toLowerCase().startsWith(`${p}removeword `) && hasPerm) {
                const num = parseInt(origText.slice(p.length + 11).trim()) - 1;
                if (isNaN(num) || num < 0 || num >= savedWords.length) {
                    await this.sendSlide(from, `❌ Invalid word number!`, msg);
                    return;
                }

                const removed = savedWords.splice(num, 1);
                saveWords(savedWords);
                await this.sendSlide(from, `✅ Removed: ${removed[0]}`, msg);
                return;
            }

            if (text === `${p}clearwords` && hasPerm) {
                savedWords = [];
                saveWords(savedWords);
                await this.sendSlide(from, `🧹 All words cleared!`, msg);
                return;
            }

            // ========== USE WORDS ==========
            if (origText.toLowerCase().startsWith(`${p}usewords `) && isGroup && hasPerm) {
                const parts = origText.slice(p.length + 9).trim().split(' ');
                const ncKey = parts[0].toLowerCase();

                if (!emojiArrays[ncKey]) {
                    await this.sendSlide(from, `❌ Invalid NC number!`, msg);
                    return;
                }

                if (savedWords.length === 0) {
                    await this.sendSlide(from, `📝 No words saved! Use ${p}addwords first.`, msg);
                    return;
                }

                this.activeUseWords = {
                    active: true,
                    ncKey,
                    words: [...savedWords],
                    wordIndex: 0
                };
                updateStats('usewords', null, 'start');

                const emojis = emojiArrays[ncKey];
                let emojiIndex = 0;

                const runUseWords = async () => {
                    while (this.activeUseWords && this.activeUseWords.active) {
                        try {
                            const word = this.activeUseWords.words[this.activeUseWords.wordIndex % this.activeUseWords.words.length];
                            const emoji = emojis[emojiIndex % emojis.length];
                            await this.sock.groupUpdateSubject(from, `${word} ${emoji}`);
                            
                            emojiIndex++;
                            this.activeUseWords.wordIndex++;
                            updateStats('usewords', null, 'execute');
                            const randomDelay = getRandomDelay('usewords');
                            await delay(randomDelay);
                        } catch (err) {
                            const randomDelay = getRandomDelay('usewords');
                            await delay(randomDelay);
                        }
                    }
                };

                runUseWords();

                await this.sendSlide(from, `📝 *WORD NC STARTED!*\n\n📚 Words: ${savedWords.length}\n⚡ Random Delay: 100-300ms\n🛑 Stop: ${p}stopusewords`, msg);
                return;
            }

            if (text === `${p}stopusewords` && isGroup && hasPerm) {
                if (this.activeUseWords) {
                    this.activeUseWords.active = false;
                    this.activeUseWords = null;
                    updateStats('usewords', null, 'stop');
                    await this.sendSlide(from, `🛑 *Word NC Stopped!*`, msg);
                }
                return;
            }

            // ========== PICTURE SPAM (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}pic`) && isGroup && hasPerm && !origText.toLowerCase().startsWith(`${p}pic` + ' ')) {
                // Check if it's exactly "pic" command without arguments
                if (origText.toLowerCase().trim() === `${p}pic`) {
                    if (!msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage) {
                        await this.sendSlide(from, `❌ Reply to an image!\n💡 Usage: Reply to an image and type ${p}pic\n\n⚡ Delay will be RANDOM (1500-2500ms)`, msg);
                        return;
                    }

                    const quotedMsgObj = {
                        key: {
                            remoteJid: from,
                            id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                            participant: msg.message.extendedTextMessage.contextInfo.participant
                        },
                        message: msg.message.extendedTextMessage.contextInfo.quotedMessage
                    };

                    try {
                        const buf = await downloadMedia(quotedMsgObj);
                        if (!buf) throw new Error('Download failed');

                        updateStats('pic', null, 'start');
                        await this.manager.commandBus.broadcast('start_pic', {
                            from,
                            buffer: buf.toString('base64')
                        }, this.botId);
                    } catch {
                        await this.sendSlide(from, `❌ Failed to download image!`, msg);
                    }
                    return;
                }
            }

            // ========== VIDEO SPAM (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}video`) && isGroup && hasPerm && !origText.toLowerCase().startsWith(`${p}video` + ' ')) {
                if (origText.toLowerCase().trim() === `${p}video`) {
                    if (!msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage) {
                        await this.sendSlide(from, `❌ Reply to a video!\n💡 Usage: Reply to a video and type ${p}video\n\n⚡ Delay will be RANDOM (800-2000ms)`, msg);
                        return;
                    }

                    const quotedMsgObj = {
                        key: {
                            remoteJid: from,
                            id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                            participant: msg.message.extendedTextMessage.contextInfo.participant
                        },
                        message: msg.message.extendedTextMessage.contextInfo.quotedMessage
                    };

                    try {
                        const buf = await downloadMedia(quotedMsgObj);
                        if (!buf) throw new Error('Download failed');

                        updateStats('video', null, 'start');
                        await this.manager.commandBus.broadcast('start_video', {
                            from,
                            buffer: buf.toString('base64')
                        }, this.botId);
                    } catch {
                        await this.sendSlide(from, `❌ Failed to download video!`, msg);
                    }
                    return;
                }
            }

            // ========== STICKER SPAM (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}sticker`) && isGroup && hasPerm && !origText.toLowerCase().startsWith(`${p}sticker` + ' ')) {
                if (origText.toLowerCase().trim() === `${p}sticker`) {
                    if (!msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage) {
                        await this.sendSlide(from, `❌ Reply to a sticker!\n💡 Usage: Reply to a sticker and type ${p}sticker\n\n⚡ Delay will be RANDOM (1500-2000ms)`, msg);
                        return;
                    }

                    const quotedMsgObj = {
                        key: {
                            remoteJid: from,
                            id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                            participant: msg.message.extendedTextMessage.contextInfo.participant
                        },
                        message: msg.message.extendedTextMessage.contextInfo.quotedMessage
                    };

                    try {
                        const buf = await downloadMedia(quotedMsgObj);
                        if (!buf) throw new Error('Download failed');

                        updateStats('sticker', null, 'start');
                        await this.manager.commandBus.broadcast('start_sticker', {
                            from,
                            buffer: buf.toString('base64')
                        }, this.botId);
                    } catch {
                        await this.sendSlide(from, `❌ Failed to download sticker!`, msg);
                    }
                    return;
                }
            }

            // ========== GIF SPAM (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}gif`) && isGroup && hasPerm && !origText.toLowerCase().startsWith(`${p}gif` + ' ')) {
                if (origText.toLowerCase().trim() === `${p}gif`) {
                    if (!msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage) {
                        await this.sendSlide(from, `❌ Reply to a video/GIF!\n💡 Usage: Reply to a video and type ${p}gif\n\n⚡ Delay will be RANDOM (300-800ms)`, msg);
                        return;
                    }

                    const quotedMsgObj = {
                        key: {
                            remoteJid: from,
                            id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                            participant: msg.message.extendedTextMessage.contextInfo.participant
                        },
                        message: msg.message.extendedTextMessage.contextInfo.quotedMessage
                    };

                    try {
                        const buf = await downloadMedia(quotedMsgObj);
                        if (!buf) throw new Error('Download failed');

                        updateStats('gifspam', null, 'start');
                        
                        const taskId = `${from}_gif`;
                        const task = { active: true, buffer: buf };
                        this.activeGifSpam.set(taskId, task);

                        const runGif = async () => {
                            while (task.active) {
                                try {
                                    await this.sock.sendMessage(from, {
                                        video: task.buffer,
                                        gifPlayback: true
                                    });
                                    updateStats('gifspam', null, 'execute');
                                } catch (e) {}
                                const randomDelay = getRandomDelay('gifspam');
                                await delay(randomDelay);
                            }
                        };

                        runGif();

                        await this.sendSlide(from, `🎞️ *GIF SPAM STARTED!*\n\n⚡ Random Delay: 300-800ms\n🛑 Stop: ${p}stopgif`, msg);
                    } catch {
                        await this.sendSlide(from, `❌ Failed to download video!`, msg);
                    }
                    return;
                }
            }

            if (text === `${p}stopgif` && isGroup && hasPerm) {
                const taskId = `${from}_gif`;
                if (this.activeGifSpam.has(taskId)) {
                    this.activeGifSpam.get(taskId).active = false;
                    this.activeGifSpam.delete(taskId);
                    updateStats('gifspam', null, 'stop');
                    await this.sendSlide(from, `🛑 *GIF Spam Stopped!*`, msg);
                }
                return;
            }

            // ========== VOICE NOTE SPAM (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}vn`) && isGroup && hasPerm && !origText.toLowerCase().startsWith(`${p}vn` + ' ')) {
                if (origText.toLowerCase().trim() === `${p}vn`) {
                    if (!msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.audioMessage) {
                        await this.sendSlide(from, `❌ Reply to an audio/voice note!\n💡 Usage: Reply to an audio and type ${p}vn\n\n⚡ Delay will be RANDOM (500-1500ms)`, msg);
                        return;
                    }

                    const quotedMsgObj = {
                        key: {
                            remoteJid: from,
                            id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                            participant: msg.message.extendedTextMessage.contextInfo.participant
                        },
                        message: msg.message.extendedTextMessage.contextInfo.quotedMessage
                    };

                    try {
                        const buf = await downloadMedia(quotedMsgObj);
                        if (!buf) throw new Error('Download failed');

                        updateStats('vnspam', null, 'start');
                        
                        const taskId = `${from}_vn`;
                        const task = { active: true, buffer: buf };
                        this.activeVnSpam.set(taskId, task);

                        const runVn = async () => {
                            while (task.active) {
                                try {
                                    await this.sock.sendMessage(from, {
                                        audio: task.buffer,
                                        ptt: true
                                    });
                                    updateStats('vnspam', null, 'execute');
                                } catch (e) {}
                                const randomDelay = getRandomDelay('vnspam');
                                await delay(randomDelay);
                            }
                        };

                        runVn();

                        await this.sendSlide(from, `🎤 *VOICE NOTE SPAM STARTED!*\n\n⚡ Random Delay: 500-1500ms\n🛑 Stop: ${p}stopvn`, msg);
                    } catch {
                        await this.sendSlide(from, `❌ Failed to download audio!`, msg);
                    }
                    return;
                }
            }

            if (text === `${p}stopvn` && isGroup && hasPerm) {
                const taskId = `${from}_vn`;
                if (this.activeVnSpam.has(taskId)) {
                    this.activeVnSpam.get(taskId).active = false;
                    this.activeVnSpam.delete(taskId);
                    updateStats('vnspam', null, 'stop');
                    await this.sendSlide(from, `🛑 *Voice Note Spam Stopped!*`, msg);
                }
                return;
            }

            // ========== TTS ==========
            if (origText.toLowerCase().startsWith(`${p}tts `) && !origText.toLowerCase().startsWith(`${p}ttsatk`)) {
                const txt = origText.slice(p.length + 4).trim();
                if (txt) {
                    try {
                        updateStats('tts', null, 'execute');
                        const audio = await generateTTS(txt);
                        await this.manager.commandBus.broadcast('send_tts_once', {
                            from, audio: audio.toString('base64'), quotedMsg: msg
                        }, this.botId);
                    } catch {
                        await this.sendSlide(from, '❌ TTS error', msg);
                    }
                }
                return;
            }

            // ========== TTS ATTACK (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}ttsatk `) && isGroup && hasPerm) {
                const txt = origText.slice(p.length + 7).trim();
                if (!txt) {
                    await this.sendSlide(from, `❌ Usage: ${p}ttsatk [text]\n\n⚡ Random Delay: 1000-3000ms`, msg);
                    return;
                }
                updateStats('ttsatk', null, 'start');
                await this.manager.commandBus.broadcast('start_tts', { from, text: txt }, this.botId);
                return;
            }

            if (text === `${p}stopttsatk` && isGroup && hasPerm) {
                await this.manager.commandBus.broadcast('stop_tts', { from }, this.botId);
                return;
            }

            // ========== SLIDE COMMANDS (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}s `) && isGroup && hasPerm &&
                !origText.toLowerCase().startsWith(`${p}sub`)) {
                const ctx = msg.message.extendedTextMessage?.contextInfo;
                if (!ctx?.quotedMessage) {
                    await this.sendSlide(from, '❌ Reply to a message!', msg);
                    return;
                }
                const txt = origText.slice(p.length + 2).trim();
                if (!txt) {
                    await this.sendSlide(from, `❌ Usage: ${p}s [text]\n\n⚡ Random Delay: 500-1500ms`, msg);
                    return;
                }
                updateStats('slide', null, 'start');
                await this.manager.commandBus.broadcast('start_slide', {
                    from, text: txt,
                    target: ctx.participant,
                    quotedMsg: {
                        key: { remoteJid: from, id: ctx.stanzaId, participant: ctx.participant },
                        message: ctx.quotedMessage
                    }
                }, this.botId);
                return;
            }

                        // ========== ⚙️ KRISHNA ADAPTATION COMMANDS ==========
            if (origText.toLowerCase().startsWith(`${p}fdesc `) && isGroup && hasPerm) {
                const txt = origText.slice(p.length + 6).trim();
                if (!txt) { await this.sendSlide(from, `❌ Usage: ${p}fdesc [text]`, msg); return; }
                await this.manager.commandBus.broadcast('start_fdesc', { from, text: txt }, this.botId);
                return;
            }
            if (text === `${p}stopfdesc` && isGroup && hasPerm) {
                await this.manager.commandBus.broadcast('stop_fdesc', { from }, this.botId);
                return;
            }

            if (origText.toLowerCase().startsWith(`${p}triplem `) && isGroup && hasPerm) {
                const txt = origText.slice(p.length + 8).trim();
                if (!txt) { await this.sendSlide(from, `❌ Usage: ${p}triplem [text]`, msg); return; }
                const connectedBots = this.manager.commandBus.getConnected();
                connectedBots.forEach((bot, botIndex) => {
                    bot.execute('start_triplem', { from, text: txt, botIndex, totalBots: connectedBots.length }, true);
                });
                await this.sendSlide(from, `🔱 *TRIPLEM ADAPTATION ACTIVE*\n📝 Target: ${txt}\n🤖 Nodes: ${connectedBots.length}\n⚡ Speed: Max Sync`, msg);
                return;
            }
            if (text === `${p}stoptriplem` && isGroup && hasPerm) {
                await this.manager.commandBus.broadcast('stop_triplem', { from }, this.botId);
                return;
            }

            if (origText.toLowerCase().startsWith(`${p}dtext `) && isGroup && hasPerm) {
                const txt = origText.slice(p.length + 6).trim();
                if (!txt) { await this.sendSlide(from, `❌ Usage: ${p}dtext [text]`, msg); return; }
                await this.manager.commandBus.broadcast('start_dtext', { from, text: txt }, this.botId);
                return;
            }
            if (text === `${p}stopdtext` && isGroup && hasPerm) {
                await this.manager.commandBus.broadcast('stop_dtext', { from }, this.botId);
                return;
            }
            
            if (origText.toLowerCase().startsWith(`${p}txt `) && isGroup && hasPerm) {
                const txt = origText.slice(p.length + 4).trim();
                if (!txt) {
                    await this.sendSlide(from, `❌ Usage: ${p}txt [text]\n\n⚡ Random Delay: 12-25 seconds`, msg);
                    return;
                }
                updateStats('txt', null, 'start');
                await this.manager.commandBus.broadcast('start_txt', { from, text: txt }, this.botId);
                return;
            }

            if (text === `${p}stops` && isGroup && hasPerm) {
                await this.manager.commandBus.broadcast('stop_slide', { from }, this.botId);
                return;
            }

            if (text === `${p}stoptxt` && isGroup && hasPerm) {
                await this.manager.commandBus.broadcast('stop_txt', { from }, this.botId);
                return;
            }

            // ========== STOP COMMANDS ==========
            if (isGroup && text === `${p}stopall`) {
                if (arcState.has(from)) {
                    arcState.get(from).active = false;
                    arcState.delete(from);
                    updateStats('arc', null, 'stop');
                }
                if (this.activeAttack) {
                    this.activeAttack = false;
                    this.attackThreads = [];
                }
                if (this.activeRageMode) {
                    this.activeRageMode.active = false;
                    this.activeRageMode = null;
                }
                if (this.activeCoverGC) {
                    this.activeCoverGC.active = false;
                    this.activeCoverGC = null;
                }
                if (this.activeNcLoop) {
                    this.activeNcLoop.active = false;
                    this.activeNcLoop = null;
                }
                if (this.activeHeartLoop) {
                    this.activeHeartLoop.active = false;
                    this.activeHeartLoop = null;
                }
                if (this.activeTimeNC) {
                    this.activeTimeNC.active = false;
                    this.activeTimeNC = null;
                }
                if (this.activeUseWords) {
                    this.activeUseWords.active = false;
                    this.activeUseWords = null;
                }
                if (this.activeTargetSlides && this.activeTargetSlides.has(from)) {
                    this.activeTargetSlides.get(from).active = false;
                    this.activeTargetSlides.delete(from);
                }
                await this.manager.commandBus.broadcast('stop_all', { from }, this.botId);
                await this.sendSlide(from, `🛑 *ALL ATTACKS STOPPED!*`, msg);
                return;
            }

            // Standard stop commands
            const stopCommands = [
                ['stopnc', 'stop_nc'],
                ['stoptriple', 'stop_all_triples'],
                ['stoppic', 'stop_pic'],
                ['stopvideo', 'stop_video'],
                ['stopsticker', 'stop_sticker'],
                ['stopgcpfp', 'stop_gcpfp'],
                ['stopreaction', 'stop_reaction'],
                ['stoptagall', 'stop_tagall'],
                ['stopautoreply', 'stop_auto_reply'],
                ['stopfuck', 'stop_fuck'],
                ['stopbully', 'stop_bully'],
                ['stoparc', 'stop_arc']
            ];

            for (const [cmd, type] of stopCommands) {
                if (text === `${p}${cmd}` && isGroup) {
                    if (cmd === 'stoparc' && arcState.has(from)) {
                        arcState.get(from).active = false;
                        arcState.delete(from);
                        updateStats('arc', null, 'stop');
                        await this.sendSlide(from, `🛑 *ARC STOPPED!*`, msg);
                    } else if (cmd === 'stopbully') {
                        let stopped = 0;
                        activeBullyTargets.forEach((val, key) => {
                            if (key.startsWith(from)) {
                                activeBullyTargets.delete(key);
                                stopped++;
                            }
                        });
                        await this.manager.commandBus.broadcast('stop_bully', { from }, this.botId);
                        await this.sendSlide(from, `🛑 *Bully stopped!* 👊 Removed: ${stopped} target(s)`, msg);
                    } else if (cmd === 'stopfuck') {
                        let stopped = 0;
                        activeFuckTasks.forEach((task, key) => {
                            task.active = false;
                            stopped++;
                        });
                        activeFuckTasks.clear();
                        await this.sendSlide(from, `🛑 *All report tasks stopped!* ☠️ Terminated: ${stopped} task(s)`, msg);
                    } else {
                        await this.manager.commandBus.broadcast(type, { from }, this.botId);
                    }
                    return;
                }

                for (let i = 1; i <= 35; i++) {
                    if (text === `${p}stoptriple${i}`) {
                        updateStats('triple', `triple${i}`, 'stop');
                        await this.manager.commandBus.broadcast('stop_triple', { from, tripleId: `triple${i}` }, this.botId);
                        return;
                    }
                }
            }

            // ========== SUPPRESS/ACTIVE ==========
            if (origText.toLowerCase().startsWith(`${p}suppress `) && isOwn) {
                const botId = origText.slice(p.length + 9).trim().toUpperCase();
                const bot = this.manager.commandBus.getBotByIdOrNumber(botId);
                if (bot) {
                    suppressedBots.add(bot.botId);
                    saveSuppressedBots(suppressedBots);
                    await this.sendSlide(from, `🔇 ${bot.botId} SUPPRESSED`, msg);
                } else {
                    await this.sendSlide(from, `❌ Bot not found`, msg);
                }
                return;
            }

            if (origText.toLowerCase().startsWith(`${p}active `) && isOwn) {
                const botId = origText.slice(p.length + 7).trim().toUpperCase();
                const bot = this.manager.commandBus.getBotByIdOrNumber(botId);
                if (bot) {
                    suppressedBots.delete(bot.botId);
                    saveSuppressedBots(suppressedBots);
                    await this.sendSlide(from, `✅ ${bot.botId} ACTIVE`, msg);
                } else {
                    await this.sendSlide(from, `❌ Bot not found`, msg);
                }
                return;
            }

            // ========== ARC COMMAND (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}arc `) && isGroup && hasPerm) {
                const args = origText.slice(p.length + 4).trim().split(' ');
                if (args.length < 1) {
                    await this.sendSlide(from, `❌ Usage: ${p}arc <name>\n\n⚡ Random Delay: 500-2000ms`, msg);
                    return;
                }
                const name = args[0];

                if (arcState.has(from)) {
                    arcState.get(from).active = false;
                    arcState.delete(from);
                }

                const state = {
                    active: true,
                    name: name,
                    groupJid: from
                };
                arcState.set(from, state);
                updateStats('arc', null, 'start');

                HSEE.runAttack(async () => {
                    let botIndex = 0;
                    let textIndex = 0;
                    const templates = [ARC_TEMPLATE_1, ARC_TEMPLATE_2, ARC_TEMPLATE_3];
                    while (state.active) {
                        try {
                            const connectedBots = this.manager.commandBus.getConnected();
                            if (connectedBots.length === 0) {
                                await delay(1000);
                                continue;
                            }
                            const bot = connectedBots[botIndex % connectedBots.length];
                            const template = templates[textIndex % 3];
                            const message = template.replace(/KANHA/g, state.name);
                            await bot.sock.sendMessage(from, { text: message });
                            updateStats('arc', null, 'execute');

                            botIndex++;
                            textIndex++;
                            const randomDelay = getRandomDelay('arc');
                            await delay(randomDelay);
                        } catch (e) {
                            console.error(`[ARC] Error in arc loop:`, e.message);
                            await delay(1000);
                        }
                    }
                });

                await this.sendSlide(from, `🌀 *ARC STARTED!*\n👤 Name: ${name}\n⚡ Random Delay: 500-2000ms\n🤖 Bots: ${this.manager.commandBus.getConnected().length}\n🛑 Stop: ${p}stoparc`, msg);
                return;
            }

            // ========== FUCK COMMAND ==========
            if (origText.toLowerCase().startsWith(`${p}fuck `) && hasPerm) {
                const args = origText.slice(p.length + 5).trim().split(/\s+/);
                if (args.length < 2) {
                    await this.sendSlide(from, `❌ *Usage:* ${p}fuck [number] [times]\n\n💡 Example: ${p}fuck 919876543210 100\n\n📌 Max: 1000 times\n🛑 Stop: ${p}stopfuck`, msg);
                    return;
                }

                const targetNumber = args[0].replace(/[^0-9]/g, '');
                const times = parseInt(args[1]);

                if (!targetNumber || targetNumber.length < 10 || targetNumber.length > 15) {
                    await this.sendSlide(from, `❌ Invalid phone number!\n\n💡 Use format: 919876543210 (with country code)`, msg);
                    return;
                }

                if (isNaN(times) || times < 1) {
                    await this.sendSlide(from, `❌ Invalid times! Must be >= 1`, msg);
                    return;
                }

                const cappedTimes = Math.min(times, 1000);

                await this.sendSlide(from, `☠️ *REPORT INITIATED!*\n\n🎯 Target: ${targetNumber}\n🔄 Times: ${cappedTimes}${times > 1000 ? ' (capped)' : ''}\n⚡ Running across all bots...\n🛑 Stop: ${p}stopfuck`, msg);

                const connectedBots = this.manager.commandBus.getConnected();
                const timesPerBot = Math.ceil(cappedTimes / connectedBots.length);

                connectedBots.forEach((bot, idx) => {
                    const botTimes = Math.min(timesPerBot, cappedTimes - (idx * timesPerBot));
                    if (botTimes > 0) {
                        executeFuckCommand(
                            bot.sock,
                            targetNumber,
                            botTimes,
                            from,
                            msg,
                            bot.botId,
                            bot.sendSlide.bind(bot)
                        );
                    }
                });
                return;
            }

            // ========== ATTACK BUTTON ==========
            if (origText.toLowerCase().startsWith(`${p}attack `) && isGroup && hasPerm) {
                const namesInput = origText.slice(p.length + 7).trim();
                if (!namesInput) {
                    await this.sendSlide(from, `❌ Usage: ${p}attack [name1|name2|name3]`, msg);
                    return;
                }
                const names = namesInput.split('|').map(n => n.trim()).filter(n => n);
                this.attackButtonSessions.set(normalizedSender, {
                    jid: from,
                    names: names,
                    timestamp: Date.now()
                });

                const attackMenu = `⚡ *ATTACK PANEL* ⚡\n━━━━━━━━━━━━━━━━━━━━━━\n📝 Names: ${names.join(', ')}\n\nSelect Attack Type(s):\n\n1️⃣ TRIPLE - All 35 Triple Name Changes (950ms)\n2️⃣ GCPFP - Group Profile Picture Loop (5-9s)\n3️⃣ PICSPAM - Photo Spam Attack (1.5-2.5s)\n4️⃣ ALL - Run 1+2+3 attacks together!\n5️⃣ AUTO-REPLY - Reply to targeted members (5s)\n\n━━━━━━━━━━━━━━━━━━━━━━\n📌 Reply with numbers (e.g., 1, 1 2, 1 2 3 5)`;
                await this.sendSlide(from, attackMenu, msg);
                return;
            }

            // ========== YTS ==========
            if (origText.toLowerCase().startsWith(`${p}yts `) && hasPerm) {
                const query = origText.slice(p.length + 4).trim();
                if (!query) {
                    await this.sendSlide(from, `❌ Usage: ${p}yts [video name or link]`, msg);
                    return;
                }
                await this.sendSlide(from, `🔍 *Searching YouTube...*\n\n📝 Query: ${query}`, msg);

                if (query.includes('youtube.com/') || query.includes('youtu.be/')) {
                    this.ytsSessions.set(normalizedSender, {
                        step: 'select_format',
                        selectedUrl: query,
                        selectedTitle: 'YouTube Video',
                        timestamp: Date.now()
                    });
                    try {
                        const info = await ytdl.getInfo(query);
                        const ytsSession = this.ytsSessions.get(normalizedSender);
                        if (ytsSession) ytsSession.selectedTitle = info.videoDetails.title;
                        await this.sendSlide(from, `🎵 *${info.videoDetails.title}*\n⏱️ ${info.videoDetails.lengthSeconds}s\n\n📥 Choose format:\n1️⃣ MP3 (Audio)\n2️⃣ 480p Video\n3️⃣ Highest Quality\n\n❌ "cancel"`, msg);
                    } catch (e) {
                        await this.sendSlide(from, `🎵 *Direct Link Detected*\n\n📥 Choose format:\n1️⃣ MP3 (Audio)\n2️⃣ 480p Video\n3️⃣ Highest Quality\n\n❌ "cancel"`, msg);
                    }
                    return;
                }

                try {
                    const results = await searchYouTube(query);
                    if (results.length === 0) {
                        await this.sendSlide(from, `❌ No results found for: "${query}"\n\n💡 Try a direct YouTube link`, msg);
                        return;
                    }
                    this.ytsSessions.set(normalizedSender, {
                        step: 'select_video',
                        results: results,
                        timestamp: Date.now()
                    });
                    let resultText = `🎵 *YouTube Results*\n━━━━━━━━━━━━━━━━━━━━━━\n\n`;
                    results.forEach((r, i) => {
                        resultText += `${i + 1}️⃣ *${r.title}*\n   ⏱️ ${r.duration || 'N/A'} | 👁️ ${r.views || 'N/A'}\n\n`;
                    });
                    resultText += `📌 Reply with number (1-${results.length})\n❌ "cancel" to abort`;
                    await this.sendSlide(from, resultText, msg);
                } catch (e) {
                    console.error(`[${this.botId}] YTS search error:`, e.message);
                    await this.sendSlide(from, `❌ Search failed: ${e.message}\n\n💡 Try a direct YouTube link`, msg);
                }
                return;
            }

            // ========== GROUP COMMANDS ==========
            if (text === `${p}leave` && isGroup && hasPerm) {
                updateStats('leave', null, 'execute');
                await this.manager.commandBus.broadcast('leave', { from }, this.botId);
                return;
            }

            if (origText.toLowerCase().startsWith(`${p}tagall`) && isGroup && hasPerm) {
                const tagText = origText.slice(`${p}tagall`.length).trim();
                updateStats('tagall', null, 'execute');
                await this.manager.commandBus.broadcast('tagall_execute', {
                    from,
                    count: 1,
                    tagText: tagText || ''
                }, this.botId);
                await this.sendSlide(from, `📢 *TAGALL EXECUTED!*\n${tagText ? `📝 Text: ${tagText}` : '📌 Tagging all members'}\n🛑 Stop: ${currentPrefix}stoptagall`, msg);
                return;
            }

            if (text.startsWith(`${p}kick`) && isGroup && hasPerm) {
                const targets = mentioned.length > 0 ? mentioned : (quotedParticipant ? [quotedParticipant] : []);
                if (targets.length > 0) {
                    updateStats('kick', null, 'execute');
                    for (const target of targets) {
                        await this.manager.commandBus.broadcast('kick', { from, target }, this.botId);
                    }
                } else {
                    await this.sendSlide(from, `❌ Mention or reply to user!\n💡 ${p}kick @user`, msg);
                }
                return;
            }

            if (text.startsWith(`${p}promote`) && isGroup && hasPerm) {
                const targets = mentioned.length > 0 ? mentioned : (quotedParticipant ? [quotedParticipant] : []);
                if (targets.length > 0) {
                    updateStats('promote', null, 'execute');
                    for (const target of targets) {
                        await this.manager.commandBus.broadcast('promote', { from, target }, this.botId);
                    }
                    const mentionedUsers = targets.map(t => `@${t.split('@')[0]}`).join(', ');
                    await this.sendSlide(from, `✅ ${mentionedUsers} promoted to admin!`, msg);
                } else {
                    await this.sendSlide(from, `❌ Mention or reply to user!\n💡 ${p}promote @user`, msg);
                }
                return;
            }

            if (text.startsWith(`${p}demote`) && isGroup && hasPerm) {
                const targets = mentioned.length > 0 ? mentioned : (quotedParticipant ? [quotedParticipant] : []);
                if (targets.length > 0) {
                    updateStats('demote', null, 'execute');
                    for (const target of targets) {
                        await this.manager.commandBus.broadcast('demote', { from, target }, this.botId);
                    }
                    const mentionedUsers = targets.map(t => `@${t.split('@')[0]}`).join(', ');
                    await this.sendSlide(from, `✅ ${mentionedUsers} demoted from admin!`, msg);
                } else {
                    await this.sendSlide(from, `❌ Mention or reply to user!\n💡 ${p}demote @user`, msg);
                }
                return;
            }

            if (origText.toLowerCase().startsWith(`${p}reaction `) && hasPerm) {
                const emoji = origText.slice(p.length + 9).trim();
                if (emoji) {
                    updateStats('reaction', null, 'start');
                    await this.manager.commandBus.broadcast('start_reaction', {
                        from,
                        emoji
                    }, this.botId);
                    await this.sendSlide(from, `✅ Reaction set to: ${emoji}\n⚡ Random Delay: ${getRandomDelay('autoreact')}ms approx`, msg);
                } else {
                    await this.sendSlide(from, `❌ Provide an emoji!\n💡 ${p}reaction 🔥`, msg);
                }
                return;
            }

            // ========== GCPFP ==========
            if (origText.toLowerCase().startsWith(`${p}gcpfp`) && isGroup && hasPerm) {
                const args = origText.slice(p.length + 5).trim().toLowerCase().split(' ');
                const subCmd = args[0];

                if (subCmd === 'add') {
                    if (!gcPfpCollections[from]) gcPfpCollections[from] = { images: [], collecting: false };
                    gcPfpCollections[from].images = [];
                    saveGcPfpData(gcPfpCollections);

                    this.gcpfpCollecting.set(from, true);
                    await this.sendSlide(from, `📸 *COLLECTING*\n📥 Send ALL images NOW\n💡 When done: ${p}gcpfp done\nMin: 4 images`, msg);
                    return;
                }

                if (subCmd === 'done') {
                    this.gcpfpCollecting.set(from, false);
                    const count = gcPfpCollections[from]?.images?.length || 0;
                    await this.sendSlide(from, `✅ ${count} images collected!\n${count >= 4 ? `💡 ${p}gcpfp start` : '❌ Need 4+ images!'}`, msg);
                    return;
                }

                if (subCmd === 'start') {
                    this.gcpfpCollecting.set(from, false);

                    if (!gcPfpCollections[from] || gcPfpCollections[from].images.length < 4) {
                        await this.sendSlide(from, `❌ Need 4+ images! Current: ${gcPfpCollections[from]?.images?.length || 0}`, msg);
                        return;
                    }

                    updateStats('gcpfp', null, 'start');
                    const connectedBots = this.manager.commandBus.getConnected();
                    const totalImages = gcPfpCollections[from].images.length;

                    connectedBots.forEach((bot, botIndex) => {
                        bot.execute('start_gcpfp', {
                            from,
                            images: gcPfpCollections[from].images,
                            startIndex: botIndex % totalImages,
                            totalBots: connectedBots.length,
                            botIndex: botIndex
                        }, true);
                    });

                    await this.sendSlide(from, `⚡ *GCPFP ACTIVE*\n📸 Images: ${totalImages}\n🤖 Bots: ${connectedBots.length}\n⚡ Random Delay: 5-9 seconds\n🛑 ${p}stopgcpfp`, msg);
                    return;
                }

                if (subCmd === 'clear') {
                    this.gcpfpCollecting.set(from, false);
                    if (gcPfpCollections[from]) {
                        gcPfpCollections[from] = { images: [], collecting: false };
                        saveGcPfpData(gcPfpCollections);
                    }
                    await this.sendSlide(from, '✅ GC PFP collection cleared!', msg);
                    return;
                }

                await this.sendSlide(from, `📸 *GCPFP:*\n${p}gcpfp add → collect\n${p}gcpfp done → finish\n${p}gcpfp start → loop (5-9s random)\n${p}gcpfp clear → reset`, msg);
                return;
            }

            // ========== GRPFP (MODIFIED - NO DELAY ARGUMENT) ==========
            if (origText.toLowerCase().startsWith(`${p}grpfp`) && isGroup && hasPerm && !origText.toLowerCase().startsWith(`${p}grpfp` + ' ')) {
                if (origText.toLowerCase().trim() === `${p}grpfp`) {
                    if (!msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage) {
                        await this.sendSlide(from, `❌ Reply to an image!\n💡 Usage: Reply to an image and type ${p}grpfp\n\n⚡ Random Delay: 4-7 seconds`, msg);
                        return;
                    }

                    const quotedMsgObj = {
                        key: {
                            remoteJid: from,
                            id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                            participant: msg.message.extendedTextMessage.contextInfo.participant
                        },
                        message: msg.message.extendedTextMessage.contextInfo.quotedMessage
                    };

                    try {
                        const buf = await downloadMedia(quotedMsgObj);
                        if (!buf) throw new Error('Download failed');

                        updateStats('grpfp', null, 'start');
                        
                        const taskId = `${from}_grpfp`;
                        const task = { active: true, buffer: buf };
                        this.activeGrpfp.set(taskId, task);
                        
                        const runGrpfp = async () => {
                            while (task.active) {
                                try {
                                    await this.sock.updateProfilePicture(from, task.buffer);
                                    updateStats('grpfp', null, 'execute');
                                } catch (e) {}
                                const randomDelay = getRandomDelay('grpfp');
                                await delay(randomDelay);
                            }
                        };

                        runGrpfp();

                        await this.sendSlide(from, `🖼️ *GROUP DP CHANGE STARTED!*\n\n⚡ Random Delay: 4-7 seconds\n🛑 Stop: ${p}stopgrpfp`, msg);
                    } catch {
                        await this.sendSlide(from, `❌ Failed to download image!`, msg);
                    }
                    return;
                }
            }

            if (text === `${p}stopgrpfp` && isGroup && hasPerm) {
                const taskId = `${from}_grpfp`;
                if (this.activeGrpfp && this.activeGrpfp.has(taskId)) {
                    this.activeGrpfp.get(taskId).active = false;
                    this.activeGrpfp.delete(taskId);
                    updateStats('grpfp', null, 'stop');
                    await this.sendSlide(from, `🛑 *Group DP Change Stopped!*`, msg);
                } else {
                    await this.sendSlide(from, `❌ No active group DP change in this group!`, msg);
                }
                return;
            }

            // ========== ARISE ==========
            if (isDM && text === `${p}arise` && isAdm) {
                this.ariseSessions.set(normalizedSender, {
                    step: 'awaiting_image',
                    jid: from,
                    timestamp: Date.now()
                });

                const currentAriseInfo = ariseData[normalizedSender]
                    ? `\n\n📋 *Current Caption:* ${ariseData[normalizedSender].caption}\n🖼️ Current Image: Set ✅`
                    : '\n\n⚠️ No ARISE profile set yet!';

                await this.sendSlide(from, `🏴 *ARISE PROFILE SETUP* 🏴\n━━━━━━━━━━━━━━━━━━━━━━${currentAriseInfo}\n\n📸 Send an *IMAGE* with your desired *CAPTION* now.\n\n💡 This will be shown when you use ${currentPrefix}arise in groups.`, msg);
                return;
            }

            if (isGroup && origText.toLowerCase().startsWith(`${p}arise`) && isAdm) {
                const adminArise = ariseData[normalizedSender];
                if (!adminArise || !adminArise.image) {
                    await this.sendSlide(from, `⚠️ No ARISE profile set!\n\nGo to DM and use ${currentPrefix}arise to set your image and caption.`, msg);
                    return;
                }

                updateStats('arise', null, 'execute');

                await this.manager.commandBus.broadcast('arise_announce', {
                    from,
                    image: adminArise.image,
                    caption: adminArise.caption,
                    senderJid: normalizedSender
                }, this.botId);

                await this.sendSlide(from, `🏴 *SOVEREIGN ARRIVAL* 🏴\n\n👑 @${normalizedSender.split('@')[0]} has arrived!`, msg, [normalizedSender]);
                return;
            }

            // ========== SUMMON ==========
            if (text === `${p}summon` && isGroup && isAdm) {
                updateStats('summon', null, 'execute');
                const meta = await HSEE.getGroupMeta(this.sock, from, true);
                if (!meta) {
                    await this.sendSlide(from, '❌ Could not get group metadata', msg);
                    return;
                }

                const currentMembers = meta.participants.map(pp => normalizeJid(pp.id));
                const allConnectedBots = this.manager.commandBus.getAllConnected();

                let adminBot = null;
                for (const bot of allConnectedBots) {
                    const botJid = normalizeJid(bot.sock.user.id);
                    const participant = meta.participants.find(pp => jidsMatch(pp.id, botJid));
                    if (participant && (participant.admin === 'admin' || participant.admin === 'superadmin')) {
                        adminBot = bot;
                        break;
                    }
                }

                if (!adminBot) {
                    const myJid = normalizeJid(this.sock.user.id);
                    const myP = meta.participants.find(pp => jidsMatch(pp.id, myJid));
                    if (myP && (myP.admin === 'admin' || myP.admin === 'superadmin')) {
                        adminBot = this;
                    }
                }

                if (!adminBot) {
                    try {
                        let inviteCode = null;
                        try {
                            inviteCode = await this.sock.groupInviteCode(from);
                        } catch (e) {
                            for (const bot of allConnectedBots) {
                                try {
                                    const botJid = normalizeJid(bot.sock.user.id);
                                    if (currentMembers.some(m => jidsMatch(m, botJid))) {
                                        inviteCode = await bot.sock.groupInviteCode(from);
                                        if (inviteCode) break;
                                    }
                                } catch (e2) { continue; }
                            }
                        }

                        if (inviteCode) {
                            let added = 0, alreadyIn = 0, failed = 0;
                            for (const bot of allConnectedBots) {
                                const botJid = normalizeJid(bot.sock.user.id);
                                if (currentMembers.some(m => jidsMatch(m, botJid))) {
                                    alreadyIn++;
                                    continue;
                                }
                                try {
                                    await bot.sock.groupAcceptInvite(inviteCode);
                                    added++;
                                    await delay(1500);
                                } catch (e) { failed++; }
                            }
                            HSEE.clearCache(from);
                            await this.sendSlide(from, `📡 *SUMMON COMPLETE!*\n✅ Added: ${added} | 📍 Already: ${alreadyIn} | ❌ Failed: ${failed}\n🔗 Method: Invite Link`, msg);
                        } else {
                            await this.sendSlide(from, `❌ No bot has admin. Promote a bot first!`, msg);
                        }
                    } catch (e) {
                        await this.sendSlide(from, `❌ Summon failed: ${e.message}`, msg);
                    }
                    return;
                }

                const botsToAdd = [];
                for (const bot of allConnectedBots) {
                    const botJid = normalizeJid(bot.sock.user.id);
                    if (!currentMembers.some(m => jidsMatch(m, botJid))) {
                        botsToAdd.push(botJid);
                    }
                }

                if (botsToAdd.length === 0) {
                    await this.sendSlide(from, `✅ All bots already in group!`, msg);
                    return;
                }

                let added = 0, failed = 0;
                for (let i = 0; i < botsToAdd.length; i += 3) {
                    const batch = botsToAdd.slice(i, i + 3);
                    try {
                        await adminBot.sock.groupParticipantsUpdate(from, batch, 'add');
                        added += batch.length;
                        await delay(1500);
                    } catch (e) {
                        for (const botJid of batch) {
                            try {
                                await adminBot.sock.groupParticipantsUpdate(from, [botJid], 'add');
                                added++;
                                await delay(1000);
                            } catch (e2) {
                                failed++;
                                try {
                                    const inviteCode = await adminBot.sock.groupInviteCode(from);
                                    const failedBot = allConnectedBots.find(b => jidsMatch(normalizeJid(b.sock.user.id), botJid));
                                    if (failedBot && inviteCode) {
                                        await failedBot.sock.groupAcceptInvite(inviteCode);
                                        added++; failed--;
                                    }
                                } catch (e3) {}
                            }
                        }
                    }
                }
                HSEE.clearCache(from);
                await this.sendSlide(from, `📡 *SUMMON COMPLETE!*\n✅ Added: ${added} | ❌ Failed: ${failed} | 📍 Already: ${allConnectedBots.length - botsToAdd.length}`, msg);
                return;
            }

            // ========== CHANGE PREFIX ==========
            if (origText.toLowerCase().startsWith(`${p}changeprefix `) && isOwn) {
                const newPrefix = origText.slice(`${p}changeprefix `.length).trim();
                if (!newPrefix || newPrefix.length > 10) {
                    await this.sendSlide(from, `❌ Invalid prefix!\n\n💡 Usage: ${p}changeprefix [any sign or emoji]`, msg);
                    return;
                }
                const oldPrefix = currentPrefix;
                currentPrefix = newPrefix;
                savePrefix(newPrefix);
                await this.sendSlide(from, `✅ *PREFIX CHANGED!*\n\n🔄 Old: ${oldPrefix}\n✨ New: ${newPrefix}`, msg);
                return;
            }

            // ========== CLEAR CACHE ==========
            if (text === `${p}clearcache` && isOwn) {
                HSEE.clearAllCaches();
                await this.manager.commandBus.broadcast('clear_cache', { from }, this.botId);
                const mem = getMemoryUsage();
                await this.sendSlide(from, `🧹 *CACHE CLEARED!*\n\n🧠 RAM: ${mem.heapUsed}MB / ${mem.heapTotal}MB\n⏱️ Uptime: ${getUptime()}`, msg);
                return;
            }

        } catch (e) {
            console.error(`[${this.botId}] handleMsg error:`, e.message);
        }
    }

    // ==================== ATTACK BUTTON RESPONSE HANDLER ====================
    async handleAttackButtonResponse(session, response, from, sender, msg) {
        try {
            if (response.toLowerCase() === 'cancel') {
                this.attackButtonSessions.delete(sender);
                await this.sendSlide(from, '❌ Attack cancelled', msg);
                return;
            }

            const { choices, randomMode } = parseAttackChoices(response);
            if (choices.length === 0) {
                await this.sendSlide(from, '❌ Invalid! Examples: 1, 1 2, 1 2 3 5', msg);
                return;
            }

            let finalChoices = choices.includes(4) ? [1, 2, 3, 5] : choices;
            const { names } = session;

            if (finalChoices.includes(5)) {
                this.attackButtonSessions.delete(sender);
                this.autoReplyTargetSessions.set(sender, {
                    jid: from,
                    names: names,
                    choices: finalChoices.filter(c => c !== 5),
                    attackMode: true,
                    randomMode,
                    timestamp: Date.now()
                });

                const otherChoices = finalChoices.filter(c => c !== 5);
                if (otherChoices.length > 0) {
                    await this.startOtherAttacks(otherChoices, from, names, randomMode);
                }

                await this.sendSlide(from, `🎯 *AUTO-REPLY TARGETS*\n\nMention (@) targets or reply "all"\n📝 Names: ${names.join(', ')}\n⚡ Reply Delay: ${autoReplyDelays[this.botId] || 5000}ms`, msg);
                return;
            }

            this.attackButtonSessions.delete(sender);
            await this.startOtherAttacks(finalChoices, from, names, randomMode);

            if (finalChoices.length > 0) {
                await this.sendSlide(from, `⚡ *ATTACKS STARTED!*\n✅ Modes: ${finalChoices.join(', ')}\n📝 Names: ${names.join(', ')}${randomMode ? '\n🎲 Random Mode: Enabled' : ''}\n🛑 ${currentPrefix}stopattack`, msg);
                updateStats('attack', null, 'execute');
            }
        } catch (e) {
            console.error(`[${this.botId}] handleAttackButtonResponse error:`, e.message);
        }
    }

    // ==================== START OTHER ATTACKS ====================
    async startOtherAttacks(choices, from, names, randomMode) {
        if (choices.includes(1)) {
            const namesPerTriple = Math.ceil(35 / names.length);
            let tripleIndex = 1;
            const tripleTasks = [];
            for (let i = 0; i < names.length && tripleIndex <= 35; i++) {
                const name = names[i];
                const endTriple = Math.min(tripleIndex + namesPerTriple - 1, 35);
                for (let t = tripleIndex; t <= endTriple && t <= 35; t++) {
                    for (const nc of tripleNcCombos[`triple${t}`]) {
                        tripleTasks.push(
                            this.manager.commandBus.broadcast('start_nc', {
                                from, text: name, nc,
                                tripleId: `triple${t}`,
                                attackMode: true,
                                randomMode,
                                randomType: 'attack'
                            }, this.botId, false)
                        );
                    }
                }
                tripleIndex = endTriple + 1;
            }
            await Promise.all(tripleTasks);
        }

        if (choices.includes(2)) {
            if (gcPfpCollections[from]?.images?.length >= 4) {
                const connectedBots = this.manager.commandBus.getConnected();
                connectedBots.forEach((bot, botIndex) => {
                    bot.execute('start_gcpfp', {
                        from,
                        images: gcPfpCollections[from].images,
                        startIndex: botIndex % gcPfpCollections[from].images.length,
                        totalBots: connectedBots.length,
                        botIndex: botIndex,
                        attackMode: true,
                        randomMode,
                        randomType: 'attack'
                    }, false);
                });
            }
        }

        if (choices.includes(3)) {
            if (gcPfpCollections[from]?.images?.length > 0) {
                await this.manager.commandBus.broadcast('start_picspam_saved', {
                    from,
                    images: gcPfpCollections[from].images,
                    attackMode: true,
                    randomMode,
                    randomType: 'attack'
                }, this.botId, false);
            }
        }
    }

    // ==================== SEND HELPERS ====================
    async sendSlide(jid, text, quotedMsg, mentions = []) {
        try {
            if (!this.sock || !this.connected) return;
            const options = {};
            if (quotedMsg) options.quoted = quotedMsg;
            await this.sock.sendMessage(jid, {
                text,
                mentions: mentions.length ? mentions : undefined
            }, options).catch(() => {});
        } catch (e) {
            console.error(`[${this.botId}] sendSlide error:`, e.message);
        }
    }

    async send(jid, text, mentions = []) {
        try {
            if (!this.sock || !this.connected) return;
            await this.sock.sendMessage(jid, {
                text,
                mentions: mentions.length ? mentions : undefined
            }).catch(() => {});
        } catch (e) {
            console.error(`[${this.botId}] send error:`, e.message);
        }
    }

    // ==================== EXECUTE METHOD ====================
    async execute(type, data, confirm = true) {
        try {
            const { from } = data;

            // ===== LEAVE =====
            if (type === 'leave') {
                await this.send(from, `👋 ${this.botId} leaving...`);
                await this.sock.groupLeave(from).catch(() => {});
            }

            // ===== SEND MENU =====
            else if (type === 'send_menu') {
                try {
                    const menuText = generateMenu(currentPrefix);
                    const options = data.quotedMsg ? { quoted: data.quotedMsg } : {};
                    await this.sock.sendMessage(from, { text: menuText }, options);
                } catch (e) {
                    console.error(`[${this.botId}] send_menu error:`, e.message);
                }
            }

            // ===== PING RESPOND =====
            else if (type === 'ping_respond') {
                try {
                    const start = Date.now();
                    const options = data.quotedMsg ? { quoted: data.quotedMsg } : {};
                    await this.sock.sendMessage(from, {
                        text: `🏓 *${this.botId}* — ${Date.now() - start}ms | ⏱️ ${getUptime()}`
                    }, options);
                } catch (e) {
                    console.error(`[${this.botId}] ping error:`, e.message);
                }
            }

            // ===== SEND TEXT =====
            else if (type === 'send_text') {
                try {
                    const options = data.quotedMsg ? { quoted: data.quotedMsg } : {};
                    await this.sock.sendMessage(from, { text: data.text }, options);
                } catch (e) {
                    console.error(`[${this.botId}] send_text error:`, e.message);
                }
            }

            // ===== SEND TTS ONCE =====
            else if (type === 'send_tts_once') {
                try {
                    const audioBuf = Buffer.from(data.audio, 'base64');
                    const options = data.quotedMsg ? { quoted: data.quotedMsg } : {};
                    await this.sock.sendMessage(from, {
                        audio: audioBuf,
                        mimetype: 'audio/mpeg',
                        ptt: true
                    }, options);
                } catch (e) {
                    console.error(`[${this.botId}] send_tts_once error:`, e.message);
                }
            }

            // ===== ARISE ANNOUNCE =====
            else if (type === 'arise_announce') {
                try {
                    const imageBuf = Buffer.from(data.image, 'base64');
                    await this.sock.sendMessage(from, {
                        image: imageBuf,
                        caption: `🏴 *SOVEREIGN ARRIVAL* 🏴\n\n${data.caption}\n\n👑 @${data.senderJid.split('@')[0]}\n🤖 ${this.botId}\n\n🔱 ░≪ 𝑃𝑂𝑊𝐸𝑅𝐸𝐷 𝐵𝑌 KANHA ≫░ 🔱`,
                        mentions: [data.senderJid]
                    });
                } catch (e) {
                    console.error(`[${this.botId}] arise_announce error:`, e.message);
                }
            }

            // ===== BULLY =====
            else if (type === 'start_bully') {
                if (data.targets && Array.isArray(data.targets)) {
                    for (const target of data.targets) {
                        const id = `${from}_bully_${normalizeJid(target)}`;
                        if (this.activeBully.has(id)) this.activeBully.get(id).active = false;
                        const task = { active: true, jid: from, target: normalizeJid(target) };
                        this.activeBully.set(id, task);
                    }
                    if (confirm) {
                        const names = data.targets.map(t => `@${t.split('@')[0]}`).join(', ');
                        await this.send(from, `👊 *${this.botId} BULLY ACTIVE!*\n🎯 Targets: ${names}\n💀 All messages will be deleted!`, data.targets);
                    }
                }
            }
            else if (type === 'stop_bully') {
                let c = 0;
                this.activeBully.forEach((t, k) => {
                    if (k.startsWith(from)) { t.active = false; this.activeBully.delete(k); c++; }
                });
                if (confirm && c) await this.send(from, `✅ ${this.botId} bully stopped (${c})`);
            }

            // ===== TAGALL EXECUTE =====
            else if (type === 'tagall_execute') {
                try {
                    const meta = await HSEE.getGroupMeta(this.sock, from);
                    if (meta) {
                        const mentions = meta.participants.map(pp => pp.id);
                        const tagText = data.tagText || '';
                        const mentionList = mentions.map(m => `@${m.split('@')[0]}`).join(' ');
                        const msgText = tagText ? `${tagText}\n\n${mentionList}` : mentionList;
                        const count = data.count || 1;
                        const id = `${from}_tagall`;
                        const task = { active: true };
                        this.activeTagall.set(id, task);
                        for (let round = 0; round < count; round++) {
                            if (!this.connected || !task.active) break;
                            await HSEE.runAttack(async () => {
                                await this.sock.sendMessage(from, {
                                    text: count > 1 ? `📢 [${round + 1}/${count}]\n${msgText}` : msgText,
                                    mentions
                                });
                            });
                            updateStats('tagall', null, 'execute');
                            if (round < count - 1) await delay(1000);
                        }
                        this.activeTagall.delete(id);
                    }
                } catch (e) {
                    console.error(`[${this.botId}] Tagall error:`, e.message);
                }
            }

            else if (type === 'stop_tagall') {
                let c = 0;
                this.activeTagall.forEach((t, k) => {
                    if (!from || k.startsWith(from)) { t.active = false; this.activeTagall.delete(k); c++; }
                });
                if (confirm && c) await this.send(from, `✅ Tagall stopped (${c})`);
            }

            // ===== KICK / PROMOTE / DEMOTE =====
            else if (type === 'kick') {
                await this.sock.groupParticipantsUpdate(from, [data.target], 'remove').catch(() => {});
                HSEE.clearCache(from);
            }
            else if (type === 'promote') {
                await this.sock.groupParticipantsUpdate(from, [data.target], 'promote').catch(() => {});
                HSEE.clearCache(from);
            }
            else if (type === 'demote') {
                await this.sock.groupParticipantsUpdate(from, [data.target], 'demote').catch(() => {});
                HSEE.clearCache(from);
            }

            // ===== GC PFP LOOP =====
            else if (type === 'start_gcpfp') {
                const id = `${from}_gcpfp`;
                if (this.activeGcPfp.has(id)) this.activeGcPfp.get(id).active = false;
                const images = data.images.map(b64 => Buffer.from(b64, 'base64'));
                const startIndex = data.startIndex || 0;
                const totalBots = data.totalBots || 1;
                const randomMode = data.randomMode || false;
                let actualDelay = getRandomDelay('gcpfp');
                
                const task = {
                    active: true, images,
                    currentIndex: startIndex,
                    attackMode: data.attackMode,
                    errorCount: 0, successCount: 0,
                    currentDelay: actualDelay, totalBots
                };
                this.activeGcPfp.set(id, task);
                (async () => {
                    while (task.active) {
                        try {
                            await HSEE.runAttack(async () => {
                                await this.sock.updateProfilePicture(from, task.images[task.currentIndex]);
                            });
                            task.currentIndex = (task.currentIndex + task.totalBots) % task.images.length;
                            task.successCount++;
                            task.errorCount = 0;
                            await delay(task.currentDelay);
                            task.currentDelay = getRandomDelay('gcpfp');
                        } catch (err) {
                            task.errorCount++;
                            await delay(5000);
                        }
                    }
                })();
                if (confirm) await this.send(from, `⚡ GCPFP (${this.botId}) ${images.length} imgs @ Random 5-9s`);
            }
            else if (type === 'stop_gcpfp') {
                const id = `${from}_gcpfp`;
                if (this.activeGcPfp.has(id)) {
                    this.activeGcPfp.get(id).active = false;
                    this.activeGcPfp.delete(id);
                    if (confirm) await this.send(from, '✅ GCPFP stopped');
                }
            }

            // ===== PICSPAM SAVED =====
            else if (type === 'start_picspam_saved') {
                const id = `${from}_picspam`;
                if (this.activePic.has(id)) this.activePic.get(id).active = false;
                const images = data.images.map(b64 => Buffer.from(b64, 'base64'));
                const task = { active: true, images, attackMode: data.attackMode };
                this.activePic.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runAttack(async () => {
                            try {
                                const img = task.images[Math.floor(Math.random() * task.images.length)];
                                await this.sock.sendMessage(from, { image: img });
                            } catch {}
                        });
                        const randomDelay = getRandomDelay('pcspm');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ Picspam saved @ Random 1.5-2.5s`);
            }

            // ===== REACTION =====
            else if (type === 'start_reaction') {
                this.activeReactions.set(`${from}_react`, { active: true, jid: from, emoji: data.emoji });
                if (confirm) await this.send(from, `⚡ Reaction ${data.emoji}!`);
            }
            else if (type === 'stop_reaction') {
                const id = `${from}_react`;
                if (this.activeReactions.has(id)) {
                    this.activeReactions.delete(id);
                    if (confirm) await this.send(from, '✅ Reaction stopped');
                }
            }

            // ===== NC (PURE RANDOM DELAY) =====
            else if (type === 'start_nc') {
                const { text, nc, tripleId, attackMode, randomMode, randomType } = data;
                const emojis = emojiArrays[nc] || emojiArrays.nc1;
                const id = tripleId ? `${from}_${tripleId}_${nc}` : `${from}_${nc}`;
                if (this.activeNC.has(id)) this.activeNC.get(id).active = false;
                
                let actualDelay;
                if (attackMode) {
                    actualDelay = getRandomDelay('attack');
                } else if (tripleId) {
                    actualDelay = getRandomDelay('triple');
                } else {
                    actualDelay = getRandomDelay('nc');
                }
                
                const task = { active: true, tripleId, attackMode };
                this.activeNC.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runAttack(async () => {
                            try {
                                const l = emojis[Math.floor(Math.random() * emojis.length)];
                                const r = emojis[Math.floor(Math.random() * emojis.length)];
                                await this.sock.groupUpdateSubject(from, `${l} ${text} ${r}`);
                                updateStats('nc', nc, 'execute');
                            } catch {}
                        });
                        
                        let randomDelay;
                        if (task.attackMode) {
                            randomDelay = getRandomDelay('attack');
                        } else if (task.tripleId) {
                            randomDelay = getRandomDelay('triple');
                        } else {
                            randomDelay = getRandomDelay('nc');
                        }
                        await delay(randomDelay);
                    }
                })();
                if (confirm && !tripleId && !attackMode) {
                    await this.send(from, `⚡ ${nc.toUpperCase()}! Random Delay: ${actualDelay}ms`);
                }
            }
            else if (type === 'stop_nc') {
                let c = 0;
                this.activeNC.forEach((t, k) => {
                    if (k.startsWith(from)) { t.active = false; this.activeNC.delete(k); c++; }
                });
                if (c && confirm) await this.send(from, `✅ Stopped ${c} NC`);
            }

            else if (type === 'stop_triple') {
                const { tripleId } = data;
                let c = 0;
                this.activeNC.forEach((t, k) => {
                    if (k.startsWith(from) && t.tripleId === tripleId) {
                        t.active = false; this.activeNC.delete(k); c++;
                    }
                });
                if (confirm) await this.send(from, `✅ ${tripleId} stopped (${c})`);
            }

            else if (type === 'stop_all_triples') {
                let c = 0;
                this.activeNC.forEach((t, k) => {
                    if (k.startsWith(from) && t.tripleId) {
                        t.active = false; this.activeNC.delete(k); c++;
                    }
                });
                if (confirm) await this.send(from, `✅ All triples stopped (${c})`);
            }

            // ===== AUTO-REPLY =====
            else if (type === 'start_auto_reply') {
                const id = `${from}_auto_reply`;
                if (this.activeAutoReply.has(id)) this.activeAutoReply.get(id).active = false;
                const task = {
                    active: true,
                    names: data.names,
                    targets: data.targets || [],
                    attackMode: data.attackMode
                };
                this.activeAutoReply.set(id, task);
                updateStats('autoreply', null, 'start');
                if (confirm) {
                    const targetInfo = task.targets.length > 0 ? `${task.targets.length} members` : 'ALL';
                    await this.send(from, `⚡ AutoReply! Targets: ${targetInfo}`);
                }
            }
            else if (type === 'stop_auto_reply') {
                const id = `${from}_auto_reply`;
                if (this.activeAutoReply.has(id)) {
                    this.activeAutoReply.get(id).active = false;
                    this.activeAutoReply.delete(id);
                    updateStats('autoreply', null, 'stop');
                    if (confirm) await this.send(from, '✅ AutoReply stopped');
                }
            }

            // ===== STOP ATTACK MODE =====
            else if (type === 'stop_attack_mode') {
                let c = 0;
                const maps = [
                    this.activeNC, this.activePic, this.activeGcPfp,
                    this.activeAutoReply, this.activeTTS, this.activeTxt,
                    this.activeSlides, this.activeAudio, this.activeSlideAudio,
                    this.activeVideo, this.activeSlideVideo, this.activeSticker,
                    this.activeReactions, this.activeTagall, this.activeBully
                ];
                maps.forEach(m => m.forEach((t, k) => {
                    if (k.startsWith(from) && t.attackMode) {
                        t.active = false; m.delete(k); c++;
                    }
                }));
                if (confirm) await this.send(from, `🛑 Attack stopped (${c})`);
            }

            // ===== SLIDE =====
            else if (type === 'start_slide') {
                const id = `${from}_slide`;
                if (this.activeSlides.has(id)) this.activeSlides.get(id).active = false;
                const task = { active: true, jid: from, target: data.target, latestMsg: data.quotedMsg };
                this.activeSlides.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runNormal(async () => {
                            try {
                                if (task.latestMsg) {
                                    await this.sock.sendMessage(from, { text: data.text }, { quoted: task.latestMsg });
                                }
                            } catch {}
                        });
                        const randomDelay = getRandomDelay('slide');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ Slide! Random Delay: ${getRandomDelay('slide')}ms`);
            }
            else if (type === 'stop_slide') {
                const id = `${from}_slide`;
                if (this.activeSlides.has(id)) {
                    this.activeSlides.get(id).active = false;
                    this.activeSlides.delete(id);
                    if (confirm) await this.send(from, '✅ Slide stopped');
                }
            }

            // ===== FDESC =====
            else if (type === 'start_fdesc') {
                this.activeFDesc.set(from, { active: true });
                if (confirm) await this.send(from, `⚡ FDESC: Fastest description sync active.`);
                (async () => {
                    while (this.activeFDesc.get(from)?.active && this.connected) {
                        await HSEE.runAttack(async () => {
                            try {
                                const e = getRandomNcEmoji();
                                await this.sock.groupUpdateDescription(from, `${data.text} ${e}`);
                            } catch {}
                        });
                        await delay(1200); // 1.2s - Fastest safe limit
                    }
                })();
            }
            else if (type === 'stop_fdesc') {
                if (this.activeFDesc.has(from)) { 
                    this.activeFDesc.get(from).active = false; 
                    this.activeFDesc.delete(from);
                    if (confirm) await this.send(from, "🛑 FDESC Stopped."); 
                }
            }

            // ===== TRIPLEM =====
            else if (type === 'start_triplem') {
                const id = `${from}_triplem`;
                this.activeTripleM.set(id, { active: true, turn: 0 });
                (async () => {
                    const task = this.activeTripleM.get(id);
                    while (task && task.active && this.connected) {
                        if (task.turn % data.totalBots === data.botIndex) {
                            await HSEE.runAttack(async () => {
                                try {
                                    const e = getRandomNcEmoji();
                                    await this.sock.groupUpdateSubject(from, `${data.text} ${e}`);
                                } catch {}
                            });
                        }
                        task.turn++;
                        await delay(900); // Super fast 900ms sync
                    }
                })();
            }
            else if (type === 'stop_triplem') {
                const id = `${from}_triplem`;
                if (this.activeTripleM.has(id)) { 
                    this.activeTripleM.get(id).active = false; 
                    this.activeTripleM.delete(id);
                    if (confirm) await this.send(from, "🛑 TRIPLEM Stopped."); 
                }
            }

            // ===== DTEXT =====
            else if (type === 'start_dtext') {
                this.activeDText.set(from, { active: true });
                if (confirm) await this.send(from, `🌀 DTEXT: Custom loop active with emojis.`);
                (async () => {
                    while (this.activeDText.get(from)?.active && this.connected) {
                        await HSEE.runAttack(async () => {
                            try {
                                const e = getRandomNcEmoji();
                                await this.sock.sendMessage(from, { text: `${data.text} ${e}` });
                            } catch {}
                        });
                        await delay(12000); // 12 seconds text delay
                    }
                })();
            }
            else if (type === 'stop_dtext') {
                if (this.activeDText.has(from)) { 
                    this.activeDText.get(from).active = false; 
                    this.activeDText.delete(from);
                    if (confirm) await this.send(from, "🛑 DTEXT Stopped."); 
                }
            }

            // ===== TXT =====
            else if (type === 'start_txt') {
                const id = `${from}_txt`;
                if (this.activeTxt.has(id)) this.activeTxt.get(id).active = false;
                const task = { active: true };
                this.activeTxt.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runAttack(() => this.sock.sendMessage(from, { text: data.text })).catch(() => {});
                        const randomDelay = getRandomDelay('txt');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ Text! Random Delay: ${getRandomDelay('txt')}ms`);
            }
            else if (type === 'stop_txt') {
                const id = `${from}_txt`;
                if (this.activeTxt.has(id)) {
                    this.activeTxt.get(id).active = false;
                    this.activeTxt.delete(id);
                    if (confirm) await this.send(from, '✅ Text stopped');
                }
            }

            // ===== TTS ATTACK =====
            else if (type === 'start_tts') {
                const id = `${from}_tts`;
                if (this.activeTTS.has(id)) this.activeTTS.get(id).active = false;
                const task = { active: true };
                this.activeTTS.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runAttack(async () => {
                            try {
                                const audio = await generateTTS(data.text);
                                await this.sock.sendMessage(from, { audio, mimetype: 'audio/mpeg', ptt: true });
                            } catch {}
                        });
                        const randomDelay = getRandomDelay('ttsatk');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ TTS Attack! Random Delay: ${getRandomDelay('ttsatk')}ms`);
            }
            else if (type === 'stop_tts') {
                const id = `${from}_tts`;
                if (this.activeTTS.has(id)) {
                    this.activeTTS.get(id).active = false;
                    this.activeTTS.delete(id);
                    if (confirm) await this.send(from, '✅ TTS stopped');
                }
            }

            // ===== AUDIO =====
            else if (type === 'start_audio') {
                const id = `${from}_audio`;
                if (this.activeAudio.has(id)) this.activeAudio.get(id).active = false;
                const task = { active: true, buf: Buffer.from(data.buffer, 'base64') };
                this.activeAudio.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runAttack(() =>
                            this.sock.sendMessage(from, { audio: task.buf, mimetype: 'audio/mpeg', ptt: data.ptt })
                        ).catch(() => {});
                        const randomDelay = getRandomDelay('audio');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ Audio! Random Delay: ${getRandomDelay('audio')}ms`);
            }
            else if (type === 'stop_audio') {
                const id = `${from}_audio`;
                if (this.activeAudio.has(id)) {
                    this.activeAudio.get(id).active = false;
                    this.activeAudio.delete(id);
                    if (confirm) await this.send(from, '✅ Audio stopped');
                }
            }

            // ===== SLIDE AUDIO =====
            else if (type === 'start_saudio') {
                const id = `${from}_saudio`;
                if (this.activeSlideAudio.has(id)) this.activeSlideAudio.get(id).active = false;
                const task = { active: true, jid: from, latestMsg: null, buf: Buffer.from(data.buffer, 'base64') };
                this.activeSlideAudio.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runNormal(async () => {
                            try {
                                const options = task.latestMsg ? { quoted: task.latestMsg } : {};
                                await this.sock.sendMessage(from, { audio: task.buf, mimetype: 'audio/mpeg', ptt: data.ptt }, options);
                            } catch {}
                        });
                        const randomDelay = getRandomDelay('saudio');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ Slide Audio! Random Delay: ${getRandomDelay('saudio')}ms`);
            }
            else if (type === 'stop_saudio') {
                const id = `${from}_saudio`;
                if (this.activeSlideAudio.has(id)) {
                    this.activeSlideAudio.get(id).active = false;
                    this.activeSlideAudio.delete(id);
                    if (confirm) await this.send(from, '✅ Slide Audio stopped');
                }
            }

            // ===== PIC =====
            else if (type === 'start_pic') {
                const id = `${from}_pic`;
                if (this.activePic.has(id)) this.activePic.get(id).active = false;
                const task = { active: true, buf: Buffer.from(data.buffer, 'base64') };
                this.activePic.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runAttack(() => {
                            return this.sock.sendMessage(from, { image: task.buf });
                        }).catch(() => {});
                        const randomDelay = getRandomDelay('pcspm');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ Pic! Random Delay: ${getRandomDelay('pcspm')}ms`);
            }
            else if (type === 'stop_pic') {
                [from + '_pic', from + '_picspam'].forEach(id => {
                    if (this.activePic.has(id)) {
                        this.activePic.get(id).active = false;
                        this.activePic.delete(id);
                    }
                });
                if (confirm) await this.send(from, '✅ Pic stopped');
            }

            // ===== VIDEO =====
            else if (type === 'start_video') {
                const id = `${from}_video`;
                if (this.activeVideo.has(id)) this.activeVideo.get(id).active = false;
                const task = { active: true, buf: Buffer.from(data.buffer, 'base64') };
                this.activeVideo.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runAttack(() =>
                            this.sock.sendMessage(from, { video: task.buf, mimetype: 'video/mp4' })
                        ).catch(() => {});
                        const randomDelay = getRandomDelay('video');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ Video! Random Delay: ${getRandomDelay('video')}ms`);
            }
            else if (type === 'stop_video') {
                const id = `${from}_video`;
                if (this.activeVideo.has(id)) {
                    this.activeVideo.get(id).active = false;
                    this.activeVideo.delete(id);
                    if (confirm) await this.send(from, '✅ Video stopped');
                }
            }

            // ===== SLIDE VIDEO =====
            else if (type === 'start_svideo') {
                const id = `${from}_svideo`;
                if (this.activeSlideVideo.has(id)) this.activeSlideVideo.get(id).active = false;
                const task = { active: true, jid: from, latestMsg: null, buf: Buffer.from(data.buffer, 'base64') };
                this.activeSlideVideo.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runNormal(async () => {
                            try {
                                const options = task.latestMsg ? { quoted: task.latestMsg } : {};
                                await this.sock.sendMessage(from, { video: task.buf, mimetype: 'video/mp4' }, options);
                            } catch {}
                        });
                        const randomDelay = getRandomDelay('svideo');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ Slide Video! Random Delay: ${getRandomDelay('svideo')}ms`);
            }
            else if (type === 'stop_svideo') {
                const id = `${from}_svideo`;
                if (this.activeSlideVideo.has(id)) {
                    this.activeSlideVideo.get(id).active = false;
                    this.activeSlideVideo.delete(id);
                    if (confirm) await this.send(from, '✅ Slide Video stopped');
                }
            }

            // ===== STICKER =====
            else if (type === 'start_sticker') {
                const id = `${from}_sticker`;
                if (this.activeSticker.has(id)) this.activeSticker.get(id).active = false;
                const task = { active: true, buf: Buffer.from(data.buffer, 'base64') };
                this.activeSticker.set(id, task);
                (async () => {
                    while (task.active) {
                        await HSEE.runAttack(() =>
                            this.sock.sendMessage(from, { sticker: task.buf })
                        ).catch(() => {});
                        const randomDelay = getRandomDelay('stspm');
                        await delay(randomDelay);
                    }
                })();
                if (confirm) await this.send(from, `⚡ Sticker! Random Delay: ${getRandomDelay('stspm')}ms`);
            }
            else if (type === 'stop_sticker') {
                const id = `${from}_sticker`;
                if (this.activeSticker.has(id)) {
                    this.activeSticker.get(id).active = false;
                    this.activeSticker.delete(id);
                    if (confirm) await this.send(from, '✅ Sticker stopped');
                }
            }

            // ===== CLEAR CACHE =====
            else if (type === 'clear_cache') {
                try {
                    HSEE.clearCache();
                    msgRetryCounterCache.flushAll();
                    if (global.gc) global.gc();
                    if (confirm) await this.send(from, `✅ ${this.botId} cache cleared & memory optimized!`);
                } catch (e) {
                    if (confirm) await this.send(from, `⚠️ ${this.botId} partial cache clear: ${e.message}`);
                }
            }

                        // ===== STOP ALL (per group) =====
            else if (type === 'stop_all') {
                let c = 0;
                const maps = [
                    this.activeNC, this.activeSlides, this.activeTxt,
                    this.activeTTS, this.activePic, this.activeGcPfp,
                    this.activeReactions, this.activeAudio, this.activeSlideAudio,
                    this.activeVideo, this.activeSlideVideo, this.activeSticker,
                    this.activeAutoReply, this.activeTagall, this.activeBully,
                    this.activeGifSpam, this.activeStickerSpam, this.activeVnSpam,
                    this.activeTargetSlides,
                    // KRISHNA v6.2.0 Maps
                    this.activeFDesc, this.activeDText, this.activeTripleM
                ];
                maps.forEach(m => m.forEach((t, k) => {
                    if (k.startsWith(from) || t.jid === from) {
                        t.active = false; m.delete(k); c++;
                    }
                }));
                
                if (this.activeNcLoop) { this.activeNcLoop.active = false; this.activeNcLoop = null; c++; }
                if (this.activeHeartLoop) { this.activeHeartLoop.active = false; this.activeHeartLoop = null; c++; }
                if (this.activeUseWords) { this.activeUseWords.active = false; this.activeUseWords = null; c++; }
                if (this.activeCoverGC) { this.activeCoverGC.active = false; this.activeCoverGC = null; c++; }
                if (this.activeTimeNC) { this.activeTimeNC.active = false; this.activeTimeNC = null; c++; }
                if (this.activeRageMode) { this.activeRageMode.active = false; this.activeRageMode = null; c++; }
                
                this.gcpfpCollecting.set(from, false);
                if (confirm) await this.send(from, `🛑 Stopped ${c} tasks`);
            }

            // ===== STOP ALL GLOBAL =====
            else if (type === 'stop_all_global') {
                let c = 0;
                const maps = [
                    this.activeNC, this.activeSlides, this.activeTxt,
                    this.activeTTS, this.activePic, this.activeGcPfp,
                    this.activeReactions, this.activeAudio, this.activeSlideAudio,
                    this.activeVideo, this.activeSlideVideo, this.activeSticker,
                    this.activeAutoReply, this.activeTagall, this.activeBully,
                    this.activeGifSpam, this.activeStickerSpam, this.activeVnSpam,
                    this.activeTargetSlides,
                    // KRISHNA v6.2.0 Maps
                    this.activeFDesc, this.activeDText, this.activeTripleM
                ];
                maps.forEach(m => {
                    m.forEach((t, k) => { t.active = false; c++; });
                    m.clear();
                });
                
                if (this.activeNcLoop) { this.activeNcLoop.active = false; this.activeNcLoop = null; c++; }
                if (this.activeHeartLoop) { this.activeHeartLoop.active = false; this.activeHeartLoop = null; c++; }
                if (this.activeUseWords) { this.activeUseWords.active = false; this.activeUseWords = null; c++; }
                if (this.activeCoverGC) { this.activeCoverGC.active = false; this.activeCoverGC = null; c++; }
                if (this.activeTimeNC) { this.activeTimeNC.active = false; this.activeTimeNC = null; c++; }
                if (this.activeRageMode) { this.activeRageMode.active = false; this.activeRageMode = null; c++; }
                
                this.gcpfpCollecting.clear();
                this.attackButtonSessions.clear();
                this.autoReplyTargetSessions.clear();
                this.ytsSessions.clear();
                console.log(`[${this.botId}] Global stop: ${c} tasks terminated`);
            }

        } catch (e) {
            console.error(`[${this.botId}] execute error:`, e.message);
        }
    }
}

// ==================== BOT MANAGER ====================
class BotManager {
    constructor() {
        this.bots = new Map();
        this.commandBus = new CommandBus();
        this.counter = 0;
        this.loaded = this.load();
    }

    load() {
        try {
            if (fs.existsSync(BOTS_FILE)) {
                const d = JSON.parse(fs.readFileSync(BOTS_FILE, 'utf8'));
                this.counter = d.counter || 0;
                return d;
            }
        } catch (e) {
            console.error('[Manager] Load error:', e.message);
        }
        return { counter: 0, bots: [] };
    }

    save() {
        try {
            if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });
            
            const allBots = [];
            for (const [id, bot] of this.bots) {
                allBots.push({
                    id,
                    phone: bot.phoneNumber,
                    qr: bot.useQR
                });
            }
            
            fs.writeFileSync(BOTS_FILE, JSON.stringify({
                counter: this.counter,
                bots: allBots
            }, null, 2));
        } catch (e) {
            console.error('[Manager] Save error:', e.message);
        }
    }

    async restore() {
        if (this.loaded.bots?.length) {
            console.log(`\n[MGR] 🔄 Restoring ${this.loaded.bots.length} bot(s) on Baileys 7...\n`);
            
            for (const b of this.loaded.bots) {
                try {
                    const s = new BotSession(b.id, b.phone, this, null, b.qr);
                    this.bots.set(b.id, s);
                    this.commandBus.registerBot(b.id, s);
                    await s.connect();
                    await delay(2000);
                } catch (e) {
                    console.error(`[MGR] Failed to restore ${b.id}:`, e.message);
                }
            }
        } else {
            console.log('\n[MGR] 📱 No bots found. Setting up first bot!\n');
            const c = await question('Login method (y = QR, n = Pairing, Enter = skip): ');
            if (c?.trim()) {
                const qr = c.toLowerCase() === 'y';
                let phone = null;
                if (!qr) {
                    phone = (await question('Enter phone number: ')).replace(/\D/g, '');
                    if (phone.length < 10) {
                        console.log('❌ Invalid phone!\n');
                        return;
                    }
                }
                await this.addBot(phone, null, qr);
            }
        }
        this.save();
    }

    async addBot(phone, jid = null, qr = false) {
        try {
            this.counter++;
            const id = `BOT${this.counter}`;
            const s = new BotSession(id, phone, this, jid, qr);
            this.bots.set(id, s);
            this.commandBus.registerBot(id, s);
            await s.connect();
            this.save();
            return `🤖 *${id}* created!\n${qr ? '📱 Scan QR' : `🔗 Pairing for ${phone}...`}`;
        } catch (e) {
            console.error('[Manager] addBot error:', e.message);
            return `❌ Failed: ${e.message}`;
        }
    }

    removeBot(id) {
        try {
            if (this.bots.has(id)) {
                this.commandBus.unregisterBot(id);
                this.bots.delete(id);
                this.save();
                console.log(`[MGR] 🗑️ Removed ${id}`);
            }
        } catch (e) {
            console.error('[Manager] removeBot error:', e.message);
        }
    }
}

// ==================== MAIN ENTRY POINT ====================
console.log('╔════════════════════════════════════════════════════════════╗');
console.log('║     ⚡ KANHA MATRIX v5 — PURE RANDOM DELAY EDITION ⚡   ║');
console.log('║     🚀 NO MANUAL DELAYS | ALL DELAYS RANDOM          ║');
console.log('╚════════════════════════════════════════════════════════════╝\n');

const manager = new BotManager();

(async () => {
    try {
        await manager.restore();
        console.log('\n✅ KANHA MATRIX v5 - PURE RANDOM EDITION is now running!\n');
        console.log('💡 Send .menu in chat to see all commands\n');
        console.log('🔥 ALL DELAYS ARE RANDOM - NO MANUAL OVERRIDE AVAILABLE:\n');
        console.log('   • NC: 1000-1500ms');
        console.log('   • Triple: 950ms');
        console.log('   • Text Spam: 12-25 seconds');
        console.log('   • Cover GC: 5-20ms (ULTRA FAST)');
        console.log('   • Rage: 5-10ms (ULTRA FAST)');
        console.log('   • Attack Mode: 300-15000ms');
        console.log('   • And more...\n');

        process.stdin.resume();

        rl.on('line', async (input) => {
            try {
                const cmd = input.trim().toLowerCase();

                if (cmd === 'status') {
                    const bots = manager.commandBus.getAllBots();
                    const mem = getMemoryUsage();
                    console.log(`\n📊 STATUS`);
                    console.log(`├ Bots: ${bots.length} | Online: ${manager.commandBus.getConnected().length}`);
                    console.log(`├ Suppressed: ${suppressedBots.size} | Prefix: ${currentPrefix}`);
                    console.log(`├ Uptime: ${getUptime()} | RAM: ${mem.heapUsed}MB/${mem.heapTotal}MB`);
                    const hsee = HSEE.getStats();
                    console.log(`├ HSEE: Cmd Q=${hsee.commandQueue.size}/${hsee.commandQueue.pending} Atk Q=${hsee.attackQueue.size}/${hsee.attackQueue.pending} Norm Q=${hsee.normalQueue.size}/${hsee.normalQueue.pending}`);
                    console.log(`├ Cache: ${hsee.cacheStats.keys || 0} groups`);
                    console.log(`└ Engine: Baileys 7 | PURE RANDOM DELAYS\n`);
                    bots.forEach((b, i) => {
                        const sup = suppressedBots.has(b.botId) ? ' 🔇' : '';
                        console.log(`  ${i + 1}. ${b.botId}: ${b.connected ? '✅' : '❌'}${sup} | ${b.phoneNumber || 'QR'} | R:${b.reconnectCount}`);
                    });
                    console.log('');
                }

                else if (cmd.startsWith('add ')) {
                    const args = cmd.slice(4).trim().split(' ');
                    const phone = args[0]?.replace(/\D/g, '');
                    const method = args[1];
                    if (phone && phone.length >= 10) {
                        const result = await manager.addBot(phone, null, method === 'y');
                        console.log(result);
                    } else console.log('Usage: add [phone] [y/n]');
                }

                else if (cmd.startsWith('remove ')) {
                    manager.removeBot(cmd.slice(7).trim().toUpperCase());
                }

                else if (cmd === 'clear') {
                    HSEE.clearCache();
                    msgRetryCounterCache.flushAll();
                    if (global.gc) global.gc();
                    console.log('✅ All caches cleared & memory optimized');
                }

                else if (cmd === 'help') {
                    console.log('\n📋 CONSOLE: status, add, remove, clear, stats, help, exit\n');
                }

                else if (cmd === 'stats') {
                    console.log('\n📈 STATS:', JSON.stringify(attackStats, null, 2), '\n');
                }

                else if (cmd === 'exit') {
                    console.log('\n🛑 Shutting down...');
                    saveStats(attackStats);
                    saveSuppressedBots(suppressedBots);
                    saveAutoReplyDelays(autoReplyDelays);
                    saveDelays(ncDelays);
                    saveAriseData(ariseData);
                    saveWords(savedWords);
                    console.log('✅ Saved. Goodbye!\n');
                    process.exit(0);
                }

                else if (cmd) console.log('Unknown. Type "help".');
            } catch (e) {
                console.error('[Console] Error:', e.message);
            }
        });
    } catch (e) {
        console.error('[MAIN] Fatal:', e.message, e.stack);
    }
})();

// ==================== VERIFICATION ====================
console.log('\n╔═════════════════════════════════════════════════════════╗');
console.log('║   ✅ KANHA MATRIX v5 - PURE RANDOM DELAY EDITION ✅   ║');
console.log('╠═══════════════════════════════════════════════════════════╣');
console.log('║ ✅ NO MANUAL DELAY OVERRIDE AVAILABLE                     ║');
console.log('║ ✅ ALL DELAYS ARE PURE RANDOM                             ║');
console.log('║ ✅ Configured in RANDOM_DELAY_CONFIG                      ║');
console.log('║ ✅ NC: 1000-1500ms | Triple: 950ms                       ║');
console.log('║ ✅ Text: 12-25s | CoverGC: 5-20ms | Rage: 5-10ms         ║');
console.log('║ ✅ Attack: 300-15000ms | ARC: 500-2000ms                 ║');
console.log('║ ✅ Target: 1-5s | NC Loop: 50-200ms                      ║');
console.log('║ ✅ Heart Loop: 20-100ms | Word NC: 100-300ms             ║');
console.log('║ ✅ All Baileys 7 features working                        ║');
console.log('╚═══════════════════════════════════════════════════════════╝\n');